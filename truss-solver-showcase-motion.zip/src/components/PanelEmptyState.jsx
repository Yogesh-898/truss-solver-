/** Quiet placeholder shown in a sidebar panel before anything has been solved. */
function PanelEmptyState({ Icon, children }) {
  return (
    <div className="flex flex-col items-center gap-2.5 px-6 py-14 text-center font-ui">
      {Icon && <Icon size={22} strokeWidth={1.5} className="text-text-muted/50" aria-hidden="true" />}
      <p className="text-xs leading-relaxed text-text-muted">{children}</p>
    </div>
  )
}

export default PanelEmptyState
