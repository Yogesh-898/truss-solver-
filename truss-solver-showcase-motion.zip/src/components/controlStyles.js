/**
 * Shared text-field styling: the ONE input / select pattern, used by the Edit
 * tab's table fields and the canvas's inline node / member / load forms.
 *
 * Control tier: rounded-md (see the radius tiers: controls = rounded-md,
 * surfaces = rounded-lg). Horizontal padding is px-2 so numbers still fit in
 * the Edit tab's narrow table columns.
 */
const fieldBase =
  'w-full rounded-md border border-border-subtle bg-base px-2 py-1.5 text-xs text-text-primary transition-colors disabled:cursor-not-allowed disabled:opacity-40'

export const inputClass = `${fieldBase} font-technical`
export const selectClass = `${fieldBase} font-ui`
