import useTrussStore from '../store/trussStore.js'
import SegmentedToggle from './SegmentedToggle.jsx'

const METHODS = [
  { id: 'joints', label: 'Joints' },
  { id: 'sections', label: 'Sections' },
]

/**
 * Chooses HOW the truss is solved.
 *   - Joints:   a "Solve" button solves every member at once.
 *   - Sections: the Section Cut tool (in the mode buttons) is how results
 *               are obtained, so the single Solve button is hidden.
 * Units are only ever passed on as labels; they never change a number.
 */
function MethodToggle() {
  const solveMethod = useTrussStore((state) => state.solveMethod)
  const setSolveMethod = useTrussStore((state) => state.setSolveMethod)
  const solveJoints = useTrussStore((state) => state.solveJoints)
  const solveReactionsOnly = useTrussStore((state) => state.solveReactionsOnly)

  return (
    <div className="flex items-center gap-2 font-ui">
      {/* Method toggle pill */}
      <SegmentedToggle
        options={METHODS}
        value={solveMethod}
        onChange={setSolveMethod}
        ariaLabel="Solving method"
      />

      {/* Solve button (joints only) */}
      {solveMethod === 'joints' && (
        <button
          type="button"
          onClick={solveJoints}
          className="rounded-md bg-accent px-4 py-1.5 text-xs font-semibold text-base transition-colors hover:bg-accent/80"
        >
          Solve
        </button>
      )}

      {/* Reactions-only shortcut */}
      <button
        type="button"
        onClick={solveReactionsOnly}
        className="rounded-md border border-border-subtle px-2.5 py-1.5 text-xs text-text-muted transition-colors hover:border-accent-2/40 hover:text-text-primary"
        title="Only compute the support reactions"
      >
        Reactions
      </button>
    </div>
  )
}

export default MethodToggle
