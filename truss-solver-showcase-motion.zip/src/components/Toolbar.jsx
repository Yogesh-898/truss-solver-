import { useRef } from 'react'
import useTrussStore from '../store/trussStore.js'
import { useSlidingIndicator, indicatorStyle } from './useSlidingIndicator.js'
import MethodToggle from './MethodToggle.jsx'
import { Link } from 'react-router-dom'
import { Plus, Spline, Anchor, ArrowDownToLine, Scissors, Crosshair, House } from 'lucide-react'

const MODES = [
  { id: 'addNode',    label: 'Add Node',    Icon: Plus },
  { id: 'addMember',  label: 'Add Member',  Icon: Spline },
  { id: 'addSupport', label: 'Add Support', Icon: Anchor },
  { id: 'addLoad',    label: 'Add Load',    Icon: ArrowDownToLine },
  { id: 'sectionCut', label: 'Section Cut', Icon: Scissors },
]

function Toolbar() {
  const mode = useTrussStore((state) => state.mode)
  const solveMethod = useTrussStore((state) => state.solveMethod)
  const setMode = useTrussStore((state) => state.setMode)
  const units = useTrussStore((state) => state.units)
  const openUnitsDialog = useTrussStore((state) => state.openUnitsDialog)
  const fbdOverlay = useTrussStore((state) => state.fbdOverlay)
  const toggleFbdOverlay = useTrussStore((state) => state.toggleFbdOverlay)

  // One indicator (tinted fill + bottom bar) that slides to the active mode button.
  const modesRef = useRef(null)
  const { rect, animate } = useSlidingIndicator(modesRef, `${mode}|${solveMethod}`)

  return (
    <div className="flex items-center border-b border-border-subtle bg-panel px-3 py-1.5 font-ui">
      {/* ─── Way back to the home page ─────────────────────── */}
      <Link
        to="/"
        aria-label="Home"
        title="Home"
        className="flex shrink-0 items-center rounded-md px-2.5 py-1.5 text-text-muted transition-colors hover:bg-panel-elevated hover:text-text-primary"
      >
        <House size={16} strokeWidth={1.8} aria-hidden="true" />
      </Link>
      <div className="mx-3 h-6 w-px shrink-0 bg-border-subtle" />

      {/* ─── Drawing-tool mode buttons ─────────────────────── */}
      <div ref={modesRef} className="relative flex items-center gap-1">
        {rect && (
          <span
            aria-hidden="true"
            className="pointer-events-none absolute rounded-md bg-accent/15 motion-reduce:!transition-none"
            style={indicatorStyle(rect, animate)}
          >
            <span className="absolute inset-x-1 -bottom-1.5 h-0.5 rounded-full bg-accent" />
          </span>
        )}
        {MODES.filter((m) => m.id !== 'sectionCut' || solveMethod === 'sections').map((m) => {
          const active = mode === m.id
          return (
            <button
              key={m.id}
              type="button"
              onClick={() => setMode(m.id)}
              title={m.label}
              data-sliding-active={active ? '' : undefined}
              className={[
                'relative flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-sm font-medium transition-colors duration-200',
                active
                  ? 'text-accent'
                  : 'text-text-muted hover:bg-panel-elevated hover:text-text-primary',
              ].join(' ')}
            >
              <m.Icon size={16} strokeWidth={active ? 2.4 : 1.8} />
              {/* Label visible once the toolbar has room for it; below that, icon-only
                  + tooltip. Sections mode has an extra button, so it needs more width
                  (breakpoints are defined in tailwind.config.js). */}
              <span
                className={
                  solveMethod === 'sections'
                    ? 'hidden toolbar-labels-sections:inline'
                    : 'hidden toolbar-labels:inline'
                }
              >
                {m.label}
              </span>
            </button>
          )
        })}
      </div>

      {/* ─── Divider ───────────────────────────────────────── */}
      <div className="mx-3 h-6 w-px bg-border-subtle" />

      {/* ─── Solve-controls group ──────────────────────────── */}
      <div className="flex items-center gap-2">
        <MethodToggle />
      </div>

      {/* ─── Right action controls ─────────────────────────── */}
      <div className="ml-auto flex items-center gap-2">
        {/* Free body diagram overlay toggle: a view option, not a drawing mode. Same
            selected language as the mode buttons (tinted fill, accent text, bottom bar);
            icon-only with a tooltip so the toolbar keeps its width. Turning it off is also
            available from the Undo button on the canvas chip. */}
        <button
          type="button"
          onClick={toggleFbdOverlay}
          aria-pressed={fbdOverlay}
          aria-label="Free body diagram overlay"
          title={fbdOverlay ? 'Hide free body diagram' : 'Show free body diagram'}
          className={[
            'relative flex items-center rounded-md px-2.5 py-1.5 transition-colors duration-200',
            fbdOverlay
              ? 'bg-accent/15 text-accent'
              : 'text-text-muted hover:bg-panel-elevated hover:text-text-primary',
          ].join(' ')}
        >
          <Crosshair size={16} strokeWidth={fbdOverlay ? 2.4 : 1.8} aria-hidden="true" />
          <span
            aria-hidden="true"
            className={`absolute inset-x-1 -bottom-1.5 h-0.5 rounded-full bg-accent transition-opacity duration-200 ${
              fbdOverlay ? 'opacity-100' : 'opacity-0'
            }`}
          />
        </button>
        <button
          type="button"
          onClick={openUnitsDialog}
          className="rounded-md border border-border-subtle px-3 py-1.5 font-technical text-xs text-text-muted transition-colors hover:border-accent/40 hover:text-text-primary"
          title="Change units"
        >
          {units ? `${units.length} · ${units.force}` : 'Units'}
        </button>
      </div>
    </div>
  )
}

export default Toolbar
