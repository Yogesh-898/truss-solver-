import { useEffect, useLayoutEffect, useState } from 'react'

/** Shared timing for every active-state slide (toolbar, sidebar tabs, segmented toggles). */
export const INDICATOR_MS = 200
export const INDICATOR_EASE = 'cubic-bezier(0.32, 0.72, 0, 1)'

/**
 * Tracks where the ACTIVE item of a group sits, so a single indicator element can
 * slide between items instead of each item snapping its own highlight on or off.
 *
 * The container must be `position: relative`; the active item is marked with the
 * `data-sliding-active` attribute. `layoutKey` should change whenever the active
 * item or the set of items changes. Item size changes (labels hiding at narrow
 * widths, tab counts changing) are picked up by a ResizeObserver.
 *
 * Returns `{ rect, animate }`: `rect` is null when there is no active item, and
 * `animate` stays false for the first paint so the indicator doesn't slide in
 * from nowhere on load.
 */
export function useSlidingIndicator(containerRef, layoutKey) {
  const [rect, setRect] = useState(null)
  const [animate, setAnimate] = useState(false)

  useLayoutEffect(() => {
    const container = containerRef.current
    if (!container) return undefined

    function measure() {
      const el = container.querySelector('[data-sliding-active]')
      if (!el) {
        setRect(null)
        return
      }
      const next = { left: el.offsetLeft, top: el.offsetTop, width: el.offsetWidth, height: el.offsetHeight }
      setRect((prev) =>
        prev &&
        prev.left === next.left &&
        prev.top === next.top &&
        prev.width === next.width &&
        prev.height === next.height
          ? prev
          : next,
      )
    }

    measure()
    const observer = new window.ResizeObserver(measure)
    observer.observe(container)
    container.querySelectorAll('button').forEach((button) => observer.observe(button))
    return () => observer.disconnect()
  }, [containerRef, layoutKey])

  useEffect(() => {
    if (!rect || animate) return undefined
    const id = window.requestAnimationFrame(() => setAnimate(true))
    return () => window.cancelAnimationFrame(id)
  }, [rect, animate])

  return { rect, animate }
}

/** Inline style that places an indicator over `rect` and slides it when `rect` changes. */
export function indicatorStyle(rect, animate, extra) {
  return {
    left: 0,
    top: rect.top,
    width: rect.width,
    height: rect.height,
    transform: `translateX(${rect.left}px)`,
    transition: animate
      ? `transform ${INDICATOR_MS}ms ${INDICATOR_EASE}, width ${INDICATOR_MS}ms ${INDICATOR_EASE}, border-radius ${INDICATOR_MS}ms ${INDICATOR_EASE}`
      : 'none',
    ...extra,
  }
}
