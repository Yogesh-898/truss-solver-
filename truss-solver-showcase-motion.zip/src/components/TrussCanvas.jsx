import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { Stage, Layer, Circle, Line, Text, Arrow, Group, Rect } from 'react-konva'
import useTrussStore from '../store/trussStore.js'
import { LOAD_DIRECTIONS } from '../models/trussModel.js'
import { computeLayout, getMemberGeometry, findCoincidentNodeIds } from '../models/layoutEngine.js'
import { computeView } from '../utils/view.js'
import { fmtNum } from '../utils/format.js'
import { TOKENS, withAlpha } from '../theme/palette.js'
import { inputClass, selectClass } from './controlStyles.js'
import FbdOverlay from './FbdOverlay.jsx'
import { overlayScene } from '../utils/fbdScene.js'
import { Undo2 } from 'lucide-react'

/* Colors come from the shared palette (src/theme/palette.js) — the same module
   Tailwind reads — so canvas and UI colors cannot drift apart. */

const NODE_RADIUS = 6.5
const GRID_MINOR = withAlpha(TOKENS.borderSubtle, 0.35)
const GRID_MAJOR = withAlpha(TOKENS.accent, 0.05)
const LOAD_ARROW_PX = 52

function forceColor(nature) {
  if (nature === 'Tension') return TOKENS.tension
  if (nature === 'Compression') return TOKENS.compression
  return TOKENS.zeroForce
}

/** Same as forceColor, but for TEXT: zero-force uses its readable text token. */
function forceTextColor(nature) {
  return nature === 'Zero-force' ? TOKENS.zeroForceText : forceColor(nature)
}

/**
 * Engineering support symbols with distinct glyphs:
 *  - Pin: Hinge triangle with pinned joint + ground plate with diagonal hatch lines
 *  - Roller: Hinge triangle with two circular rollers + ground plate (oriented by rollerDirection)
 */
function SupportSymbol({ node, support }) {
  const trianglePoints = [0, 0, -9, 16, 9, 16]

  if (support.type === 'pin') {
    return (
      <Group x={node.x} y={node.y} listening={false}>
        {/* Support hinge triangle */}
        <Line
          points={trianglePoints}
          closed
          fill={TOKENS.panelElevated}
          stroke={TOKENS.accent}
          strokeWidth={1.5}
        />
        {/* Pin joint dot */}
        <Circle x={0} y={0} radius={2} fill={TOKENS.accent} />
        {/* Ground base line */}
        <Line points={[-13, 16, 13, 16]} stroke={TOKENS.textMuted} strokeWidth={1.8} />
        {/* Ground hatch ticks */}
        <Line points={[-10, 21, -6, 16]} stroke={TOKENS.textMuted} strokeWidth={1.2} />
        <Line points={[-4, 21, 0, 16]} stroke={TOKENS.textMuted} strokeWidth={1.2} />
        <Line points={[2, 21, 6, 16]} stroke={TOKENS.textMuted} strokeWidth={1.2} />
        <Line points={[8, 21, 12, 16]} stroke={TOKENS.textMuted} strokeWidth={1.2} />
      </Group>
    )
  }

  // Roller support — rotates 90° if resisting horizontal (x)
  const rotation = support.rollerDirection === 'x' ? 90 : 0
  return (
    <Group x={node.x} y={node.y} rotation={rotation} listening={false}>
      {/* Upper triangle */}
      <Line
        points={[0, 0, -9, 13, 9, 13]}
        closed
        fill={TOKENS.panelElevated}
        stroke={TOKENS.accent2}
        strokeWidth={1.5}
      />
      {/* Joint dot */}
      <Circle x={0} y={0} radius={2} fill={TOKENS.accent2} />
      {/* Roller wheels */}
      <Circle x={-5} y={17.5} radius={3} fill={TOKENS.panelElevated} stroke={TOKENS.accent2} strokeWidth={1.4} />
      <Circle x={5} y={17.5} radius={3} fill={TOKENS.panelElevated} stroke={TOKENS.accent2} strokeWidth={1.4} />
      {/* Ground track line */}
      <Line points={[-13, 22, 13, 22]} stroke={TOKENS.textMuted} strokeWidth={1.8} />
      {/* Ground hatch ticks */}
      <Line points={[-10, 27, -6, 22]} stroke={TOKENS.textMuted} strokeWidth={1.2} />
      <Line points={[-4, 27, 0, 22]} stroke={TOKENS.textMuted} strokeWidth={1.2} />
      <Line points={[2, 27, 6, 22]} stroke={TOKENS.textMuted} strokeWidth={1.2} />
      <Line points={[8, 27, 12, 22]} stroke={TOKENS.textMuted} strokeWidth={1.2} />
    </Group>
  )
}

/**
 * Arrow showing load vector (tail at node, head along force direction).
 * Distinct rose-red vector styling with high-contrast text pill.
 */
function LoadArrow({ node, load, forceUnit }) {
  const magnitude = Math.hypot(load.fx, load.fy)
  if (magnitude === 0) return null

  const dx = (load.fx / magnitude) * LOAD_ARROW_PX
  const dy = (-load.fy / magnitude) * LOAD_ARROW_PX // +fy is up, screen y is down
  const tip = { x: node.x + dx, y: node.y + dy }
  const directionText =
    load.direction === 'inclined' ? `${fmtNum(load.angle)}°` : LOAD_DIRECTIONS[load.direction]?.label ?? ''
  const tagText = `${fmtNum(load.magnitude)} ${forceUnit} @ ${directionText}`
  const tagWidth = tagText.length * 6.5 + 8

  return (
    <Group listening={false}>
      {/* Load vector arrow */}
      <Arrow
        points={[node.x, node.y, tip.x, tip.y]}
        stroke={TOKENS.error}
        fill={TOKENS.error}
        strokeWidth={2.5}
        pointerLength={8}
        pointerWidth={8}
      />
      {/* Tag background pill */}
      <Rect
        x={tip.x + 4}
        y={tip.y - 17}
        width={tagWidth}
        height={16}
        fill={TOKENS.canvasLabel}
        stroke={TOKENS.error}
        strokeWidth={1}
        cornerRadius={3}
        opacity={0.92}
      />
      {/* Tag text */}
      <Text
        x={tip.x + 8}
        y={tip.y - 14}
        text={tagText}
        fontFamily="JetBrains Mono, monospace"
        fontSize={10}
        fontStyle="bold"
        fill={TOKENS.error}
      />
    </Group>
  )
}

const primaryButton =
  'flex-1 rounded-md bg-accent px-3 py-1.5 text-xs font-semibold text-base transition-colors hover:bg-accent/80'
const secondaryButton =
  'flex-1 rounded-md border border-border-subtle bg-panel px-3 py-1.5 text-xs font-medium text-text-muted transition-colors hover:bg-border-subtle hover:text-text-primary'

function parseNumber(text) {
  if (text.trim() === '') return NaN
  return Number(text)
}

/**
 * Node form: popup for placing a node by relative offset from an existing node.
 */
function NodeForm({ nodes, lengthUnit, onPlace, onCancel }) {
  const isFirst = nodes.length === 0
  const [refId, setRefId] = useState(nodes.length > 0 ? nodes[nodes.length - 1].id : '')
  const [dxText, setDxText] = useState('')
  const [dyText, setDyText] = useState('')
  const [error, setError] = useState('')

  function submit() {
    if (isFirst) return onPlace(null, 0, 0)
    const dx = parseNumber(dxText)
    const dy = parseNumber(dyText)
    if (!Number.isFinite(dx) || !Number.isFinite(dy)) {
      setError('Enter both distances (use 0 if no offset).')
      return
    }
    if (dx === 0 && dy === 0) {
      setError('Both distances are 0 — node would sit on top of reference node.')
      return
    }
    onPlace(refId, dx, dy)
  }

  return (
    <div className="flex w-64 flex-col gap-3 text-xs font-ui">
      {isFirst ? (
        <p className="text-text-muted leading-relaxed">
          This is the first node — it becomes origin <span className="font-technical font-semibold text-text-primary">(0, 0)</span>. Every other node is measured from a node you choose.
        </p>
      ) : (
        <>
          <label className="flex flex-col gap-1">
            <span className="text-[11px] font-medium text-text-muted">Measured from node</span>
            <select
              value={refId}
              onChange={(e) => setRefId(e.target.value)}
              className={selectClass}
            >
              {nodes.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.id}
                </option>
              ))}
            </select>
          </label>
          <label className="flex flex-col gap-1">
            <span className="text-[11px] font-medium text-text-muted">Horizontal distance ({lengthUnit}, → +)</span>
            <input
              type="number"
              step="any"
              value={dxText}
              onChange={(e) => setDxText(e.target.value)}
              className={inputClass}
              autoFocus
            />
          </label>
          <label className="flex flex-col gap-1">
            <span className="text-[11px] font-medium text-text-muted">Vertical distance ({lengthUnit}, ↑ +)</span>
            <input
              type="number"
              step="any"
              value={dyText}
              onChange={(e) => setDyText(e.target.value)}
              className={inputClass}
            />
          </label>
        </>
      )}
      {error && (
        <div className="rounded-lg border border-error/40 bg-error/15 p-2 text-[11px] text-error font-medium leading-tight">
          {error}
        </div>
      )}
      <div className="mt-1 flex gap-2">
        <button type="button" className={primaryButton} onClick={submit}>
          Place node
        </button>
        <button type="button" className={secondaryButton} onClick={onCancel}>
          Cancel
        </button>
      </div>
    </div>
  )
}

/** Load form: magnitude + direction (+ angle when inclined). */
function LoadForm({ existing, forceUnit, onApply, onCancel }) {
  const [magnitudeText, setMagnitudeText] = useState(existing ? String(existing.magnitude) : '')
  const [direction, setDirection] = useState(existing?.direction ?? 'down')
  const [angleText, setAngleText] = useState(
    existing?.direction === 'inclined' ? String(existing.angle) : '',
  )
  const [error, setError] = useState('')

  function submit() {
    const magnitude = parseNumber(magnitudeText)
    if (!Number.isFinite(magnitude) || magnitude <= 0) {
      setError('Magnitude must be greater than 0.')
      return
    }
    let angle = 0
    if (direction === 'inclined') {
      angle = parseNumber(angleText)
      if (!Number.isFinite(angle) || angle < 0 || angle > 360) {
        setError('Angle must be between 0° and 360°.')
        return
      }
    }
    onApply({ magnitude, direction, angle })
  }

  return (
    <div className="flex w-64 flex-col gap-3 text-xs font-ui">
      <label className="flex flex-col gap-1">
        <span className="text-[11px] font-medium text-text-muted">Magnitude ({forceUnit})</span>
        <input
          type="number"
          step="any"
          value={magnitudeText}
          onChange={(e) => setMagnitudeText(e.target.value)}
          className={inputClass}
          autoFocus
        />
      </label>
      <label className="flex flex-col gap-1">
        <span className="text-[11px] font-medium text-text-muted">Direction</span>
        <select
          value={direction}
          onChange={(e) => setDirection(e.target.value)}
          className={selectClass}
        >
          {Object.entries(LOAD_DIRECTIONS).map(([key, { label }]) => (
            <option key={key} value={key}>
              {label}
            </option>
          ))}
        </select>
      </label>
      {direction === 'inclined' && (
        <label className="flex flex-col gap-1">
          <span className="text-[11px] font-medium text-text-muted">Angle (°, 0–360)</span>
          <input
            type="number"
            step="any"
            value={angleText}
            onChange={(e) => setAngleText(e.target.value)}
            className={inputClass}
          />
          <p className="text-[10px] text-text-muted/80">
            Counterclockwise from +x (→ = 0°, ↑ = 90°, ← = 180°, ↓ = 270°).
          </p>
        </label>
      )}
      {error && (
        <div className="rounded-lg border border-error/40 bg-error/15 p-2 text-[11px] text-error font-medium leading-tight">
          {error}
        </div>
      )}
      <div className="mt-1 flex gap-2">
        <button type="button" className={primaryButton} onClick={submit}>
          Apply
        </button>
        <button type="button" className={secondaryButton} onClick={onCancel}>
          Cancel
        </button>
      </div>
    </div>
  )
}

function clampPopup(x, y, width, height, size) {
  return {
    left: Math.max(4, Math.min(x + 14, size.width - width - 4)),
    top: Math.max(4, Math.min(y - 10, size.height - height - 4)),
  }
}

/**
 * Wraps the solved section-cut result box so it can be dragged (mouse or touch, from
 * anywhere on the box except its button). The box keeps its default position and
 * styling; dragging only adds a translate on top of it, kept fully inside the canvas
 * area. The offset belongs to one result (`resetKey`): a new solve gives a new key,
 * so the box returns to its default spot.
 */
function DraggableNote({ resetKey, size, className, style, children }) {
  const ref = useRef(null)
  const session = useRef(null)
  const [drag, setDrag] = useState({ key: resetKey, dx: 0, dy: 0 })
  const offset = drag.key === resetKey ? drag : { dx: 0, dy: 0 }

  // Largest allowed offset on each axis so the whole box stays inside its container.
  function clampOffset(dx, dy) {
    const el = ref.current
    const parent = el?.offsetParent
    if (!el || !parent) return { dx, dy }
    const minDx = -el.offsetLeft
    const minDy = -el.offsetTop
    const maxDx = Math.max(minDx, parent.clientWidth - el.offsetWidth - el.offsetLeft)
    const maxDy = Math.max(minDy, parent.clientHeight - el.offsetHeight - el.offsetTop)
    return { dx: Math.min(maxDx, Math.max(minDx, dx)), dy: Math.min(maxDy, Math.max(minDy, dy)) }
  }

  // If the canvas shrinks (window resize, sidebar opening) keep a dragged box on-screen.
  useLayoutEffect(() => {
    if (drag.key !== resetKey || (drag.dx === 0 && drag.dy === 0)) return
    const next = clampOffset(drag.dx, drag.dy)
    if (next.dx !== drag.dx || next.dy !== drag.dy) setDrag({ key: resetKey, ...next })
  }, [size.width, size.height]) // eslint-disable-line react-hooks/exhaustive-deps

  function onPointerDown(event) {
    if (event.pointerType === 'mouse' && event.button !== 0) return
    if (event.target.closest('button')) return
    event.currentTarget.setPointerCapture(event.pointerId)
    session.current = {
      id: event.pointerId,
      x: event.clientX,
      y: event.clientY,
      dx: offset.dx,
      dy: offset.dy,
    }
  }

  function onPointerMove(event) {
    const start = session.current
    if (!start || start.id !== event.pointerId) return
    const next = clampOffset(start.dx + event.clientX - start.x, start.dy + event.clientY - start.y)
    setDrag({ key: resetKey, ...next })
  }

  function endDrag(event) {
    if (session.current?.id !== event.pointerId) return
    session.current = null
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId)
    }
  }

  return (
    <div
      ref={ref}
      className={`${className} cursor-grab active:cursor-grabbing`}
      style={{
        ...style,
        transform: offset.dx || offset.dy ? `translate(${offset.dx}px, ${offset.dy}px)` : undefined,
        touchAction: 'none',
      }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
    >
      {children}
    </div>
  )
}

/**
 * `size` is the canvas slot's FINAL pixel size, measured by App. It is passed in
 * rather than measured here on purpose: while the sidebar slides open or shut,
 * this component's own box changes width on every animation frame, and
 * re-measuring it would resize and fully redraw the Konva stage ~60 times a
 * second. App knows the slot's end size up front, so the stage is resized once
 * and the (overflow-hidden) container simply reveals or clips it as it animates.
 */
function TrussCanvas({ size, glide }) {
  const stageLayerRef = useRef(null)
  const [hoveredNodeId, setHoveredNodeId] = useState(null)

  const model = useTrussStore((state) => state.model)
  const mode = useTrussStore((state) => state.mode)
  const units = useTrussStore((state) => state.units)
  const pendingMemberNodeId = useTrussStore((state) => state.pendingMemberNodeId)
  const inlineEditor = useTrussStore((state) => state.inlineEditor)
  const handleStageClick = useTrussStore((state) => state.handleStageClick)
  const handleNodeClick = useTrussStore((state) => state.handleNodeClick)
  const addNodeFromForm = useTrussStore((state) => state.addNodeFromForm)
  const applySupport = useTrussStore((state) => state.applySupport)
  const applyLoad = useTrussStore((state) => state.applyLoad)
  const closeInlineEditor = useTrussStore((state) => state.closeInlineEditor)
  const pendingCutPoint = useTrussStore((state) => state.pendingCutPoint)
  const cutLine = useTrussStore((state) => state.cutLine)
  const sectionResult = useTrussStore((state) => state.sectionResult)
  const sectionModel = useTrussStore((state) => state.sectionModel)
  const results = useTrussStore((state) => state.results)
  const reactions = useTrussStore((state) => state.reactions)
  const fbdOverlay = useTrussStore((state) => state.fbdOverlay)
  const setFbdOverlay = useTrussStore((state) => state.setFbdOverlay)
  const addCutPoint = useTrussStore((state) => state.addCutPoint)
  const clearCut = useTrussStore((state) => state.clearCut)

  // Sidebar toggle: the stage is resized once to its final width, so play the truss's
  // jump back as a transform glide (compositor-only) matching the sidebar's timing.
  const lastGlideId = useRef(glide?.id ?? 0)
  useEffect(() => {
    if (!glide || glide.id === lastGlideId.current) return
    lastGlideId.current = glide.id
    const layer = stageLayerRef.current
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    if (!layer?.animate || reduced || !glide.from) return
    layer.animate(
      [{ transform: `translateX(${glide.from}px)` }, { transform: 'translateX(0)' }],
      { duration: glide.duration, easing: glide.easing },
    )
  }, [glide?.id]) // eslint-disable-line react-hooks/exhaustive-deps

  const lengthUnit = units?.length ?? ''
  const forceUnit = units?.force ?? ''

  // Real-unit positions derived from typed distances, scaled for display
  const layout = computeLayout(model)
  const view = computeView(layout, size.width, size.height)
  const screenPos = (nodeId) => (layout[nodeId] ? view.toScreen(layout[nodeId]) : null)

  // Identify coincident nodes (nodes that share identical coordinates)
  const coincidentNodeIds = findCoincidentNodeIds(model, layout)

  function onStageClick(e) {
    const stage = e.target.getStage()
    if (e.target !== stage) return
    const pos = stage.getPointerPosition()
    if (!pos) return

    if (mode === 'sectionCut') {
      addCutPoint({ screen: pos, model: view.toModel(pos) })
      return
    }
    handleStageClick(pos)
  }

  const editorNodeScreen = inlineEditor?.nodeId ? screenPos(inlineEditor.nodeId) : null

  const sectionIsCurrent = sectionResult !== null && sectionModel === model
  const liveSection = sectionIsCurrent ? sectionResult : null
  const crossedIds = new Set(liveSection?.ok ? liveSection.crossedMemberIds : [])
  const hasResults = Object.keys(results).length > 0

  const cutScreen = cutLine
    ? { start: view.toScreen(cutLine.start.model), end: view.toScreen(cutLine.end.model) }
    : null
  const cutAnchor = cutScreen
    ? cutScreen.start.y <= cutScreen.end.y
      ? cutScreen.start
      : cutScreen.end
    : null

  // Free body diagram overlay: built from the existing results / reactions / model only.
  const fbdScene = fbdOverlay ? overlayScene({ model, screenPos, results, reactions, units }) : null

  const nodeScreens = model.nodes.map((node) => screenPos(node.id)).filter(Boolean)
  function noteStyle(width, estimatedHeight) {
    const anchor = cutAnchor
    const fallback = clampPopup(anchor.x, anchor.y, width, estimatedHeight, size)
    if (nodeScreens.length === 0) return fallback
    const margin = 36
    const trussTop = Math.min(...nodeScreens.map((p) => p.y)) - margin
    const trussBottom = Math.max(...nodeScreens.map((p) => p.y)) + margin
    const roomAbove = trussTop
    const roomBelow = size.height - trussBottom
    const fitsAbove = roomAbove >= estimatedHeight + 8
    const fitsBelow = roomBelow >= estimatedHeight + 8
    if (!fitsAbove && !fitsBelow) return fallback
    const left = Math.max(4, Math.min(anchor.x - width / 2, size.width - width - 4))
    const above = fitsAbove && (!fitsBelow || roomAbove >= roomBelow)
    return above
      ? { left, bottom: size.height - trussTop + 4 }
      : { left, top: trussBottom + 4 }
  }

  return (
    <div
      className="relative h-full w-full min-w-0 select-none overflow-hidden bg-panel"
      style={{
        backgroundImage: `
          linear-gradient(to right, ${GRID_MINOR} 1px, transparent 1px),
          linear-gradient(to bottom, ${GRID_MINOR} 1px, transparent 1px),
          linear-gradient(to right, ${GRID_MAJOR} 1px, transparent 1px),
          linear-gradient(to bottom, ${GRID_MAJOR} 1px, transparent 1px)
        `,
        backgroundSize: '20px 20px, 20px 20px, 100px 100px, 100px 100px',
      }}
    >
      {/* The stage sits in an absolutely-positioned layer so its px size never
          feeds back into this container's own width (which is what stopped the
          canvas from shrinking). */}
      <div ref={stageLayerRef} className="absolute inset-0">
        <Stage width={size.width} height={size.height} onClick={onStageClick}>
          <Layer>
            {/* ─── Members ────────────────────────────────────────── */}
            {model.members.map((member) => {
              const start = screenPos(member.startNodeId)
              const end = screenPos(member.endNodeId)
              if (!start || !end) return null
              const geometry = getMemberGeometry(model, member, layout)
              const solved = results[member.id]
              const isCrossed = crossedIds.has(member.id)
              const isUnsolvedCrossed = isCrossed && !solved

              const midX = (start.x + end.x) / 2
              const midY = (start.y + end.y) / 2

              // Visual styling per member state:
              // Solved: colored by nature (tension/compression/zero-force)
              // Unsolved crossed in Sections: dashed gray
              // Default unattempted: solid slate-500
              let strokeColor = TOKENS.memberDefault
              let strokeWidth = 2.5
              let dashPattern = null

              if (solved) {
                strokeColor = forceColor(solved.nature)
                strokeWidth = 3.5
              } else if (isUnsolvedCrossed) {
                strokeColor = TOKENS.textMuted
                strokeWidth = 3
                dashPattern = [8, 5]
              }

              const geomText = `${member.id}: ${fmtNum(geometry.length)} ${lengthUnit} · ${fmtNum(geometry.angle, 1)}°`
              const geomWidth = geomText.length * 6.2 + 8
              const forceText = solved?.label ?? ''
              const forceWidth = forceText.length * 7 + 8

              return (
                <Group key={member.id} listening={false}>
                  {/* Primary member structural line */}
                  <Line
                    points={[start.x, start.y, end.x, end.y]}
                    stroke={strokeColor}
                    strokeWidth={strokeWidth}
                    dash={dashPattern}
                    lineCap="round"
                  />

                  {/* Solved Force Label (upper, prominent hierarchy) */}
                  {solved && (
                    <Group x={midX + 4} y={midY - 20}>
                      <Rect
                        x={-2}
                        y={-2}
                        width={forceWidth}
                        height={18}
                        fill={TOKENS.canvasLabel}
                        stroke={forceColor(solved.nature)}
                        strokeWidth={1}
                        cornerRadius={3}
                        opacity={0.94}
                      />
                      <Text
                        x={2}
                        y={1.5}
                        text={forceText}
                        fontFamily="JetBrains Mono, monospace"
                        fontSize={11.5}
                        fontStyle="bold"
                        fill={forceTextColor(solved.nature)}
                      />
                    </Group>
                  )}

                  {/* Unsolved Crossed Member Notice */}
                  {isUnsolvedCrossed && (
                    <Group x={midX + 4} y={midY - 20}>
                      <Rect
                        x={-2}
                        y={-2}
                        width={74}
                        height={16}
                        fill={TOKENS.canvasLabel}
                        stroke={TOKENS.warning}
                        strokeWidth={1}
                        cornerRadius={3}
                        opacity={0.9}
                      />
                      <Text
                        x={2}
                        y={1}
                        text="not solved"
                        fontFamily="JetBrains Mono, monospace"
                        fontSize={10}
                        fontStyle="italic"
                        fill={TOKENS.warning}
                      />
                    </Group>
                  )}

                  {/* Derived Length & Angle Label (stacked cleanly below force) */}
                  <Group x={midX + 4} y={solved || isUnsolvedCrossed ? midY + 4 : midY - 7}>
                    <Rect
                      x={-2}
                      y={-2}
                      width={geomWidth}
                      height={15}
                      fill={TOKENS.panel}
                      stroke={TOKENS.borderSubtle}
                      strokeWidth={1}
                      cornerRadius={3}
                      opacity={0.88}
                    />
                    <Text
                      x={2}
                      y={1}
                      text={geomText}
                      fontFamily="JetBrains Mono, monospace"
                      fontSize={9.5}
                      fill={TOKENS.textMuted}
                    />
                  </Group>
                </Group>
              )
            })}

            {/* ─── Supports ───────────────────────────────────────── */}
            {model.supports.map((support) => {
              const position = screenPos(support.nodeId)
              if (!position) return null
              return <SupportSymbol key={support.nodeId} node={position} support={support} />
            })}

            {/* ─── Loads ──────────────────────────────────────────── */}
            {model.loads.map((load) => {
              const position = screenPos(load.nodeId)
              if (!position) return null
              return <LoadArrow key={load.nodeId} node={position} load={load} forceUnit={forceUnit} />
            })}

            {/* ─── Free body diagram overlay (view-only; absent when toggled off) ─── */}
            {fbdScene && <FbdOverlay scene={fbdScene} />}

            {/* ─── Section Cut Line ───────────────────────────────── */}
            {cutScreen && (
              <Line
                points={[cutScreen.start.x, cutScreen.start.y, cutScreen.end.x, cutScreen.end.y]}
                stroke={liveSection && !liveSection.ok ? TOKENS.error : TOKENS.accent2}
                strokeWidth={2.5}
                dash={[8, 5]}
                listening={false}
              />
            )}
            {cutScreen &&
              [cutScreen.start, cutScreen.end].map((point, index) => (
                <Circle
                  key={`cut-end-${index}`}
                  x={point.x}
                  y={point.y}
                  radius={4.5}
                  fill={liveSection && !liveSection.ok ? TOKENS.error : TOKENS.accent2}
                  stroke={TOKENS.canvasLabel}
                  strokeWidth={1.5}
                  listening={false}
                />
              ))}
            {pendingCutPoint && (
              <Group listening={false}>
                <Circle
                  x={pendingCutPoint.screen.x}
                  y={pendingCutPoint.screen.y}
                  radius={9}
                  stroke={TOKENS.accent2}
                  strokeWidth={1.5}
                  dash={[3, 3]}
                  opacity={0.7}
                />
                <Circle
                  x={pendingCutPoint.screen.x}
                  y={pendingCutPoint.screen.y}
                  radius={5}
                  fill={TOKENS.accent2}
                />
              </Group>
            )}

            {/* ─── Nodes ──────────────────────────────────────────── */}
            {model.nodes.map((node) => {
              const position = screenPos(node.id)
              if (!position) return null
              const isSelected = pendingMemberNodeId === node.id
              const isHovered = hoveredNodeId === node.id
              const isCoincident = coincidentNodeIds.has(node.id)

              // Visual state resolution:
              // 1. Coincident: pulsating warning ring + bright warning fill
              // 2. Selected/Pending: accent ring halo + filled dot
              // 3. Hovered: enlarged accent highlight
              // 4. Default: elevated panel circle with crisp accent border
              let nodeFill = TOKENS.panelElevated
              let nodeStroke = TOKENS.accent
              let strokeWidth = 1.8
              let radius = NODE_RADIUS

              if (isCoincident) {
                nodeFill = TOKENS.warning
                nodeStroke = TOKENS.nodeInk
                strokeWidth = 2
              } else if (isSelected) {
                nodeFill = TOKENS.accent
                nodeStroke = TOKENS.nodeHalo
                strokeWidth = 2
              } else if (isHovered) {
                nodeFill = TOKENS.nodeHover
                nodeStroke = TOKENS.accent
                strokeWidth = 2.5
                radius = NODE_RADIUS + 1.5
              }

              const labelWidth = node.id.length * 7.5 + 8

              return (
                <Group key={node.id}>
                  {/* Coincident node warning halo */}
                  {isCoincident && (
                    <Circle
                      x={position.x}
                      y={position.y}
                      radius={14}
                      stroke={TOKENS.warning}
                      strokeWidth={2}
                      dash={[4, 2]}
                      listening={false}
                    />
                  )}

                  {/* Selected/Pending member creation halo */}
                  {isSelected && (
                    <Circle
                      x={position.x}
                      y={position.y}
                      radius={13}
                      stroke={TOKENS.accent}
                      strokeWidth={2}
                      dash={[4, 3]}
                      opacity={0.85}
                      listening={false}
                    />
                  )}

                  {/* Main Node Circle */}
                  <Circle
                    x={position.x}
                    y={position.y}
                    radius={radius}
                    fill={nodeFill}
                    stroke={nodeStroke}
                    strokeWidth={strokeWidth}
                    onClick={(e) => {
                      e.cancelBubble = true
                      handleNodeClick(node.id)
                    }}
                    onMouseEnter={(e) => {
                      e.target.getStage().container().style.cursor = 'pointer'
                      setHoveredNodeId(node.id)
                    }}
                    onMouseLeave={(e) => {
                      e.target.getStage().container().style.cursor = 'default'
                      setHoveredNodeId(null)
                    }}
                  />

                  {/* Node ID label with backdrop pill (prevents overlapping lines) */}
                  <Group x={position.x + 8} y={position.y - 19} listening={false}>
                    <Rect
                      x={-2}
                      y={-2}
                      width={labelWidth}
                      height={16}
                      fill={TOKENS.canvasLabel}
                      stroke={isCoincident ? TOKENS.warning : TOKENS.borderSubtle}
                      strokeWidth={1}
                      cornerRadius={3}
                      opacity={0.92}
                    />
                    <Text
                      x={2}
                      y={1.5}
                      text={node.id}
                      fontFamily="JetBrains Mono, monospace"
                      fontSize={10.5}
                      fontStyle="bold"
                      fill={isCoincident ? TOKENS.warning : TOKENS.textPrimary}
                    />
                  </Group>
                </Group>
              )
            })}
          </Layer>
        </Stage>
      </div>

      {/* ─── Inline Popups ────────────────────────────────────── */}
      {inlineEditor?.type === 'node' && (
        <div
          className="absolute z-20 rounded-lg border border-border-subtle bg-panel-elevated p-3 shadow-xl backdrop-blur-sm"
          style={clampPopup(inlineEditor.x, inlineEditor.y, 280, 220, size)}
        >
          <NodeForm
            key={`${inlineEditor.x}-${inlineEditor.y}-${model.nodes.length}`}
            nodes={model.nodes}
            lengthUnit={lengthUnit}
            onPlace={addNodeFromForm}
            onCancel={closeInlineEditor}
          />
        </div>
      )}

      {inlineEditor?.type === 'support' && editorNodeScreen && (
        <div
          className="absolute z-20 flex flex-col gap-1 rounded-lg border border-border-subtle bg-panel-elevated p-2 text-xs font-ui shadow-xl backdrop-blur-sm"
          style={clampPopup(editorNodeScreen.x, editorNodeScreen.y, 230, 140, size)}
        >
          <span className="px-2 py-1 text-xs font-semibold text-text-primary">
            Support type
          </span>
          <button
            type="button"
            className="rounded-md px-2.5 py-1.5 text-left text-text-primary transition-colors hover:bg-border-subtle hover:text-accent"
            onClick={() => applySupport(inlineEditor.nodeId, 'pin')}
          >
            Pin
          </button>
          <button
            type="button"
            className="rounded-md px-2.5 py-1.5 text-left text-text-primary transition-colors hover:bg-border-subtle hover:text-accent"
            onClick={() => applySupport(inlineEditor.nodeId, 'roller', 'y')}
          >
            Roller — resists vertical (y)
          </button>
          <button
            type="button"
            className="rounded-md px-2.5 py-1.5 text-left text-text-primary transition-colors hover:bg-border-subtle hover:text-accent"
            onClick={() => applySupport(inlineEditor.nodeId, 'roller', 'x')}
          >
            Roller — resists horizontal (x)
          </button>
          <button
            type="button"
            className="mt-1 rounded-md border-t border-border-subtle pt-1 px-2.5 py-1 text-left text-text-muted transition-colors hover:text-text-primary"
            onClick={closeInlineEditor}
          >
            Cancel
          </button>
        </div>
      )}

      {inlineEditor?.type === 'load' && editorNodeScreen && (
        <div
          className="absolute z-20 rounded-lg border border-border-subtle bg-panel-elevated p-3 shadow-xl backdrop-blur-sm"
          style={clampPopup(editorNodeScreen.x, editorNodeScreen.y, 280, 240, size)}
        >
          <LoadForm
            key={inlineEditor.nodeId}
            existing={model.loads.find((l) => l.nodeId === inlineEditor.nodeId)}
            forceUnit={forceUnit}
            onApply={(load) => applyLoad(inlineEditor.nodeId, load)}
            onCancel={closeInlineEditor}
          />
        </div>
      )}

      {/* ─── FBD overlay status + Undo ───────────────────────────
          Always-visible way back to the plain view while the overlay is on. */}
      {fbdOverlay && (
        <div className="absolute left-3 top-3 z-10 flex items-center gap-2 rounded-lg border border-accent/40 bg-panel-elevated/95 py-1 pl-3 pr-1 text-xs font-ui shadow-xl backdrop-blur-sm">
          <span className="font-semibold text-accent">Free body diagram</span>
          <span className="hidden text-text-muted sm:inline">
            {Object.keys(results).length > 0 ? 'loads, reactions, member forces' : 'loads and reactions'}
          </span>
          <button
            type="button"
            onClick={() => setFbdOverlay(false)}
            title="Undo — back to the plain view"
            className="flex items-center gap-1 rounded-md border border-border-subtle bg-panel px-2 py-1 font-medium text-text-muted transition-colors hover:bg-border-subtle hover:text-text-primary"
          >
            <Undo2 size={13} aria-hidden="true" />
            Undo
          </button>
        </div>
      )}

      {/* ─── Section Cut Banners / Error Toasts ────────────────── */}
      {mode === 'sectionCut' && liveSection && !liveSection.ok && cutAnchor && (
        <div
          className="pointer-events-none absolute z-20 w-72 rounded-lg border border-error/50 bg-panel-elevated/95 p-3 text-xs font-ui text-text-primary shadow-xl backdrop-blur-sm"
          style={noteStyle(288, 130)}
        >
          <p className="font-semibold text-error">This cut can&apos;t be solved</p>
          <p className="mt-1 text-text-muted leading-relaxed">{liveSection.message}</p>
          <button
            type="button"
            className="pointer-events-auto mt-2.5 rounded-md border border-error/40 bg-error/15 px-2.5 py-1 font-medium text-error transition-colors hover:bg-error/25"
            onClick={clearCut}
          >
            Clear cut
          </button>
        </div>
      )}

      {mode === 'sectionCut' && liveSection?.ok && cutAnchor && (
        <DraggableNote
          resetKey={liveSection}
          size={size}
          className="absolute z-20 w-64 rounded-lg border border-accent-2/50 bg-panel-elevated/95 p-3 text-xs font-ui text-text-primary shadow-xl backdrop-blur-sm"
          style={noteStyle(256, 100 + 16 * Object.keys(liveSection.results).length + (liveSection.unsolvedNote ? 44 : 0))}
        >
          <p className="font-semibold text-accent-2">
            Cut crosses {liveSection.crossedMemberIds.join(', ')}
          </p>
          <p className="mt-0.5 text-text-muted">
            Free body: {liveSection.sideLabel} segment ({liveSection.freeBodyNodeIds.join(', ')}).
          </p>
          <ul className="mt-2 space-y-1 font-technical">
            {Object.entries(liveSection.results).map(([memberId, result]) => (
              <li key={memberId} style={{ color: forceTextColor(result.nature) }} className="flex justify-between">
                <span className="font-semibold">{memberId}:</span>
                <span>{result.label}</span>
              </li>
            ))}
          </ul>
          {liveSection.unsolvedMemberIds.length > 0 && (
            <p className="mt-2 rounded-lg border border-warning/40 bg-warning/15 p-1.5 text-[11px] text-warning">
              Not solved: {liveSection.unsolvedMemberIds.join(', ')} (more unknowns than equations).
            </p>
          )}
          <button
            type="button"
            className="pointer-events-auto mt-2.5 rounded-md border border-border-subtle bg-panel px-2.5 py-1 font-medium text-text-muted transition-colors hover:bg-border-subtle hover:text-text-primary"
            onClick={clearCut}
          >
            Clear cut
          </button>
        </DraggableNote>
      )}

      {/* ─── Legend for Solved Force Colors ────────────────────── */}
      {hasResults && (
        <div className={`pointer-events-none absolute right-3 top-3 z-10 flex flex-col gap-1.5 rounded-lg border border-border-subtle bg-panel-elevated/95 px-3 py-2 text-xs font-ui shadow-xl backdrop-blur-sm`}>
          <span className="text-xs font-semibold text-text-primary">
            Member forces
          </span>
          <div className="flex flex-col gap-1 font-technical text-[11px]">
            <div className="flex items-center gap-2">
              <span className="inline-block h-2 w-3.5 rounded-sm bg-tension" />
              <span className="text-text-primary">Tension</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="inline-block h-2 w-3.5 rounded-sm bg-compression" />
              <span className="text-text-primary">Compression</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="inline-block h-2 w-3.5 rounded-sm bg-zero-force" />
              <span className="text-zero-force-text">Zero-force</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="inline-block h-0 w-3.5 border-t-2 border-dashed border-text-muted" />
              <span className="text-text-muted">Unsolved</span>
            </div>
          </div>
        </div>
      )}

      {/* ─── Stale Cut Notice ─────────────────────────────────── */}
      {sectionResult && !sectionIsCurrent && (
        <div className={`absolute right-3 top-3 z-10 rounded-lg border border-warning/40 bg-panel-elevated/95 px-3 py-1.5 text-xs font-medium text-warning shadow-xl backdrop-blur-sm`}>
          The truss changed — draw the cut again.
        </div>
      )}

      {/* ─── Mode Instruction Hint Toast ───────────────────────── */}
      <div className="pointer-events-none absolute bottom-3 left-3 z-10 rounded-lg border border-border-subtle bg-panel-elevated/90 px-3 py-1.5 text-xs font-ui text-text-muted shadow-xl backdrop-blur-sm">
        {mode === 'addNode' &&
          'Click the drawing to open the node form — click position is not used as a dimension.'}
        {mode === 'addMember' &&
          (pendingMemberNodeId
            ? `Select the second node to connect to ${pendingMemberNodeId}…`
            : 'Select two nodes to connect them with a member.')}
        {mode === 'addSupport' && 'Click a node to set its support.'}
        {mode === 'addLoad' && 'Click a node to enter a load (magnitude + direction).'}
        {mode === 'sectionCut' &&
          (pendingCutPoint
            ? 'Click the second point to finish the cut.'
            : 'Click two points to draw a cut. It must cross at least 3 members.')}
      </div>
    </div>
  )
}

export default TrussCanvas
