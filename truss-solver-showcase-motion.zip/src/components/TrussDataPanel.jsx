import { Fragment, useEffect, useState } from 'react'
import { checkDeterminacy, isReferenced, LOAD_DIRECTIONS } from '../models/trussModel.js'
import { computeLayout, findCoincidentNodeIds, getMemberGeometry } from '../models/layoutEngine.js'
import { fmtNum } from '../utils/format.js'
import useTrussStore from '../store/trussStore.js'
import { Trash2, Check, AlertCircle, Plus } from 'lucide-react'
import { inputClass, selectClass } from './controlStyles.js'

const addButtonClass =
  'mt-2.5 flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-border-subtle bg-panel py-1.5 text-xs font-medium text-text-muted transition-colors hover:border-accent/40 hover:bg-panel-elevated hover:text-text-primary disabled:cursor-not-allowed disabled:opacity-30'
const thClass = 'px-2 pb-1.5 text-left font-ui text-[11px] font-semibold text-text-muted'
const tdClass = 'px-2 py-1.5'
const sectionTitleClass = 'font-ui text-xs font-semibold text-text-primary'

/**
 * Reusable two-step confirmation delete button with tooltip explanation
 * when an item is protected from deletion.
 */
function DeleteButton({ onDelete, disabled, disabledReason, title = 'Delete' }) {
  const [confirming, setConfirming] = useState(false)

  useEffect(() => {
    if (!confirming) return
    const timer = setTimeout(() => setConfirming(false), 2500)
    return () => clearTimeout(timer)
  }, [confirming])

  if (disabled) {
    return (
      <button
        type="button"
        disabled
        title={disabledReason || 'Cannot delete this item'}
        className="rounded-md p-1 text-text-muted/30 cursor-not-allowed transition-colors"
      >
        <Trash2 size={13} />
      </button>
    )
  }

  if (confirming) {
    return (
      <button
        type="button"
        title="Click again to confirm delete"
        onClick={() => {
          setConfirming(false)
          onDelete()
        }}
        className="flex items-center gap-1 rounded-md bg-error/20 px-1.5 py-0.5 text-[11px] font-semibold text-error hover:bg-error/30 transition-colors animate-pulse"
      >
        <Check size={12} />
        <span>Delete?</span>
      </button>
    )
  }

  return (
    <button
      type="button"
      title={title}
      onClick={() => setConfirming(true)}
      className="rounded-md p-1 text-text-muted hover:bg-error/15 hover:text-error transition-colors"
    >
      <Trash2 size={13} />
    </button>
  )
}

/**
 * A number field that lets the user type freely and commits on valid input.
 */
function NumberField({ value, onCommit, min, max, disabled, hasError }) {
  const [text, setText] = useState(String(value))
  const [focused, setFocused] = useState(false)

  useEffect(() => {
    if (!focused) setText(String(value))
  }, [value, focused])

  return (
    <input
      type="number"
      step="any"
      className={`${inputClass} ${
        hasError ? 'border-error bg-error/10 text-error' : ''
      }`}
      value={text}
      disabled={disabled}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      onChange={(e) => {
        setText(e.target.value)
        if (e.target.value.trim() === '') return
        const n = Number(e.target.value)
        if (!Number.isFinite(n)) return
        if (min !== undefined && n < min) return
        if (max !== undefined && n > max) return
        onCommit(n)
      }}
    />
  )
}

function DeterminacyBadge({ model }) {
  const { m, j, r, status } = checkDeterminacy(model)
  const isDet = status === 'determinate'
  const isIndet = status === 'indeterminate'

  const borderBgText = isDet
    ? 'border-accent/40 bg-accent/10 text-accent'
    : isIndet
      ? 'border-warning/40 bg-warning/15 text-warning'
      : 'border-error/40 bg-error/15 text-error'

  const description = isDet
    ? 'Static equilibrium equations can solve all forces (m + r = 2j)'
    : isIndet
      ? 'More unknowns than equilibrium equations (m + r > 2j)'
      : 'Truss is unstable and can move under load (m + r < 2j)'

  return (
    <div className={`rounded-lg border p-3 font-ui text-xs ${borderBgText}`}>
      <div className="flex items-center justify-between font-semibold">
        <span className="flex items-center gap-1.5">
          {isDet ? (
            <Check size={13} aria-hidden="true" />
          ) : (
            <AlertCircle size={13} aria-hidden="true" />
          )}
          {isDet ? 'Determinate' : isIndet ? 'Indeterminate' : 'Unstable'}
        </span>
        <span className="font-technical text-[11px] opacity-80">
          m={m} · j={j} · r={r} · 2j={2 * j}
        </span>
      </div>
      <p className="mt-1 text-[11px] opacity-85 leading-relaxed">{description}</p>
    </div>
  )
}

function NodesTable({ model, units, updateNode, deleteNode, addBlankNode }) {
  const layout = computeLayout(model)
  const coincident = findCoincidentNodeIds(model, layout)
  const u = units?.length ?? ''

  return (
    <section>
      <div className="flex items-baseline justify-between">
        <h2 className={sectionTitleClass}>Nodes</h2>
        <span className="font-technical text-[11px] text-text-muted">{model.nodes.length} nodes</span>
      </div>
      <p className="mt-0.5 text-xs text-text-muted">
        Δx → and Δy ↑ are entered relative to the referenced node.
      </p>

      <div className="mt-2 overflow-hidden rounded-lg border border-border-subtle bg-panel shadow-sm">
        <table className="w-full border-collapse text-xs">
          <thead>
            <tr className="border-b border-border-subtle bg-panel-elevated/80">
              <th className={thClass}>Node</th>
              <th className={thClass}>From</th>
              <th className={thClass}>Δx ({u})</th>
              <th className={thClass}>Δy ({u})</th>
              <th className={`${thClass} w-8`}></th>
            </tr>
          </thead>
          <tbody>
            {model.nodes.map((node, index) => {
              const position = layout[node.id]
              const referenced = isReferenced(model, node.id)
              const isFirst = index === 0
              const isCoincident = coincident.has(node.id)
              const rowBg = index % 2 === 0 ? 'bg-panel/40' : 'bg-panel-elevated/30'

              return (
                <Fragment key={node.id}>
                  <tr className={`border-b border-border-subtle/40 ${rowBg} hover:bg-panel-elevated/70 transition-colors`}>
                    <td className={`${tdClass} font-technical font-semibold text-text-primary`}>
                      {node.id}
                    </td>
                    <td className={tdClass}>
                      {isFirst ? (
                        <span className="font-ui text-xs text-text-muted/70 italic">origin (0,0)</span>
                      ) : (
                        <select
                          className={selectClass}
                          value={node.refNodeId ?? ''}
                          onChange={(e) => updateNode(node.id, { refNodeId: e.target.value })}
                        >
                          {model.nodes.slice(0, index).map((n) => (
                            <option key={n.id} value={n.id}>
                              {n.id}
                            </option>
                          ))}
                        </select>
                      )}
                    </td>
                    <td className={tdClass}>
                      <NumberField
                        value={node.dx}
                        disabled={isFirst}
                        onCommit={(n) => updateNode(node.id, { dx: n })}
                      />
                    </td>
                    <td className={tdClass}>
                      <NumberField
                        value={node.dy}
                        disabled={isFirst}
                        onCommit={(n) => updateNode(node.id, { dy: n })}
                      />
                    </td>
                    <td className={`${tdClass} text-center`}>
                      <DeleteButton
                        onDelete={() => deleteNode(node.id)}
                        disabled={referenced}
                        disabledReason={
                          referenced
                            ? `Cannot delete ${node.id}: other nodes are measured from it. Re-reference or delete those first.`
                            : undefined
                        }
                        title={`Delete node ${node.id}`}
                      />
                    </td>
                  </tr>
                  <tr className={`border-b border-border-subtle/40 ${rowBg} text-[11px]`}>
                    <td colSpan={5} className="px-2 pb-1.5 pt-0">
                      <div className="flex flex-wrap items-center gap-2 text-text-muted font-technical">
                        <span>
                          coord: ({fmtNum(position?.x ?? 0)}, {fmtNum(position?.y ?? 0)}) {u}
                        </span>
                        {isCoincident && (
                          <span className="flex items-center gap-1 font-ui font-medium text-warning">
                            <AlertCircle size={11} /> Coincident with another node — enter Δx / Δy
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                </Fragment>
              )
            })}
          </tbody>
        </table>
      </div>

      <button type="button" className={addButtonClass} onClick={addBlankNode}>
        <Plus size={14} />
        <span>Add Node</span>
      </button>
    </section>
  )
}

function MembersTable({ model, units, updateMember, deleteMember, addBlankMember }) {
  const nodeIds = model.nodes.map((n) => n.id)
  const layout = computeLayout(model)
  const u = units?.length ?? ''

  return (
    <section className="mt-5">
      <div className="flex items-baseline justify-between">
        <h2 className={sectionTitleClass}>Members</h2>
        <span className="font-technical text-[11px] text-text-muted">{model.members.length} members</span>
      </div>
      <p className="mt-0.5 text-xs text-text-muted">
        Connects two nodes. Length and angle are calculated from node positions.
      </p>

      <div className="mt-2 overflow-hidden rounded-lg border border-border-subtle bg-panel shadow-sm">
        <table className="w-full border-collapse text-xs">
          <thead>
            <tr className="border-b border-border-subtle bg-panel-elevated/80">
              <th className={thClass}>Member</th>
              <th className={thClass}>Start</th>
              <th className={thClass}>End</th>
              <th className={thClass}>Length ({u})</th>
              <th className={thClass}>Angle°</th>
              <th className={`${thClass} w-8`}></th>
            </tr>
          </thead>
          <tbody>
            {model.members.map((member, index) => {
              const geometry = getMemberGeometry(model, member, layout)
              const isSelfConnected = member.startNodeId === member.endNodeId
              const isZeroLength = geometry && !isSelfConnected && geometry.length < 1e-9
              const hasError = isSelfConnected || isZeroLength
              const rowBg = index % 2 === 0 ? 'bg-panel/40' : 'bg-panel-elevated/30'

              return (
                <Fragment key={member.id}>
                  <tr className={`border-b border-border-subtle/40 ${rowBg} hover:bg-panel-elevated/70 transition-colors`}>
                    <td className={`${tdClass} font-technical font-semibold text-text-primary`}>
                      {member.id}
                    </td>
                    <td className={tdClass}>
                      <select
                        className={`${selectClass} ${isSelfConnected ? 'border-error bg-error/10 text-error' : ''}`}
                        value={member.startNodeId}
                        onChange={(e) => updateMember(member.id, { startNodeId: e.target.value })}
                      >
                        {nodeIds.map((id) => (
                          <option key={id} value={id}>
                            {id}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className={tdClass}>
                      <select
                        className={`${selectClass} ${isSelfConnected ? 'border-error bg-error/10 text-error' : ''}`}
                        value={member.endNodeId}
                        onChange={(e) => updateMember(member.id, { endNodeId: e.target.value })}
                      >
                        {nodeIds.map((id) => (
                          <option key={id} value={id}>
                            {id}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className={`${tdClass} font-technical text-text-primary`}>
                      {geometry ? fmtNum(geometry.length) : '—'}
                    </td>
                    <td className={`${tdClass} font-technical text-text-primary`}>
                      {geometry ? fmtNum(geometry.angle, 1) : '—'}
                    </td>
                    <td className={`${tdClass} text-center`}>
                      <DeleteButton
                        onDelete={() => deleteMember(member.id)}
                        title={`Delete member ${member.id}`}
                      />
                    </td>
                  </tr>
                  {hasError && (
                    <tr className={`border-b border-border-subtle/40 ${rowBg} text-[11px]`}>
                      <td colSpan={6} className="px-2 pb-1.5 pt-0">
                        {isSelfConnected && (
                          <span className="flex items-center gap-1 font-ui font-medium text-error">
                            <AlertCircle size={11} /> Cannot connect node to itself — choose two different nodes
                          </span>
                        )}
                        {isZeroLength && (
                          <span className="flex items-center gap-1 font-ui font-medium text-error">
                            <AlertCircle size={11} /> Zero-length member — start and end nodes coincide
                          </span>
                        )}
                      </td>
                    </tr>
                  )}
                </Fragment>
              )
            })}
          </tbody>
        </table>
      </div>

      <button
        type="button"
        className={addButtonClass}
        onClick={addBlankMember}
        disabled={model.nodes.length < 2}
        title={model.nodes.length < 2 ? 'Need at least 2 nodes to add a member' : undefined}
      >
        <Plus size={14} />
        <span>Add Member</span>
      </button>
    </section>
  )
}

function SupportsTable({ model, changeSupportNode, applySupport, removeSupport, addBlankSupport }) {
  const nodeIds = model.nodes.map((n) => n.id)
  const canAddMore = model.nodes.some((n) => !model.supports.some((s) => s.nodeId === n.id))

  return (
    <section className="mt-5">
      <div className="flex items-baseline justify-between">
        <h2 className={sectionTitleClass}>Supports</h2>
        <span className="font-technical text-[11px] text-text-muted">{model.supports.length} supports</span>
      </div>

      <div className="mt-2 overflow-hidden rounded-lg border border-border-subtle bg-panel shadow-sm">
        <table className="w-full border-collapse text-xs">
          <thead>
            <tr className="border-b border-border-subtle bg-panel-elevated/80">
              <th className={thClass}>Node</th>
              <th className={thClass}>Type</th>
              <th className={thClass}>Direction</th>
              <th className={`${thClass} w-8`}></th>
            </tr>
          </thead>
          <tbody>
            {model.supports.map((support, index) => {
              const rowBg = index % 2 === 0 ? 'bg-panel/40' : 'bg-panel-elevated/30'
              return (
                <tr key={support.nodeId} className={`border-b border-border-subtle/40 ${rowBg} hover:bg-panel-elevated/70 transition-colors`}>
                  <td className={tdClass}>
                    <select
                      className={selectClass}
                      value={support.nodeId}
                      onChange={(e) => changeSupportNode(support.nodeId, e.target.value)}
                    >
                      {nodeIds.map((id) => (
                        <option key={id} value={id}>
                          {id}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className={tdClass}>
                    <select
                      className={selectClass}
                      value={support.type}
                      onChange={(e) =>
                        applySupport(
                          support.nodeId,
                          e.target.value,
                          e.target.value === 'roller' ? support.rollerDirection || 'y' : undefined,
                        )
                      }
                    >
                      <option value="pin">Pin (Rx, Ry)</option>
                      <option value="roller">Roller</option>
                    </select>
                  </td>
                  <td className={tdClass}>
                    {support.type === 'roller' ? (
                      <select
                        className={selectClass}
                        value={support.rollerDirection || 'y'}
                        onChange={(e) => applySupport(support.nodeId, 'roller', e.target.value)}
                      >
                        <option value="y">y (resists vertical)</option>
                        <option value="x">x (resists horizontal)</option>
                      </select>
                    ) : (
                      <span className="font-technical text-text-muted/60 pl-2">x + y</span>
                    )}
                  </td>
                  <td className={`${tdClass} text-center`}>
                    <DeleteButton
                      onDelete={() => removeSupport(support.nodeId)}
                      title={`Remove support at ${support.nodeId}`}
                    />
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      <button
        type="button"
        className={addButtonClass}
        onClick={addBlankSupport}
        disabled={!canAddMore}
        title={!canAddMore ? 'All existing nodes already have supports' : undefined}
      >
        <Plus size={14} />
        <span>Add Support</span>
      </button>
    </section>
  )
}

function LoadsTable({ model, units, changeLoadNode, applyLoad, removeLoad, addBlankLoad }) {
  const nodeIds = model.nodes.map((n) => n.id)
  const canAddMore = model.nodes.some((n) => !model.loads.some((l) => l.nodeId === n.id))
  const f = units?.force ?? ''

  return (
    <section className="mt-5">
      <div className="flex items-baseline justify-between">
        <h2 className={sectionTitleClass}>Loads</h2>
        <span className="font-technical text-[11px] text-text-muted">{model.loads.length} loads</span>
      </div>
      <p className="mt-0.5 text-xs text-text-muted">
        Nodal point loads. Inclined angles are measured counterclockwise from +x (0–360°).
      </p>

      <div className="mt-2 overflow-hidden rounded-lg border border-border-subtle bg-panel shadow-sm">
        <table className="w-full border-collapse text-xs">
          <thead>
            <tr className="border-b border-border-subtle bg-panel-elevated/80">
              <th className={thClass}>Node</th>
              <th className={thClass}>Magnitude ({f})</th>
              <th className={thClass}>Direction</th>
              <th className={thClass}>Angle°</th>
              <th className={`${thClass} w-8`}></th>
            </tr>
          </thead>
          <tbody>
            {model.loads.map((load, index) => {
              const inclined = load.direction === 'inclined'
              const magError = !Number.isFinite(load.magnitude) || load.magnitude <= 0
              const angleError = inclined && (!Number.isFinite(load.angle) || load.angle < 0 || load.angle > 360)
              const hasError = magError || angleError
              const rowBg = index % 2 === 0 ? 'bg-panel/40' : 'bg-panel-elevated/30'

              const update = (changes) =>
                applyLoad(load.nodeId, {
                  magnitude: load.magnitude,
                  direction: load.direction,
                  angle: load.angle,
                  ...changes,
                })

              return (
                <Fragment key={load.nodeId}>
                  <tr className={`border-b border-border-subtle/40 ${rowBg} hover:bg-panel-elevated/70 transition-colors`}>
                    <td className={tdClass}>
                      <select
                        className={selectClass}
                        value={load.nodeId}
                        onChange={(e) => changeLoadNode(load.nodeId, e.target.value)}
                      >
                        {nodeIds.map((id) => (
                          <option key={id} value={id}>
                            {id}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className={tdClass}>
                      <NumberField
                        value={load.magnitude}
                        min={0}
                        hasError={magError}
                        onCommit={(n) => update({ magnitude: n })}
                      />
                    </td>
                    <td className={tdClass}>
                      <select
                        className={selectClass}
                        value={load.direction}
                        onChange={(e) =>
                          update({
                            direction: e.target.value,
                            angle: e.target.value === 'inclined' ? load.angle : 0,
                          })
                        }
                      >
                        {Object.entries(LOAD_DIRECTIONS).map(([key, { label }]) => (
                          <option key={key} value={key}>
                            {label}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className={tdClass}>
                      {inclined ? (
                        <NumberField
                          value={load.angle}
                          min={0}
                          max={360}
                          hasError={angleError}
                          onCommit={(n) => update({ angle: n })}
                        />
                      ) : (
                        <span className="font-technical text-text-muted/60 pl-2">—</span>
                      )}
                    </td>
                    <td className={`${tdClass} text-center`}>
                      <DeleteButton
                        onDelete={() => removeLoad(load.nodeId)}
                        title={`Remove load at node ${load.nodeId}`}
                      />
                    </td>
                  </tr>
                  <tr className={`border-b border-border-subtle/40 ${rowBg} text-[11px]`}>
                    <td colSpan={5} className="px-2 pb-1.5 pt-0">
                      <div className="flex flex-wrap items-center gap-3 font-technical text-text-muted">
                        <span>Fx = {fmtNum(load.fx)} {f}</span>
                        <span>Fy = {fmtNum(load.fy)} {f}</span>
                        {magError && (
                          <span className="flex items-center gap-1 font-ui font-medium text-error">
                            <AlertCircle size={11} /> Magnitude must be greater than 0
                          </span>
                        )}
                        {angleError && (
                          <span className="flex items-center gap-1 font-ui font-medium text-error">
                            <AlertCircle size={11} /> Angle must be between 0° and 360°
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                </Fragment>
              )
            })}
          </tbody>
        </table>
      </div>

      <button
        type="button"
        className={addButtonClass}
        onClick={addBlankLoad}
        disabled={!canAddMore}
        title={!canAddMore ? 'All existing nodes already have loads' : undefined}
      >
        <Plus size={14} />
        <span>Add Load</span>
      </button>
    </section>
  )
}

/**
 * Main TrussDataPanel component.
 */
function TrussDataPanel() {
  const model = useTrussStore((state) => state.model)
  const units = useTrussStore((state) => state.units)
  const updateNode = useTrussStore((state) => state.updateNode)
  const deleteNode = useTrussStore((state) => state.deleteNode)
  const addBlankNode = useTrussStore((state) => state.addBlankNode)
  const updateMember = useTrussStore((state) => state.updateMember)
  const deleteMember = useTrussStore((state) => state.deleteMember)
  const addBlankMember = useTrussStore((state) => state.addBlankMember)
  const changeSupportNode = useTrussStore((state) => state.changeSupportNode)
  const applySupport = useTrussStore((state) => state.applySupport)
  const removeSupport = useTrussStore((state) => state.removeSupport)
  const addBlankSupport = useTrussStore((state) => state.addBlankSupport)
  const changeLoadNode = useTrussStore((state) => state.changeLoadNode)
  const applyLoad = useTrussStore((state) => state.applyLoad)
  const removeLoad = useTrussStore((state) => state.removeLoad)
  const addBlankLoad = useTrussStore((state) => state.addBlankLoad)

  return (
    <div className="font-ui text-xs">
      <DeterminacyBadge model={model} />
      <div className="mt-4 space-y-2">
        <NodesTable
          model={model}
          units={units}
          updateNode={updateNode}
          deleteNode={deleteNode}
          addBlankNode={addBlankNode}
        />
        <MembersTable
          model={model}
          units={units}
          updateMember={updateMember}
          deleteMember={deleteMember}
          addBlankMember={addBlankMember}
        />
        <SupportsTable
          model={model}
          changeSupportNode={changeSupportNode}
          applySupport={applySupport}
          removeSupport={removeSupport}
          addBlankSupport={addBlankSupport}
        />
        <LoadsTable
          model={model}
          units={units}
          changeLoadNode={changeLoadNode}
          applyLoad={applyLoad}
          removeLoad={removeLoad}
          addBlankLoad={addBlankLoad}
        />
      </div>
    </div>
  )
}

export default TrussDataPanel
