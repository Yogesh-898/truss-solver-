import { jointStepScene, sectionStepScene } from '../utils/fbdScene.js'

/**
 * Small schematic free body diagram for ONE step card, drawn from the `fbd` metadata the
 * solver attached to that step:
 *   - kind 'joint':   only that joint, isolated, with every member / load / reaction arrow;
 *   - kind 'section': only the segment that was used as the free body, cut members as
 *                     force arrows, plus the loads and reactions inside that segment.
 * The viewBox is fitted to the drawing so nothing is clipped, and the SVG scales down to
 * the card's width (it never scales up past its natural size).
 */
function StepFbd({ fbd, units }) {
  const scene = fbd.kind === 'joint' ? jointStepScene(fbd, units) : sectionStepScene(fbd, units)
  const { bounds } = scene
  const caption =
    fbd.kind === 'joint'
      ? `Free body diagram — joint ${fbd.nodeId}`
      : 'Free body diagram — solved segment (cut members shown as forces)'

  return (
    <figure className="rounded-lg border border-border-subtle bg-base/60 px-2 pb-2 pt-1.5">
      <figcaption className="mb-1 font-ui text-[10.5px] font-medium text-text-muted">{caption}</figcaption>
      <svg
        role="img"
        aria-label={caption}
        viewBox={`${bounds.x} ${bounds.y} ${bounds.width} ${bounds.height}`}
        width={Math.min(bounds.width, 320)}
        className="mx-auto block h-auto max-h-44 w-full max-w-[320px]"
        preserveAspectRatio="xMidYMid meet"
      >
        {scene.lines.map((l, index) => (
          <line
            key={`l${index}`}
            x1={l.x1}
            y1={l.y1}
            x2={l.x2}
            y2={l.y2}
            stroke={l.color}
            strokeWidth={l.width}
            strokeDasharray={l.dash ? '4 3' : undefined}
            strokeLinecap="round"
          />
        ))}

        {scene.arrows.map((a, index) => (
          <ArrowShape key={`a${index}`} arrow={a} />
        ))}

        {scene.dots.map((d, index) => (
          <circle key={`d${index}`} cx={d.x} cy={d.y} r={d.r} fill={d.fill} stroke={d.stroke} strokeWidth={1.4} />
        ))}

        {scene.labels.map((t, index) => (
          <text
            key={`t${index}`}
            x={t.x}
            y={t.y}
            textAnchor={t.anchor}
            fontSize={t.size}
            fontWeight={t.weight}
            fill={t.fill}
            fontFamily="JetBrains Mono, monospace"
          >
            {t.text.split('\n').map((line, lineIndex) => (
              <tspan key={lineIndex} x={t.x} dy={lineIndex === 0 ? 0 : t.size + 1}>
                {line}
              </tspan>
            ))}
          </text>
        ))}
      </svg>
    </figure>
  )
}

/** A line with an explicit triangular head (drawn by hand: no marker support needed). */
function ArrowShape({ arrow }) {
  const { x1, y1, x2, y2, color, width, dash } = arrow
  const dx = x2 - x1
  const dy = y2 - y1
  const length = Math.hypot(dx, dy) || 1
  const ux = dx / length
  const uy = dy / length
  const head = 7
  const half = 3.4
  const bx = x2 - ux * head
  const by = y2 - uy * head
  const points = `${x2},${y2} ${bx - uy * half},${by + ux * half} ${bx + uy * half},${by - ux * half}`
  return (
    <g>
      <line x1={x1} y1={y1} x2={bx} y2={by} stroke={color} strokeWidth={width} strokeDasharray={dash ? '4 3' : undefined} strokeLinecap="round" />
      <polygon points={points} fill={color} />
    </g>
  )
}

export default StepFbd
