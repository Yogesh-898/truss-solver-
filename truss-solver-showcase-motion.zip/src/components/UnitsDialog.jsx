import { useEffect, useId, useRef, useState } from 'react'
import useTrussStore from '../store/trussStore.js'

const LENGTH_UNITS = ['m', 'mm']
const FORCE_UNITS = ['kN', 'N']

/** Everything inside the dialog that can take keyboard focus. */
const FOCUSABLE = 'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'

function Choice({ options, value, onChange, labelledBy }) {
  // The pop only plays for an option the user just picked, never for the option that is
  // already selected when the dialog opens (that would fight the dialog's own entrance).
  const [picked, setPicked] = useState(null)
  return (
    <div className="flex gap-2" role="group" aria-labelledby={labelledBy}>
      {options.map((option) => (
        <button
          key={option}
          type="button"
          aria-pressed={value === option}
          onClick={() => {
            setPicked(option)
            onChange(option)
          }}
          className={`flex-1 rounded-md border py-2 text-xs font-technical font-semibold transition-colors ${
            value === option
              ? `border-accent bg-accent/15 text-accent ring-1 ring-accent/30 ${
                  picked === option ? 'animate-unit-select motion-reduce:animate-none' : ''
                }`
              : 'border-border-subtle bg-panel text-text-muted hover:border-text-muted/60 hover:text-text-primary'
          }`}
        >
          {option}
        </button>
      ))}
    </div>
  )
}

/**
 * Centered modal over a dimmed, translucent backdrop.
 */
function UnitsDialog() {
  const units = useTrussStore((state) => state.units)
  const open = useTrussStore((state) => state.unitsDialogOpen)
  const setUnits = useTrussStore((state) => state.setUnits)
  const closeUnitsDialog = useTrussStore((state) => state.closeUnitsDialog)

  const [length, setLength] = useState(units?.length ?? 'm')
  const [force, setForce] = useState(units?.force ?? 'kN')

  const titleId = useId()
  const descriptionId = useId()
  const lengthLabelId = useId()
  const forceLabelId = useId()
  const dialogRef = useRef(null)
  const openerRef = useRef(null) // whatever had focus when the dialog opened

  // While open: move focus in, trap Tab, close on Escape, and hand focus back on close.
  useEffect(() => {
    if (!open) return undefined
    const dialog = dialogRef.current
    if (!dialog) return undefined

    // Remember the opener only if focus is still outside the dialog. (React StrictMode
    // runs this effect twice in dev; on the second run the cleanup below has already
    // handed focus back, so the opener is captured correctly both times.)
    if (!dialog.contains(document.activeElement)) {
      openerRef.current = document.activeElement
      // Land on the currently-selected option, so the dialog opens on a meaningful control.
      const target = dialog.querySelector('[aria-pressed="true"]') ?? dialog.querySelector(FOCUSABLE)
      target?.focus()
    }

    function onKeyDown(event) {
      if (event.key === 'Escape') {
        event.preventDefault()
        // The store ignores this until units have been chosen once (there is no
        // Cancel button on first run either), so Escape can't strand the app unit-less.
        closeUnitsDialog()
        return
      }
      if (event.key !== 'Tab') return

      const items = [...dialog.querySelectorAll(FOCUSABLE)].filter((el) => el.getClientRects().length > 0)
      if (items.length === 0) {
        event.preventDefault()
        return
      }
      const first = items[0]
      const last = items[items.length - 1]
      const outside = !dialog.contains(document.activeElement)
      if (event.shiftKey && (outside || document.activeElement === first)) {
        event.preventDefault()
        last.focus()
      } else if (!event.shiftKey && (outside || document.activeElement === last)) {
        event.preventDefault()
        first.focus()
      }
    }

    // On document, not on the overlay, so Tab/Escape still work if focus was lost to <body>.
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('keydown', onKeyDown)
      const opener = openerRef.current
      openerRef.current = null
      if (opener && opener !== document.body && opener.isConnected) opener.focus({ preventScroll: true })
    }
  }, [open, closeUnitsDialog])

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-base/60 backdrop-blur-sm p-4 animate-dialog-backdrop-in motion-reduce:animate-none">
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={descriptionId}
        className="w-full max-w-sm rounded-lg border border-border-subtle bg-panel-elevated/95 p-6 shadow-xl backdrop-blur-md font-ui animate-dialog-panel-in motion-reduce:animate-none"
      >
        <h2 id={titleId} className="text-base font-semibold text-text-primary">Choose your units</h2>
        <p id={descriptionId} className="mt-1 text-xs text-text-muted leading-relaxed">
          Every distance and force you type will be measured in these units.
        </p>

        <div className="mt-5 space-y-4">
          <div>
            <p id={lengthLabelId} className="mb-1.5 text-xs font-semibold text-text-primary">
              Length
            </p>
            <Choice options={LENGTH_UNITS} value={length} onChange={setLength} labelledBy={lengthLabelId} />
          </div>

          <div>
            <p id={forceLabelId} className="mb-1.5 text-xs font-semibold text-text-primary">
              Force
            </p>
            <Choice options={FORCE_UNITS} value={force} onChange={setForce} labelledBy={forceLabelId} />
          </div>
        </div>

        <div className="mt-6 flex gap-2.5">
          <button
            type="button"
            onClick={() => setUnits({ length, force })}
            className="flex-1 rounded-md bg-accent py-2 text-xs font-semibold text-base transition-colors hover:bg-accent/80"
          >
            Continue
          </button>
          {units && (
            <button
              type="button"
              onClick={closeUnitsDialog}
              className="rounded-md border border-border-subtle bg-panel px-4 py-2 text-xs font-medium text-text-muted transition-colors hover:bg-border-subtle hover:text-text-primary"
            >
              Cancel
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

export default UnitsDialog
