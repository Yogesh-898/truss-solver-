import { Arrow, Group, Rect, Text } from 'react-konva'
import { TOKENS } from '../theme/palette.js'
import { textWidth } from '../utils/fbdScene.js'

/**
 * Konva drawing of the full-truss FBD overlay. Purely presentational: it renders the
 * `scene` built by overlayScene() (src/utils/fbdScene.js) and nothing else, and is
 * mounted only while the FBD toggle is on, so toggling it off leaves nothing behind.
 * Everything is `listening={false}` so it never intercepts a canvas click.
 */
function FbdOverlay({ scene }) {
  return (
    <Group listening={false} name="fbd-overlay">
      {scene.arrows.map((a, index) => (
        <Arrow
          key={`fbd-arrow-${index}`}
          points={[a.x1, a.y1, a.x2, a.y2]}
          stroke={a.color}
          fill={a.color}
          strokeWidth={a.width}
          dash={a.dash ? [6, 4] : undefined}
          pointerLength={8}
          pointerWidth={8}
          lineCap="round"
        />
      ))}
      {scene.labels.map((l, index) => {
        const width = textWidth(l.text, l.size) + 8
        const left = l.anchor === 'start' ? l.x : l.anchor === 'end' ? l.x - width : l.x - width / 2
        return (
          <Group key={`fbd-label-${index}`} x={left} y={l.y - l.size - 2}>
            <Rect
              width={width}
              height={l.size + 6}
              fill={TOKENS.canvasLabel}
              stroke={l.stroke ?? TOKENS.borderSubtle}
              strokeWidth={1}
              cornerRadius={3}
              opacity={0.94}
            />
            <Text
              x={4}
              y={3}
              text={l.text}
              fontFamily="JetBrains Mono, monospace"
              fontSize={l.size}
              fontStyle="bold"
              fill={l.fill}
            />
          </Group>
        )
      })}
    </Group>
  )
}

export default FbdOverlay
