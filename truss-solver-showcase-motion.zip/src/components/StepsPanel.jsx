import { useEffect, useState } from 'react'
import { ChevronRight, ListOrdered } from 'lucide-react'
import useTrussStore from '../store/trussStore.js'
import SegmentedToggle from './SegmentedToggle.jsx'
import PanelEmptyState from './PanelEmptyState.jsx'
import StepFbd from './StepFbd.jsx'
import { NATURE_STYLE, splitNumericParts, splitResultByNature } from '../utils/nature.js'

const VIEWS = [
  { id: 'compact', label: 'Compact' },
  { id: 'detailed', label: 'Detailed' },
]

/** Prose with its numbers and symbols (F_m1, 0.8, 30°, 400 kN) set in monospace. */
function MathText({ text }) {
  return splitNumericParts(text).map((part, index) =>
    part.mono ? (
      <span key={index} className="font-technical text-text-primary">
        {part.text}
      </span>
    ) : (
      <span key={index}>{part.text}</span>
    ),
  )
}

/** The step's conclusion; each "member = value (T|C|zero-force)" piece takes its nature's color. */
function StepResult({ text }) {
  return (
    <p className="whitespace-pre-wrap break-words font-technical text-[13px] font-semibold leading-snug text-text-primary">
      {splitResultByNature(text).map((piece, index) =>
        piece.nature ? (
          <span key={index} className={NATURE_STYLE[piece.nature].text}>
            {piece.text}
          </span>
        ) : (
          <span key={index}>{piece.text}</span>
        ),
      )}
    </p>
  )
}

function StepNumber({ number }) {
  return (
    <span className="mt-px flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full border border-border-subtle bg-base px-1 font-technical text-[10px] font-medium text-text-muted">
      {number}
    </span>
  )
}

/**
 * The numbered worked solution from the last Solve or Section Cut. Every
 * solver produces the same step shape:
 *   { title, reasoning, equation, breakdown[], substitution, result }
 *
 * Detailed view shows every field. Compact view shows title + result only,
 * and a step's header can be clicked to open the rest (any number of steps
 * can be open; "Expand all" / "Collapse all" does them together).
 */
function StepsPanel() {
  const steps = useTrussStore((state) => state.steps)
  const solveError = useTrussStore((state) => state.solveError)
  const solveMethod = useTrussStore((state) => state.solveMethod)
  const stepsView = useTrussStore((state) => state.stepsView)
  const setStepsView = useTrussStore((state) => state.setStepsView)
  const units = useTrussStore((state) => state.units)

  const [expanded, setExpanded] = useState(() => new Set())

  // A new solve produces a new steps array; start it collapsed.
  useEffect(() => {
    setExpanded(new Set())
  }, [steps])

  if (steps.length === 0) {
    return (
      <div className="font-ui">
        {solveError && (
          <div className="mb-3 rounded-lg border border-error/40 bg-error/15 p-2.5 text-xs font-medium text-error">
            {solveError}
          </div>
        )}
        <PanelEmptyState Icon={ListOrdered}>
          {solveMethod === 'joints'
            ? 'Run Solve to see the worked steps here.'
            : 'Make a section cut to see the worked steps here.'}
        </PanelEmptyState>
      </div>
    )
  }

  const compact = stepsView === 'compact'
  const allExpanded = expanded.size === steps.length

  const toggleStep = (index) =>
    setExpanded((previous) => {
      const next = new Set(previous)
      if (next.has(index)) next.delete(index)
      else next.add(index)
      return next
    })

  const toggleAll = () =>
    setExpanded(allExpanded ? new Set() : new Set(steps.map((_step, index) => index)))

  return (
    <div className="font-ui">
      {/* Controls stay pinned while the steps scroll underneath. -top-4 / -mt-4 cancel the
          scroll area's p-4, because sticky offsets are measured from its padding. */}
      <div className="sticky -top-4 z-10 -mx-4 -mt-4 mb-3 flex items-center justify-between border-b border-border-subtle bg-panel px-4 py-2.5">
        <SegmentedToggle
          options={VIEWS}
          value={stepsView}
          onChange={setStepsView}
          ariaLabel="Steps detail level"
        />
        {compact ? (
          <button
            type="button"
            onClick={toggleAll}
            className="rounded-md px-2 py-1 text-xs font-medium text-text-muted transition-colors hover:bg-panel-elevated hover:text-text-primary"
          >
            {allExpanded ? 'Collapse all' : 'Expand all'}
          </button>
        ) : (
          <span className="font-technical text-[11px] text-text-muted">{steps.length} steps</span>
        )}
      </div>

      <ol className="space-y-3">
        {steps.map((step, index) => {
          const hasDetails =
            step.reasoning || step.equation || step.breakdown?.length > 0 || step.substitution
          const open = !compact || expanded.has(index)
          const showDetails = open && hasDetails

          const heading = (
            <>
              <StepNumber number={index + 1} />
              <span className="flex-1 text-[13px] font-semibold leading-snug text-text-primary">
                {step.title}
              </span>
            </>
          )

          const detailsId = `step-details-${index}`

          return (
            <li
              key={index}
              className="rounded-lg border border-border-subtle bg-panel-elevated shadow-sm"
            >
              {compact && hasDetails ? (
                <button
                  type="button"
                  aria-expanded={open}
                  aria-controls={detailsId}
                  onClick={() => toggleStep(index)}
                  // scroll-mt keeps a keyboard-focused header clear of the sticky controls bar
                  className="flex w-full scroll-mt-16 items-start gap-2.5 rounded-t-lg px-3 pb-2.5 pt-3 text-left transition-colors hover:bg-border-subtle/30"
                >
                  {heading}
                  <ChevronRight
                    size={15}
                    className={`mt-0.5 shrink-0 text-text-muted transition-transform duration-200 motion-reduce:transition-none ${
                      open ? 'rotate-90' : ''
                    }`}
                    aria-hidden="true"
                  />
                </button>
              ) : (
                <div className="flex items-start gap-2.5 px-3 pb-2.5 pt-3">{heading}</div>
              )}

              <div className="px-3 pb-3">
                {hasDetails && (
                  /* Height animates 0fr -> 1fr (CSS grid), which transitions to the content's
                     natural height with no measuring. The details stay mounted so they can
                     animate shut; while closed they are inert + invisible, so they are out of
                     the accessibility tree. `visibility` flips after the collapse finishes and
                     immediately on expand (it interpolates as a discrete step). */
                  <div
                    id={detailsId}
                    inert={showDetails ? undefined : ''}
                    className={`grid transition-[grid-template-rows,opacity,visibility] duration-200 ease-out motion-reduce:transition-none ${
                      showDetails ? 'visible grid-rows-[1fr] opacity-100' : 'invisible grid-rows-[0fr] opacity-0'
                    }`}
                  >
                    <div className="min-h-0 overflow-hidden">
                      <div className="space-y-3 pb-3">
                        {step.reasoning && (
                          <p className="text-xs italic leading-relaxed text-text-muted">{step.reasoning}</p>
                        )}

                        {/* Mini FBD: Detailed view only (Compact stays title + result, even when a
                            step is expanded), and only on steps the solver attached one to. */}
                        {!compact && step.fbd && <StepFbd fbd={step.fbd} units={units} />}

                        {step.equation && (
                          <p className="whitespace-pre-wrap break-words rounded-lg border border-l-2 border-border-subtle border-l-accent-2 bg-base/70 px-2.5 py-2 font-technical text-[12.5px] leading-relaxed text-text-primary">
                            {step.equation}
                          </p>
                        )}

                        {step.breakdown?.length > 0 && (
                          <ul className="list-disc space-y-1 pl-4 text-xs leading-relaxed text-text-muted marker:text-text-muted/60">
                            {step.breakdown.map((line, lineIndex) => (
                              <li key={lineIndex}>
                                <MathText text={line} />
                              </li>
                            ))}
                          </ul>
                        )}

                        {step.substitution && (
                          <p className="whitespace-pre-wrap break-words border-l-2 border-border-subtle pl-2.5 font-technical text-[11.5px] leading-relaxed text-text-muted">
                            {step.substitution}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {step.result && (
                  <div
                    className={
                      hasDetails
                        ? `border-t transition-[border-color,padding] duration-200 motion-reduce:transition-none ${
                            showDetails ? 'border-border-subtle pt-2.5' : 'border-transparent pt-0'
                          }`
                        : ''
                    }
                  >
                    <StepResult text={step.result} />
                  </div>
                )}
              </div>
            </li>
          )
        })}
      </ol>
    </div>
  )
}

export default StepsPanel
