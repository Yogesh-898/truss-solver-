import { useRef } from 'react'
import { useSlidingIndicator, indicatorStyle } from './useSlidingIndicator.js'

/**
 * The app's one "pick one of N" pill control. Used by the Joints/Sections
 * method toggle in the toolbar and the Compact/Detailed toggle in the
 * Steps panel, so both look and behave identically.
 *
 * options: [{ id, label }]
 *
 * Note: the active label color is read from the `base` color token through
 * an arbitrary property. `text-base` can't be used for this because Tailwind
 * also defines `text-base` as a 1rem font size, which would enlarge the
 * active label.
 */
function SegmentedToggle({ options, value, onChange, ariaLabel }) {
  const groupRef = useRef(null)
  const { rect, animate } = useSlidingIndicator(groupRef, value)
  const activeIndex = options.findIndex((option) => option.id === value)
  // The sliding fill keeps the old look at rest: only its outer end is rounded.
  const fillRadius =
    activeIndex === 0 ? '5px 0 0 5px' : activeIndex === options.length - 1 ? '0 5px 5px 0' : '0'

  return (
    <div
      ref={groupRef}
      className="relative flex rounded-md border border-border-subtle bg-panel-elevated font-ui"
      role="group"
      aria-label={ariaLabel}
    >
      {rect && (
        <span
          aria-hidden="true"
          className="pointer-events-none absolute bg-accent motion-reduce:!transition-none"
          style={indicatorStyle(rect, animate, { borderRadius: fillRadius })}
        />
      )}
      {options.map((option) => {
        const active = value === option.id
        return (
          <button
            key={option.id}
            type="button"
            aria-pressed={active}
            data-sliding-active={active ? '' : undefined}
            onClick={() => onChange(option.id)}
            className={[
              // No overflow-hidden on the container (it would clip the focus ring), so the
              // end segments round themselves: container radius 6px - 1px border = 5px.
              'relative px-3 py-1.5 text-xs font-medium transition-colors duration-200 first:rounded-l-[5px] last:rounded-r-[5px]',
              // Lift the focused segment so its ring isn't painted under its neighbour.
              'focus-visible:relative focus-visible:z-10',
              active
                ? '[color:theme(colors.base)]'
                : 'text-text-muted hover:bg-border-subtle hover:text-text-primary',
            ].join(' ')}
          >
            {option.label}
          </button>
        )
      })}
    </div>
  )
}

export default SegmentedToggle
