/**
 * A small schematic truss as plain data: nodes + members (member = pair of node ids).
 * Decorative only: not a solved problem and not connected to the solver. Shape space is
 * 200 x 130 units, the same box the other capability shapes use.
 *
 * A Warren-style truss: 4 bottom joints, 3 top joints, 11 members, every panel a triangle
 * (members = 2 * nodes - 3, so it is exactly triangulated).
 *
 * `trussStrokes()` in shapes.js turns one of these into particle strokes, tagged by
 * group (node / member) so a card can animate the parts separately. The Method of
 * Sections card can import SCHEMATIC_TRUSS and trussStrokes() and add its own cut line.
 */
export const SCHEMATIC_TRUSS = {
  w: 200,
  h: 130,
  nodes: [
    { id: 'b0', x: 16, y: 100 },
    { id: 'b1', x: 72, y: 100 },
    { id: 'b2', x: 128, y: 100 },
    { id: 'b3', x: 184, y: 100 },
    { id: 't0', x: 44, y: 30 },
    { id: 't1', x: 100, y: 30 },
    { id: 't2', x: 156, y: 30 },
  ],
  members: [
    { id: 'bc0', a: 'b0', b: 'b1' },
    { id: 'bc1', a: 'b1', b: 'b2' },
    { id: 'bc2', a: 'b2', b: 'b3' },
    { id: 'tc0', a: 't0', b: 't1' },
    { id: 'tc1', a: 't1', b: 't2' },
    { id: 'd0', a: 'b0', b: 't0' },
    { id: 'd1', a: 't0', b: 'b1' },
    { id: 'd2', a: 'b1', b: 't1' },
    { id: 'd3', a: 't1', b: 'b2' },
    { id: 'd4', a: 'b2', b: 't2' },
    { id: 'd5', a: 't2', b: 'b3' },
  ],
}

/**
 * A differently-proportioned variant for the Method of Sections card: a trapezoidal
 * truss with two verticals, 6 nodes and 9 members (2 * 6 - 3, still fully triangulated).
 * The card's cut line runs between the two verticals and crosses three members (the top
 * chord, the middle diagonal and the bottom chord), like a typical section cut.
 */
export const SECTIONS_TRUSS = {
  w: 200,
  h: 130,
  nodes: [
    { id: 'b0', x: 14, y: 104 },
    { id: 'b1', x: 70, y: 104 },
    { id: 'b2', x: 130, y: 104 },
    { id: 'b3', x: 186, y: 104 },
    { id: 't1', x: 70, y: 34 },
    { id: 't2', x: 130, y: 34 },
  ],
  members: [
    { id: 'bc0', a: 'b0', b: 'b1' },
    { id: 'bc1', a: 'b1', b: 'b2' },
    { id: 'bc2', a: 'b2', b: 'b3' },
    { id: 'tc', a: 't1', b: 't2' },
    { id: 'v1', a: 'b1', b: 't1' },
    { id: 'v2', a: 'b2', b: 't2' },
    { id: 'd0', a: 'b0', b: 't1' },
    { id: 'd1', a: 'b3', b: 't2' },
    { id: 'dm', a: 't1', b: 'b2' },
  ],
}

/** Members sorted left to right by midpoint (then top to bottom): a wave order. */
export function memberWaveOrder(truss) {
  const at = Object.fromEntries(truss.nodes.map((n) => [n.id, n]))
  const key = (m) => {
    const a = at[m.a]
    const b = at[m.b]
    return [(a.x + b.x) / 2, (a.y + b.y) / 2]
  }
  return [...truss.members].sort((m, n) => {
    const [mx, my] = key(m)
    const [nx, ny] = key(n)
    return mx - nx || my - ny
  })
}
