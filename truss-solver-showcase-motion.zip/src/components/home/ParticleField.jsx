import { useEffect, useRef } from 'react'
import { TOKENS } from '../../theme/palette.js'
import tint from './tint.js'
import useReducedMotion from './useReducedMotion.js'

/**
 * Full-size canvas particle field, meant to sit behind hero content.
 *
 *  - A fairly dense field of dots drifts and sways (px/second, so speed is
 *    frame-rate independent).
 *  - Near the cursor a dot brightens a lot, swells, gets a soft halo, speeds up and is
 *    pulled toward it; dots that are both lit and close are joined by lines (truss
 *    members, in spirit). When the cursor leaves, everything eases back to rest.
 *  - Plain canvas 2D + requestAnimationFrame. The loop, the pointer listeners and the
 *    ResizeObserver are all torn down on unmount.
 *  - prefers-reduced-motion: no loop and no pointer tracking — one static frame, redrawn
 *    on resize. Follows the OS setting live.
 *
 * Colors come from palette.js only.
 */

const DOT = TOKENS.textMuted // resting dot
const LIT = TOKENS.accent // dot near the cursor

const REACH = 230 // cursor influence radius, px
const PULL = 38 // max displacement toward the cursor, px
const LINK = 140 // max distance between two lit dots for a line, px
const EXCITE = 1.4 // extra drift speed at the cursor (1 + glow * EXCITE)
const AREA_PER_DOT = 8500 // px² of canvas per particle
const MIN_DOTS = 50
const MAX_DOTS = 150 // also caps the pair pass below, the only O(n²) part of the frame (cheap: it skips unlit dots)

const smooth = (t) => t * t * (3 - 2 * t)

function makeParticles(width, height) {
  const count = Math.max(MIN_DOTS, Math.min(MAX_DOTS, Math.round((width * height) / AREA_PER_DOT)))
  return Array.from({ length: count }, () => {
    const angle = Math.random() * Math.PI * 2
    const speed = 9 + Math.random() * 15 // px/s
    return {
      x: Math.random() * width,
      y: Math.random() * height,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      r: 0.8 + Math.random() * 1.0,
      a: 0.28 + Math.random() * 0.27, // resting alpha
      phase: Math.random() * Math.PI * 2, // for the slow sway
      glow: 0, // 0 (rest) … 1 (at the cursor), eased
      ox: 0, // eased displacement toward the cursor
      oy: 0,
    }
  })
}

function draw(ctx, width, height, particles) {
  ctx.clearRect(0, 0, width, height)

  // Lines first (under the dots), only between dots that are lit and near each other.
  ctx.lineWidth = 1
  for (let i = 0; i < particles.length; i++) {
    const p = particles[i]
    if (p.glow < 0.08) continue
    const px = p.x + p.ox
    const py = p.y + p.oy
    for (let j = i + 1; j < particles.length; j++) {
      const q = particles[j]
      if (q.glow < 0.08) continue
      const dx = q.x + q.ox - px
      const dy = q.y + q.oy - py
      const d2 = dx * dx + dy * dy
      if (d2 > LINK * LINK) continue
      const closeness = 1 - Math.sqrt(d2) / LINK
      const alpha = 0.55 * closeness * Math.min(p.glow, q.glow)
      if (alpha < 0.01) continue
      ctx.strokeStyle = tint(LIT, alpha)
      ctx.beginPath()
      ctx.moveTo(px, py)
      ctx.lineTo(q.x + q.ox, q.y + q.oy)
      ctx.stroke()
    }
  }

  for (const p of particles) {
    const alpha = p.a + p.glow * (0.9 - p.a)
    const x = p.x + p.ox
    const y = p.y + p.oy
    if (p.glow > 0.35) {
      // Soft halo on strongly lit dots.
      ctx.fillStyle = tint(LIT, 0.15 * p.glow)
      ctx.beginPath()
      ctx.arc(x, y, p.r + p.glow * 5.5, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.fillStyle = tint(p.glow > 0.02 ? LIT : DOT, p.glow > 0.02 ? alpha : p.a)
    ctx.beginPath()
    ctx.arc(x, y, p.r + p.glow * 2.4, 0, Math.PI * 2)
    ctx.fill()
  }
}

export default function ParticleField() {
  const canvasRef = useRef(null)
  const reduced = useReducedMotion()

  useEffect(() => {
    const canvas = canvasRef.current
    const host = canvas?.parentElement
    if (!canvas || !host) return undefined
    const ctx = canvas.getContext('2d')

    let width = 0
    let height = 0
    let particles = []
    let frame = 0
    let last = 0
    // Cursor in canvas coordinates; null while it is away.
    let cursor = null
    let onScreen = true // hero scrolled out of view → no work
    let running = false

    function resize() {
      const w = host.clientWidth
      const h = host.clientHeight
      if (w === 0 || h === 0) return
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      canvas.width = Math.round(w * dpr)
      canvas.height = Math.round(h * dpr)
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)

      if (particles.length === 0) {
        particles = makeParticles(w, h)
      } else {
        // Keep the existing field; rescale positions so it spreads over the new size,
        // then top up / trim to the density that fits the new area.
        const target = makeParticles(w, h).length
        for (const p of particles) {
          p.x = (p.x / width) * w
          p.y = (p.y / height) * h
        }
        if (particles.length > target) particles.length = target
        else particles.push(...makeParticles(w, h).slice(0, target - particles.length))
      }
      width = w
      height = h
      if (reduced) draw(ctx, width, height, particles)
    }

    function start() {
      if (running || reduced || !onScreen || document.hidden) return
      running = true
      last = window.performance.now() // no huge dt after a pause
      frame = window.requestAnimationFrame(step)
    }
    function stop() {
      running = false
      window.cancelAnimationFrame(frame)
    }

    function step(now) {
      if (!running) return
      frame = window.requestAnimationFrame(step)
      const dt = Math.min((now - last) / 1000, 0.05) // clamp after tab switches
      last = now

      const settle = 1 - Math.exp(-dt * 6) // ease rate: ~170ms time constant
      for (const p of particles) {
        // Drift, plus a slow sine sway so paths curve instead of running dead straight;
        // dots near the cursor move faster.
        const boost = 1 + p.glow * EXCITE
        p.x += (p.vx * boost + Math.sin(now / 2100 + p.phase) * 7) * dt
        p.y += (p.vy * boost + Math.cos(now / 2600 + p.phase) * 7) * dt
        if (p.x < -10) p.x = width + 10
        else if (p.x > width + 10) p.x = -10
        if (p.y < -10) p.y = height + 10
        else if (p.y > height + 10) p.y = -10

        let glow = 0
        let tx = 0
        let ty = 0
        if (cursor) {
          const dx = cursor.x - p.x
          const dy = cursor.y - p.y
          const d = Math.hypot(dx, dy)
          if (d < REACH) {
            glow = smooth(1 - d / REACH)
            // Pull strongest at mid-range so dots gather around the cursor rather than
            // collapsing onto it.
            const pull = PULL * glow * Math.min(1, d / 60)
            tx = (dx / (d || 1)) * pull
            ty = (dy / (d || 1)) * pull
          }
        }
        p.glow += (glow - p.glow) * settle
        p.ox += (tx - p.ox) * settle
        p.oy += (ty - p.oy) * settle
      }
      draw(ctx, width, height, particles)
    }

    const observer = new window.ResizeObserver(resize)
    observer.observe(host)
    resize()

    let onMove
    let onLeave
    let io
    let onVisibility
    if (!reduced) {
      onMove = (event) => {
        const rect = canvas.getBoundingClientRect()
        const x = event.clientX - rect.left
        const y = event.clientY - rect.top
        cursor = x >= 0 && y >= 0 && x <= rect.width && y <= rect.height ? { x, y } : null
      }
      onLeave = () => {
        cursor = null
      }
      // Hero content sits above the canvas and would swallow pointer events, so listen
      // on the window and map into canvas coordinates ourselves.
      window.addEventListener('pointermove', onMove, { passive: true })
      document.documentElement.addEventListener('pointerleave', onLeave)
      window.addEventListener('blur', onLeave)

      // Pause the loop while the hero is scrolled off-screen or the tab is hidden.
      io = new window.IntersectionObserver(([entry]) => {
        onScreen = entry.isIntersecting
        if (onScreen) start()
        else stop()
      })
      io.observe(host)
      onVisibility = () => (document.hidden ? stop() : start())
      document.addEventListener('visibilitychange', onVisibility)
      start()
    }

    return () => {
      stop()
      observer.disconnect()
      io?.disconnect()
      if (onVisibility) document.removeEventListener('visibilitychange', onVisibility)
      if (onMove) {
        window.removeEventListener('pointermove', onMove)
        document.documentElement.removeEventListener('pointerleave', onLeave)
        window.removeEventListener('blur', onLeave)
      }
    }
  }, [reduced])

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 h-full w-full"
    />
  )
}
