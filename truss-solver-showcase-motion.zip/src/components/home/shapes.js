/**
 * Point clouds for the capability cards. Each shape is a handful of strokes (lines,
 * rings, arrows) in a small unit box; every stroke is sampled into dots. ShapeParticles
 * then makes the dots fly in from scattered positions and settle on these points.
 *
 * Tones map to the palette: 'a' = accent, 'b' = accent-2 (see ShapeParticles).
 * Shapes stay deliberately simple so they read as a silhouette, not a detailed icon.
 */

import { SCHEMATIC_TRUSS, SECTIONS_TRUSS, memberWaveOrder } from './truss.js'

const STEP = 4.8 // spacing between dots along a stroke, in shape units (wider = fewer dots = cheaper frames)

function sampleLine(x1, y1, x2, y2, step = STEP) {
  const n = Math.max(1, Math.round(Math.hypot(x2 - x1, y2 - y1) / step))
  return Array.from({ length: n + 1 }, (_, i) => ({
    x: x1 + ((x2 - x1) * i) / n,
    y: y1 + ((y2 - y1) * i) / n,
  }))
}

function samplePolyline(points, step = STEP) {
  const out = []
  for (let i = 0; i < points.length - 1; i++) {
    const [x1, y1] = points[i]
    const [x2, y2] = points[i + 1]
    out.push(...sampleLine(x1, y1, x2, y2, step))
  }
  return out
}

function sampleCircle(cx, cy, r, step = STEP) {
  const n = Math.max(6, Math.round((Math.PI * 2 * r) / step))
  return Array.from({ length: n }, (_, i) => {
    const t = (i / n) * Math.PI * 2
    return { x: cx + Math.cos(t) * r, y: cy + Math.sin(t) * r }
  })
}

/* Stroke builders — each returns { pts, tone, link, big? } ----------------------- */

const line = (x1, y1, x2, y2, tone) => ({ pts: sampleLine(x1, y1, x2, y2), tone, link: true })
const poly = (points, tone) => ({ pts: samplePolyline(points), tone, link: true })
const rect = (x, y, w, h, tone) =>
  poly(
    [
      [x, y],
      [x + w, y],
      [x + w, y + h],
      [x, y + h],
      [x, y],
    ],
    tone,
  )
const ring = (cx, cy, r, tone) => ({ pts: sampleCircle(cx, cy, r), tone, link: true })
/** Sparse dotted ring / line: no links, so it reads as dashed. */
const dashedRing = (cx, cy, r, tone) => ({ pts: sampleCircle(cx, cy, r, 7), tone, link: false })
const dashedLine = (x1, y1, x2, y2, tone) => ({
  pts: sampleLine(x1, y1, x2, y2, 6.5),
  tone,
  link: false,
})
/** A single emphasised dot (a node / joint). */
const node = (x, y, tone) => ({ pts: [{ x, y }], tone, link: false, big: true })
/** Filled disc from concentric rings. */
const disc = (cx, cy, r, tone) => ({
  pts: [{ x: cx, y: cy }, ...sampleCircle(cx, cy, r * 0.5, 3), ...sampleCircle(cx, cy, r, 3)],
  tone,
  link: false,
})

function arrow(x1, y1, x2, y2, tone, head = 10) {
  const angle = Math.atan2(y2 - y1, x2 - x1)
  const spread = (28 * Math.PI) / 180
  const wing = (sign) => [
    x2 - Math.cos(angle + sign * spread) * head,
    y2 - Math.sin(angle + sign * spread) * head,
  ]
  const [lx, ly] = wing(1)
  const [rx, ry] = wing(-1)
  return [line(x1, y1, x2, y2, tone), line(x2, y2, lx, ly, tone), line(x2, y2, rx, ry, tone)]
}

/** Member between two points, shortened by the node radius at each end. */
function member(a, b, shortenA, shortenB, tone) {
  const len = Math.hypot(b[0] - a[0], b[1] - a[1])
  const ux = (b[0] - a[0]) / len
  const uy = (b[1] - a[1]) / len
  return line(
    a[0] + ux * shortenA,
    a[1] + uy * shortenA,
    b[0] - ux * shortenB,
    b[1] - uy * shortenB,
    tone,
  )
}

const polar = (cx, cy, r, deg) => [
  cx + Math.cos((deg * Math.PI) / 180) * r,
  cy + Math.sin((deg * Math.PI) / 180) * r,
]

/**
 * Strokes for a truss data structure (see truss.js). Joints are a small ring plus a centre
 * dot; members run between the rings. Every stroke carries a `group` so a card can animate
 * the parts separately: { kind: 'node', id } or { kind: 'member', id, rank, of } where
 * rank is the member's place in the left-to-right wave order.
 */
export function trussStrokes(truss, { ringR = 5, gap = 7.5, memberTone = 'a' } = {}) {
  const at = Object.fromEntries(truss.nodes.map((n) => [n.id, n]))
  const order = memberWaveOrder(truss)
  const members = order.map((m, rank) => ({
    ...member([at[m.a].x, at[m.a].y], [at[m.b].x, at[m.b].y], gap, gap, memberTone),
    group: { kind: 'member', id: m.id, rank, of: order.length },
  }))
  const nodes = truss.nodes.flatMap((n) => [
    { ...node(n.x, n.y, 'a'), group: { kind: 'node', id: n.id } },
    { ...ring(n.x, n.y, ringR, 'b'), group: { kind: 'node', id: n.id } },
  ])
  return { members, nodes }
}

/* Shape definitions ------------------------------------------------------------ */

const SHAPES = {
  // A small truss: it assembles, then its members dissolve one by one (a wave) until only
  // the isolated joints are left. Reversing the hover plays it backwards (members return,
  // then the whole truss scatters). `stages.split` is where on the 0..1 hover timeline the
  // assembly ends and the dissolve begins.
  joints: () => {
    const { members, nodes } = trussStrokes(SCHEMATIC_TRUSS)
    return {
      w: SCHEMATIC_TRUSS.w,
      h: SCHEMATIC_TRUSS.h,
      strokes: [...members, ...nodes],
      stages: { mode: 'dissolve', asmEnd: 0.5 }, // 0..asmEnd assemble, then members dissolve
      dur: { in: 1.4, out: 1.1 }, // seconds for the whole timeline, each way
    }
  },

  // The variant truss, then a dotted cut line sweeps across it and the two halves drift
  // apart. Timeline: 0..asmEnd assemble, asmEnd..cutEnd the cut line is drawn top to
  // bottom, cutEnd..1 the halves separate along the cut's normal. Reversed on hover-out:
  // the halves rejoin, the line retracts, then the truss scatters.
  sections: () => {
    const { members, nodes } = trussStrokes(SECTIONS_TRUSS)
    const cut = { x1: 82, y1: 6, x2: 118, y2: 128 }
    return {
      w: SECTIONS_TRUSS.w,
      h: SECTIONS_TRUSS.h,
      strokes: [
        ...members,
        ...nodes,
        { ...dashedLine(cut.x1, cut.y1, cut.x2, cut.y2, 'b'), group: { kind: 'cut' } },
      ],
      stages: { mode: 'cut', asmEnd: 0.4, cutEnd: 0.65 },
      cut,
      drift: 6, // shape units each half moves away from the cut
      dur: { in: 1.5, out: 1.15 },
    }
  },

  // A pointer next to a table: build on the canvas, or type it in.
  input: () => ({
    w: 200,
    h: 130,
    strokes: [
      poly(
        [
          [28, 18],
          [28, 96],
          [48, 78],
          [61, 108],
          [74, 102],
          [61, 73],
          [88, 73],
          [28, 18],
        ],
        'a',
      ),
      rect(112, 24, 76, 76, 'b'),
      line(112, 49, 188, 49, 'b'),
      line(112, 74, 188, 74, 'b'),
      line(150, 24, 150, 100, 'b'),
    ],
  }),

  // Full-truss overlay (left) → one isolated joint with its forces (right).
  fbd: () => {
    const c = [232, 66]
    return {
      w: 300,
      h: 130,
      strokes: [
        node(18, 100, 'a'),
        node(98, 100, 'a'),
        node(58, 36, 'a'),
        line(18, 100, 98, 100, 'a'),
        line(18, 100, 58, 36, 'a'),
        line(98, 100, 58, 36, 'a'),
        ...arrow(58, 4, 58, 28, 'b'),
        ...arrow(18, 128, 18, 108, 'b'),
        ...arrow(98, 128, 98, 108, 'b'),
        ...arrow(124, 66, 160, 66, 'a'),
        dashedRing(c[0], c[1], 52, 'b'),
        node(c[0], c[1], 'a'),
        ...[200, 340, 90].flatMap((deg) => {
          const from = polar(c[0], c[1], 9, deg)
          const to = polar(c[0], c[1], 40, deg)
          return arrow(from[0], from[1], to[0], to[1], 'a')
        }),
      ],
    }
  },

  // A stack of step cards, the first one expanded.
  steps: () => ({
    w: 300,
    h: 130,
    strokes: [
      rect(62, 10, 214, 58, 'a'),
      ring(36, 25, 6, 'b'),
      line(78, 25, 180, 25, 'a'),
      poly(
        [
          [251, 22],
          [256, 27],
          [261, 22],
        ],
        'b',
      ),
      line(78, 42, 250, 42, 'b'),
      line(78, 54, 208, 54, 'b'),

      rect(62, 78, 214, 22, 'a'),
      ring(36, 89, 6, 'b'),
      line(78, 89, 170, 89, 'a'),
      poly(
        [
          [254, 85],
          [259, 89],
          [254, 93],
        ],
        'b',
      ),

      rect(62, 108, 214, 20, 'a'),
      ring(36, 118, 6, 'b'),
      line(78, 118, 150, 118, 'a'),
      poly(
        [
          [254, 114],
          [259, 118],
          [254, 122],
        ],
        'b',
      ),

      dashedLine(36, 32, 36, 82, 'b'),
    ],
  }),
}

/**
 * Flatten a shape into one point list. Points that land within ~2 units of an earlier
 * point are dropped (strokes share their end points). `prev` is the index of the previous
 * kept point on the same stroke (or -1), used to draw the faint member lines.
 */
export function buildShape(id) {
  const { w, h, strokes, stages = null, dur = null, cut = null, drift = 0 } = SHAPES[id]()
  // Unit normal of the cut line (pointing to the right-hand side) and which side a point is on.
  let normal = null
  if (cut) {
    const len = Math.hypot(cut.x2 - cut.x1, cut.y2 - cut.y1)
    normal = { x: (cut.y2 - cut.y1) / len, y: -(cut.x2 - cut.x1) / len }
  }
  const sideOf = (x, y, group) =>
    !cut || group?.kind === 'cut'
      ? 0
      : Math.sign((x - cut.x1) * (cut.y2 - cut.y1) - (y - cut.y1) * (cut.x2 - cut.x1))
  const points = []
  for (const stroke of strokes) {
    let prev = -1
    const last = Math.max(1, stroke.pts.length - 1)
    stroke.pts.forEach((pt, i) => {
      const clash = points.findIndex((q) => Math.hypot(q.x - pt.x, q.y - pt.y) < 2)
      if (clash >= 0) {
        // Shared end point: keep the chain going from the dot that is already there.
        prev = clash
        return
      }
      points.push({
        x: pt.x,
        y: pt.y,
        tone: stroke.tone,
        big: !!stroke.big,
        prev: stroke.link ? prev : -1,
        grp: stroke.group ?? null,
        mt: i / last, // position along its stroke, 0..1
        side: sideOf(pt.x, pt.y, stroke.group), // -1 / +1 either side of the cut, 0 = none
      })
      prev = points.length - 1
    })
  }
  return { w, h, points, stages, dur, normal, drift }
}
