import { useEffect, useMemo, useRef } from 'react'
import { TOKENS } from '../../theme/palette.js'
import tint from './tint.js'
import { buildShape } from './shapes.js'
import useReducedMotion from './useReducedMotion.js'

/**
 * A small canvas of dots for one capability card. Same technique and colors as the
 * hero's ParticleField: plain canvas 2D + requestAnimationFrame, speeds in px/second,
 * dt clamped, colors from palette.js only.
 *
 * Everything is driven by ONE number per card, `hover` (0…1), which moves linearly
 * toward `want` (1 while the pointer is over / near the card, else 0). Every dot's
 * position and alpha is a pure function of `hover`, so a rapid in/out can never leave
 * a dot half-way or stray: it simply reverses from wherever it is.
 *
 * On hover the dots fly (on slight arcs, staggered) into the silhouette and keep a
 * gentle ambient sway; on hover-out they scatter again. At rest they drift loose and
 * unformed.
 *
 * Near the cursor dots swell, brighten and lean toward it; neighbours on the same
 * stroke are joined by faint lines (truss members, in spirit).
 *
 * The loop only runs while the canvas is on screen, and drops to ~30fps while nothing
 * is transitioning and the cursor is away (the work left is slow drift).
 * prefers-reduced-motion: no loop, no ambient drift, no cursor effects. The card still
 * snaps between its two states on pointer enter / leave, drawn as one static frame.
 */

const REST = TOKENS.textMuted
const TONES = { a: TOKENS.accent, b: TOKENS.accent2 }

const PAD = 18 // px kept clear around the shape
const AMBIENT = 12
const REACH = 80 // cursor influence radius, px
const PULL = 7 // max lean toward the cursor, px
const ENTER_MARGIN = 24 // px around the card that counts as "near"
const LEAVE_MARGIN = 48 // wider once hovered, so the edge doesn't flicker
const IDLE_FRAME_MS = 33

// Seconds for hover 0 → 1 (in) and 1 → 0 (out).
const DUR_IN = 1.3
const DUR_OUT = 0.95

const SWAY = 2.6 // px, whole-shape ambient drift while assembled
const WOBBLE = 1.2 // px, per-dot ambient drift while assembled
const smooth = (t) => t * t * (3 - 2 * t)
const clamp01 = (t) => Math.max(0, Math.min(1, t))

export default function ShapeParticles({ shape, targetRef, className = '' }) {
  const hostRef = useRef(null)
  const canvasRef = useRef(null)
  const reduced = useReducedMotion()
  const data = useMemo(() => buildShape(shape), [shape])

  useEffect(() => {
    const host = hostRef.current
    const canvas = canvasRef.current
    if (!host || !canvas) return undefined
    const ctx = canvas.getContext('2d')
    // Hover / proximity is measured against the whole card when given, else the canvas.
    const target = targetRef?.current ?? host

    let width = 0
    let height = 0
    let scale = 1
    let offX = 0
    let offY = 0
    let frame = 0
    let last = 0
    let placed = false
    let hover = 0 // 0 (rest) … 1 (hovered); everything below is a function of this
    let want = 0
    let pointer = null // viewport coordinates, from the window
    let cursor = null // same, in canvas coordinates (null while away)
    let busy = false
    let sep = 0 // 0..1 how far the halves have separated (sections card)

    const dots = data.points.map((pt) => {
      return {
        ...pt,
        x0: pt.x, // shape-space home
        y0: pt.y,
        hx: 0, // canvas-space home
        hy: 0,
        x: 0, // drawn position
        y: 0,
        lx: 0, // loose (scattered) position, form mode only
        ly: 0,
        vx: 0,
        vy: 0,
        delay: Math.random(), // 0..1 stagger rank
        bend: (Math.random() - 0.5) * 0.7, // fly-in arc, fraction of the distance
        phase: Math.random() * Math.PI * 2,
        r: 0.9 + Math.random() * 0.5,
        a: 0.7 + Math.random() * 0.3, // assembled alpha
        keep: 1, // staged shapes: 1 = member present, 0 = dissolved (nodes stay 1)
        asm: 0, // presence / "formed": drives color crossover, alpha and line fade
        glow: 0,
        ox: 0,
        oy: 0,
      }
    })
    const ambient = []

    function layout() {
      scale = Math.min((width - PAD * 2) / data.w, (height - PAD * 2) / data.h)
      offX = (width - data.w * scale) / 2
      offY = (height - data.h * scale) / 2
      for (const d of dots) {
        d.hx = offX + d.x0 * scale
        d.hy = offY + d.y0 * scale
      }
    }

    function scatter(p) {
      const angle = Math.random() * Math.PI * 2
      const speed = 6 + Math.random() * 10
      p.x = Math.random() * width
      p.y = Math.random() * height
      p.vx = Math.cos(angle) * speed
      p.vy = Math.sin(angle) * speed
    }

    const wrap = (p, key, limit) => {
      if (p[key] < -10) p[key] = limit + 10
      else if (p[key] > limit + 10) p[key] = -10
    }

    /** Positions, alpha and cursor reaction for every dot, from `hover` alone. */
    function evaluate(now, dt, animate) {
      const quick = 1 - Math.exp(-dt * 6)
      const sx = animate ? Math.sin(now / 2300) * SWAY : 0
      const sy = animate ? Math.cos(now / 2900) * SWAY * 0.7 : 0

      for (const a of ambient) {
        a.x += a.vx * dt
        a.y += a.vy * dt
        wrap(a, 'x', width)
        wrap(a, 'y', height)
      }

      // Staged shapes are one timeline on `hover` (0..1), so any interruption just reverses
      // from the current value. Plain shapes: all of it is assembly.
      //  - 'dissolve' (joints):  0..asmEnd assemble, then the members dissolve in a wave.
      //  - 'cut' (sections):     0..asmEnd assemble, asmEnd..cutEnd the cut line is drawn,
      //                          cutEnd..1 the two halves drift apart.
      const st = data.stages
      const asmEnd = st ? st.asmEnd : 1
      const asmT = clamp01(hover / asmEnd)
      const disT = st?.mode === 'dissolve' ? clamp01((hover - asmEnd) / (1 - asmEnd)) : 0
      const cutT = st?.mode === 'cut' ? clamp01((hover - asmEnd) / (st.cutEnd - asmEnd)) : 0
      sep = st?.mode === 'cut' ? smooth(clamp01((hover - st.cutEnd) / (1 - st.cutEnd))) : 0
      const SPAN = 0.4 // share of the dissolve a single member takes
      const SWEEP = 0.15 // extra stagger along a member's own length
      const drift = sep * (data.drift || 0) * scale

      for (const d of dots) {
        const kind = d.grp?.kind
        if (st?.mode === 'dissolve' && kind === 'member') {
          const start = (d.grp.rank / Math.max(1, d.grp.of - 1)) * (1 - SPAN - SWEEP)
          d.keep = 1 - smooth(clamp01((disT - start - d.mt * SWEEP) / SPAN))
        } else if (st?.mode === 'cut' && kind === 'cut') {
          d.keep = smooth(clamp01((cutT - d.mt * 0.6) / 0.4)) // drawn top to bottom
        } else {
          d.keep = 1
        }
        const wx = animate
          ? (Math.sin(now / 1400 + d.phase) + Math.sin(now / 2300 + d.phase * 1.7) * 0.6) * WOBBLE
          : 0
        const wy = animate
          ? (Math.cos(now / 1600 + d.phase) + Math.cos(now / 2100 + d.phase * 1.3) * 0.6) * WOBBLE
          : 0
        // assembled position, with its ambient drift (and the halves' separation)
        const gx = d.hx + wx + sx + (drift ? d.side * drift * data.normal.x : 0)
        const gy = d.hy + wy + sy + (drift ? d.side * drift * data.normal.y : 0)
        let x = gx
        let y = gy

        if (animate) {
          // Loose positions keep drifting (with a slow sideways sway) even while assembled,
          // so dots fly out from wherever they have got to.
          d.lx += (d.vx + Math.sin(now / 1900 + d.phase) * 4) * dt
          d.ly += (d.vy + Math.cos(now / 2400 + d.phase) * 4) * dt
          wrap(d, 'lx', width)
          wrap(d, 'ly', height)
        }
        const e = smooth(clamp01((asmT - d.delay * 0.45) / 0.55))
        d.asm = e
        if (e <= 0) {
          x = d.lx
          y = d.ly
        } else if (e < 1) {
          const dx = gx - d.lx
          const dy = gy - d.ly
          const len = Math.hypot(dx, dy) || 1
          const arc = Math.sin(Math.PI * e) * d.bend * len // slight curve, not a straight line
          x = d.lx + dx * e - (dy / len) * arc
          y = d.ly + dy * e + (dx / len) * arc
        }

        // Cursor: swell, brighten and lean toward it. Skipped for dots that aren't there.
        let glow = 0
        let tx = 0
        let ty = 0
        if (cursor) {
          const dx = cursor.x - x
          const dy = cursor.y - y
          const dist = Math.hypot(dx, dy)
          if (dist < REACH) {
            glow = smooth(1 - dist / REACH)
            const pull = PULL * glow * Math.min(1, dist / 30)
            tx = (dx / (dist || 1)) * pull
            ty = (dy / (dist || 1)) * pull
          }
        }
        d.glow += (glow - d.glow) * quick
        d.ox += (tx - d.ox) * quick
        d.oy += (ty - d.oy) * quick
        d.x = x + d.ox
        d.y = y + d.oy
      }
    }

    function draw() {
      ctx.clearRect(0, 0, width, height)

      // Faint member lines first (under the dots), between neighbours on the same stroke.
      ctx.lineWidth = 1
      for (let i = 0; i < dots.length; i++) {
        const d = dots[i]
        if (d.prev < 0) continue
        const q = dots[d.prev]
        const alpha = 0.3 * Math.min(d.asm, q.asm) * Math.min(d.keep, q.keep) *
          (d.side && q.side && d.side !== q.side ? 1 - sep : 1) * // cut members' links fade as the halves part
          (1 + Math.max(d.glow, q.glow))
        if (alpha < 0.01) continue
        ctx.strokeStyle = tint(TONES[d.tone], Math.min(alpha, 0.6))
        ctx.beginPath()
        ctx.moveTo(d.x, d.y)
        ctx.lineTo(q.x, q.y)
        ctx.stroke()
      }

      for (const a of ambient) {
        ctx.fillStyle = tint(REST, a.a)
        ctx.beginPath()
        ctx.arc(a.x, a.y, a.r, 0, Math.PI * 2)
        ctx.fill()
      }

      for (const d of dots) {
        if (d.keep < 0.02) continue // dissolved member dot: nothing drawn, nothing left behind
        const radius = ((d.big ? 2.4 : d.r) + d.glow * 1.5) * (0.5 + 0.5 * d.keep)
        // Loose dots are the muted resting dot; as they arrive they cross over to the tone.
        if (d.asm < 0.98) {
          ctx.fillStyle = tint(REST, 0.4 * (1 - d.asm) + d.glow * 0.2)
          ctx.beginPath()
          ctx.arc(d.x, d.y, radius, 0, Math.PI * 2)
          ctx.fill()
        }
        if (d.asm > 0.02) {
          ctx.fillStyle = tint(TONES[d.tone], Math.min(1, (d.a + d.glow * 0.3) * d.asm * d.keep))
          ctx.beginPath()
          ctx.arc(d.x, d.y, radius, 0, Math.PI * 2)
          ctx.fill()
        }
      }
    }

    function resize() {
      const w = host.clientWidth
      const h = host.clientHeight
      if (w === 0 || h === 0) return
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      canvas.width = Math.round(w * dpr)
      canvas.height = Math.round(h * dpr)
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)

      const prevW = width
      const prevH = height
      width = w
      height = h
      layout()

      if (!placed) {
        placed = true
        for (const d of dots) {
          const angle = Math.random() * Math.PI * 2
          const speed = 6 + Math.random() * 10
          d.lx = Math.random() * width
          d.ly = Math.random() * height
          d.vx = Math.cos(angle) * speed
          d.vy = Math.sin(angle) * speed
        }
        for (let i = 0; i < AMBIENT; i++) {
          const a = {}
          scatter(a)
          a.r = 0.8 + Math.random() * 0.9
          a.a = 0.2 + Math.random() * 0.2
          ambient.push(a)
        }
      } else if (prevW > 0 && prevH > 0) {
        // Keep the loose dots spread over the new size; assembled ones follow their homes.
        for (const d of dots) {
          d.lx = (d.lx / prevW) * w
          d.ly = (d.ly / prevH) * h
        }
        for (const a of ambient) {
          a.x = (a.x / prevW) * w
          a.y = (a.y / prevH) * h
        }
      }
      if (reduced) {
        evaluate(0, 0, false)
        draw()
      }
    }

    /** Is the pointer over (or just around) the card? Also refreshes `cursor`. */
    function track() {
      if (!pointer) {
        want = 0
        cursor = null
        return
      }
      const rect = target.getBoundingClientRect()
      const m = want ? LEAVE_MARGIN : ENTER_MARGIN
      want =
        pointer.x >= rect.left - m &&
        pointer.x <= rect.right + m &&
        pointer.y >= rect.top - m &&
        pointer.y <= rect.bottom + m
          ? 1
          : 0
      const box = canvas.getBoundingClientRect()
      cursor = { x: pointer.x - box.left, y: pointer.y - box.top }
    }

    function step(now) {
      frame = window.requestAnimationFrame(step)
      // Nothing transitioning and the cursor away: the work left is slow drift, so skip
      // every other frame.
      if (!busy && now - last < IDLE_FRAME_MS - 2) return
      const dt = Math.min((now - last) / 1000, 0.05) // clamp after tab switches
      last = now

      track()
      if (hover !== want) {
        const dur = want ? (data.dur?.in ?? DUR_IN) : (data.dur?.out ?? DUR_OUT)
        hover = want ? Math.min(1, hover + dt / dur) : Math.max(0, hover - dt / dur)
      }
      busy =
        hover !== want ||
        (cursor !== null &&
          cursor.x > -REACH &&
          cursor.x < width + REACH &&
          cursor.y > -REACH &&
          cursor.y < height + REACH)

      evaluate(now, dt, true)
      draw()
    }

    function run() {
      if (frame || reduced || document.hidden) return
      last = window.performance.now()
      frame = window.requestAnimationFrame(step)
    }
    function halt() {
      window.cancelAnimationFrame(frame)
      frame = 0
    }

    const resizeObserver = new window.ResizeObserver(resize)
    resizeObserver.observe(host)
    resize()

    const cleanups = []
    const listen = (el, type, fn, options) => {
      el.addEventListener(type, fn, options)
      cleanups.push(() => el.removeEventListener(type, fn, options))
    }

    if (reduced) {
      // No loop and no cursor effects: snap between the two states, one static frame each.
      const snap = (value) => {
        hover = value
        want = value
        evaluate(0, 0, false)
        draw()
      }
      listen(target, 'pointerenter', () => snap(1))
      listen(target, 'pointerleave', () => snap(0))
      evaluate(0, 0, false)
      draw()
      if (target.matches(':hover')) snap(1) // setting changed while the pointer is over the card
    } else {
      // The window sees the pointer wherever it is, so "near the card" works without
      // the card having to be hit. Touch has no hover: a tap forms the card, and it stays
      // until the next tap elsewhere or a scroll (which cancels the touch pointer).
      const onPointer = (event) => {
        pointer = { x: event.clientX, y: event.clientY }
      }
      const onGone = () => {
        pointer = null
      }
      listen(window, 'pointermove', onPointer, { passive: true })
      listen(window, 'pointerdown', onPointer, { passive: true })
      listen(window, 'pointercancel', onGone)
      listen(window, 'blur', onGone)
      listen(document.documentElement, 'pointerleave', onGone)
      listen(document, 'visibilitychange', () => (document.hidden ? halt() : run()))

      // Run only while the canvas is (nearly) on screen.
      const visibility = new window.IntersectionObserver(
        (entries) => {
          for (const entry of entries) {
            if (entry.isIntersecting) run()
            else halt()
          }
        },
        { rootMargin: '60px' },
      )
      visibility.observe(host)
      cleanups.push(() => visibility.disconnect())
    }

    return () => {
      halt()
      resizeObserver.disconnect()
      for (const fn of cleanups) fn()
    }
  }, [data, reduced, targetRef])

  return (
    <div ref={hostRef} className={`relative ${className}`}>
      <canvas ref={canvasRef} aria-hidden="true" className="absolute inset-0 h-full w-full" />
    </div>
  )
}
