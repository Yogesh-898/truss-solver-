import { useRef } from 'react'
import ShapeParticles from './ShapeParticles.jsx'

/**
 * What the solver actually does, one card per capability. Every entry maps to something
 * in the app: the Joints / Sections method toggle and the Section Cut tool (Toolbar,
 * solvers/), the canvas tools + the Edit truss tables (TrussCanvas, TrussDataPanel),
 * the FBD overlay toggle and per-step diagrams (FbdOverlay, StepFbd), and the Steps
 * panel with its Compact / Detailed views (StepsPanel).
 *
 * Each card's particles react to the cursor being over / near the card (not to scroll):
 * they sit loose and scattered at rest, assemble into the icon on hover, and scatter
 * again when the cursor leaves. See ShapeParticles.
 */
const CAPABILITIES = [
  {
    id: 'joints',
    shape: 'joints',
    title: 'Method of Joints',
    text: 'Solve every member in one click, joint by joint, with zero-force members found by inspection and each force marked tension or compression.',
    span: 'lg:col-span-2',
  },
  {
    id: 'sections',
    shape: 'sections',
    title: 'Method of Sections',
    text: 'Draw a cut line with two clicks and the solver isolates one side and finds the forces in the members it crosses.',
    span: 'lg:col-span-2',
  },
  {
    id: 'input',
    shape: 'input',
    title: 'Two ways to build',
    text: 'Add nodes, members, supports and loads with the canvas tools or fill in the tables, with every dimension coming from the values you type.',
    span: 'sm:col-span-2 lg:col-span-2',
  },
  {
    id: 'fbd',
    shape: 'fbd',
    title: 'Free body diagrams',
    text: 'Overlay the full-truss free body diagram on the canvas, and see an isolated joint or section sketch inside each solution step.',
    span: 'lg:col-span-3',
  },
  {
    id: 'steps',
    shape: 'steps',
    title: 'Step-by-step solutions',
    text: 'Read the worked solution in Compact view for titles and answers, or switch to Detailed for the reasoning, equations and substitutions.',
    span: 'lg:col-span-3',
  },
]

function CapabilityCard({ capability }) {
  // The card (not just its canvas) is the hover target, so hovering the text or moving
  // up to the edge of the card forms / dissolves the particles too.
  const cardRef = useRef(null)
  return (
    <article
      ref={cardRef}
      className={`group flex min-w-0 flex-col overflow-hidden rounded-xl border border-border-subtle bg-panel transition-colors duration-200 hover:border-accent/40 motion-reduce:transition-none ${capability.span}`}
    >
      <ShapeParticles
        shape={capability.shape}
        targetRef={cardRef}
        className="h-48 border-b border-border-subtle bg-base/60"
      />
      <div className="p-5">
        <h3 className="break-words font-ui text-lg font-semibold text-text-primary">{capability.title}</h3>
        <p className="mt-2 break-words font-ui text-sm leading-relaxed text-text-muted">{capability.text}</p>
      </div>
    </article>
  )
}

export default function CapabilityShowcase() {
  return (
    <section
      aria-labelledby="capabilities-title"
      className="bg-base px-6 pb-24 pt-20 text-text-primary sm:px-10 sm:pt-28"
    >
      <div className="mx-auto max-w-6xl">
        <h2
          id="capabilities-title"
          className="text-center font-ui text-3xl font-bold tracking-tight text-text-primary sm:text-4xl"
        >
          What it does
        </h2>
        <p className="mx-auto mt-3 max-w-xl text-balance text-center font-ui text-base text-text-muted">
          Build a truss, solve it two ways, and see every step of the working.
        </p>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-6">
          {CAPABILITIES.map((capability) => (
            <CapabilityCard key={capability.id} capability={capability} />
          ))}
        </div>
      </div>
    </section>
  )
}
