import { withAlpha } from '../../theme/palette.js'

// Alpha is quantised to 1/20 steps and the resulting color strings cached, so a frame
// builds no strings per dot (hundreds of short-lived strings per second otherwise).
const cache = new Map()

/** Cached withAlpha(hex, alpha) with alpha rounded to the nearest 0.05. */
export default function tint(hex, alpha) {
  const step = Math.max(0, Math.min(20, Math.round(alpha * 20)))
  const key = `${hex}|${step}`
  let value = cache.get(key)
  if (!value) {
    value = withAlpha(hex, step / 20)
    cache.set(key, value)
  }
  return value
}
