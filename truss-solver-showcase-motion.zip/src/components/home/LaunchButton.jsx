import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'

/** The one "Launch Solver" call to action — used in the hero and again at the page bottom. */
export default function LaunchButton({ className = '' }) {
  return (
    <Link
      to="/solver"
      className={`group inline-flex items-center gap-2 rounded-md bg-accent px-6 py-3 font-ui text-sm font-semibold text-base transition-colors hover:bg-accent/80 ${className}`}
    >
      Launch Solver
      <ArrowRight
        size={16}
        strokeWidth={2.4}
        aria-hidden="true"
        className="transition-transform duration-200 group-hover:translate-x-0.5 motion-reduce:transition-none"
      />
    </Link>
  )
}
