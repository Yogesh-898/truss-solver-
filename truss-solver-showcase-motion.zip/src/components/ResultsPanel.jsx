import { Table2 } from 'lucide-react'
import useTrussStore from '../store/trussStore.js'
import PanelEmptyState from './PanelEmptyState.jsx'
import { fmtNum } from '../utils/format.js'
import { NATURE_STYLE } from '../utils/nature.js'

/** Fewest decimals (0-3) that show every value in the list exactly as fmtNum would. */
function sharedDecimals(values) {
  let decimals = 0
  for (const value of values) {
    const text = fmtNum(Math.abs(value))
    const dot = text.indexOf('.')
    if (dot >= 0) decimals = Math.max(decimals, text.length - dot - 1)
  }
  return decimals
}

/** Magnitude padded to a shared number of decimals, so a column lines up like currency. */
function fixed(value, decimals) {
  const rounded = Number(fmtNum(Math.abs(value)))
  return Number.isFinite(rounded) ? rounded.toFixed(decimals) : '—'
}

/** The sign of a reaction is its direction in the +x right / +y up frame. */
function reactionArrow(component, value) {
  if (Math.abs(value) < 1e-9) return '' // no direction for a zero reaction
  if (component === 'Rx') return value >= 0 ? '→' : '←'
  return value >= 0 ? '↑' : '↓'
}

function NaturePill({ nature }) {
  const style = NATURE_STYLE[nature]
  if (!style) return <span className="text-text-muted">{nature}</span>
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 font-ui text-[11px] font-medium ${style.pill}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${style.dot}`} aria-hidden="true" />
      {nature}
    </span>
  )
}

function SectionHeader({ title, aside }) {
  return (
    <div className="flex items-baseline justify-between border-b border-border-subtle px-3 py-2">
      <h2 className="font-ui text-xs font-semibold text-text-primary">{title}</h2>
      {aside && <span className="font-technical text-[11px] text-text-muted">{aside}</span>}
    </div>
  )
}

/**
 * Member forces and support reactions from the last solve, read from the
 * store. Members that have not been solved show "—".
 */
function ResultsPanel() {
  const model = useTrussStore((state) => state.model)
  const units = useTrussStore((state) => state.units)
  const results = useTrussStore((state) => state.results)
  const reactions = useTrussStore((state) => state.reactions)
  const solveError = useTrussStore((state) => state.solveError)
  const sectionNote = useTrussStore((state) => state.sectionNote)
  const sectionResult = useTrussStore((state) => state.sectionResult)
  const sectionModel = useTrussStore((state) => state.sectionModel)
  const solveMethod = useTrussStore((state) => state.solveMethod)
  const clearResults = useTrussStore((state) => state.clearResults)

  const forceUnit = units?.force ?? ''
  const solvedCount = model.members.filter((member) => results[member.id]).length
  const reactionEntries = reactions
    ? Object.entries(reactions).flatMap(([nodeId, components]) =>
        Object.entries(components).map(([component, value]) => ({ nodeId, component, value })),
      )
    : []

  const isCurrentSection = sectionResult !== null && sectionModel === model
  const unsolvedCrossedIds = new Set(
    isCurrentSection && sectionResult?.ok ? sectionResult.unsolvedMemberIds : [],
  )

  const nothingYet = solvedCount === 0 && reactionEntries.length === 0

  const memberDecimals = sharedDecimals(
    model.members.map((member) => results[member.id]?.force).filter(Number.isFinite),
  )
  const reactionDecimals = sharedDecimals(reactionEntries.map((entry) => entry.value))

  return (
    <div className="font-ui text-xs">
      {solveError && (
        <div className="mb-3 rounded-lg border border-error/40 bg-error/15 p-2.5 text-xs font-medium text-error">
          {solveError}
        </div>
      )}

      {sectionNote && (
        <div className="mb-3 rounded-lg border border-warning/40 bg-warning/15 p-2.5 text-xs text-warning">
          {sectionNote}
        </div>
      )}

      {nothingYet ? (
        !solveError && (
          <PanelEmptyState Icon={Table2}>
            {solveMethod === 'joints'
              ? 'Run Solve to see results here.'
              : 'Make a section cut to see results here. Each cut adds the members it solves.'}
          </PanelEmptyState>
        )
      ) : (
        <div className="space-y-4">
          {/* ─── Support reactions ─────────────────────────────── */}
          {reactionEntries.length > 0 && (
            <section className="overflow-hidden rounded-lg border border-border-subtle bg-panel-elevated shadow-sm">
              <SectionHeader title="Support reactions" aside={forceUnit} />
              <table className="w-full border-collapse font-technical text-xs">
                <tbody>
                  {reactionEntries.map(({ nodeId, component, value }) => (
                    <tr
                      key={`${nodeId}-${component}`}
                      className="border-b border-border-subtle/50 last:border-b-0"
                    >
                      <td className="px-3 py-1.5 font-medium text-text-primary">
                        {component}
                        <sub className="ml-px text-[10px] text-text-muted">{nodeId}</sub>
                      </td>
                      <td className="py-1.5 pl-2 text-right tabular-nums text-text-primary">
                        {fixed(value, reactionDecimals)}
                      </td>
                      <td className="w-8 py-1.5 pl-1.5 pr-3 text-left text-text-muted">
                        {reactionArrow(component, value)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>
          )}

          {/* ─── Member forces ─────────────────────────────────── */}
          <section className="overflow-hidden rounded-lg border border-border-subtle bg-panel-elevated shadow-sm">
            <SectionHeader
              title="Member forces"
              aside={`${solvedCount} of ${model.members.length} solved`}
            />
            {model.members.length === 0 ? (
              <p className="p-3 text-xs text-text-muted">No members yet.</p>
            ) : (
              <table className="w-full border-collapse font-technical text-xs">
                <thead>
                  <tr className="border-b border-border-subtle text-text-muted">
                    <th className="px-3 py-1.5 text-left font-ui font-medium">Member</th>
                    <th className="py-1.5 pl-2 text-right font-ui font-medium">
                      Force{forceUnit ? ` (${forceUnit})` : ''}
                    </th>
                    <th className="py-1.5 pl-4 pr-3 text-left font-ui font-medium">Nature</th>
                  </tr>
                </thead>
                <tbody>
                  {model.members.map((member) => {
                    const result = results[member.id]
                    const isUnsolvedCut = unsolvedCrossedIds.has(member.id)
                    return (
                      <tr
                        key={member.id}
                        className="border-b border-border-subtle/50 last:border-b-0"
                      >
                        <td className="px-3 py-1.5 font-medium text-text-primary">{member.id}</td>
                        {result ? (
                          <>
                            <td className="py-1.5 pl-2 text-right tabular-nums text-text-primary">
                              {fixed(result.force, memberDecimals)}
                            </td>
                            <td className="py-1.5 pl-4 pr-3">
                              <NaturePill nature={result.nature} />
                            </td>
                          </>
                        ) : isUnsolvedCut ? (
                          <>
                            <td className="py-1.5 pl-2 text-right italic text-warning">
                              unsolved cut
                            </td>
                            <td className="py-1.5 pl-4 pr-3">
                              <span className="inline-flex items-center rounded-full border border-warning/40 bg-warning/15 px-2 py-0.5 font-ui text-[11px] font-medium text-warning">
                                Indeterminate
                              </span>
                            </td>
                          </>
                        ) : (
                          <>
                            <td className="py-1.5 pl-2 text-right text-text-muted/60">—</td>
                            <td className="py-1.5 pl-4 pr-3 text-text-muted/60">—</td>
                          </>
                        )}
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            )}
          </section>

          {solvedCount > 0 && (
            <button
              type="button"
              onClick={clearResults}
              className="rounded-md border border-border-subtle bg-panel px-3 py-1.5 text-xs font-medium text-text-muted transition-colors hover:bg-border-subtle hover:text-text-primary"
            >
              Clear results
            </button>
          )}
        </div>
      )}
    </div>
  )
}

export default ResultsPanel
