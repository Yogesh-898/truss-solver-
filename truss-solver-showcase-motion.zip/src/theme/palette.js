/**
 * The app's one color palette. Imported by tailwind.config.js (class names
 * such as `bg-panel`, `text-tension`) AND by the Konva canvas (TOKENS), so the
 * two can never drift apart. Change a color here and nowhere else.
 *
 * Keys are kebab-case because they become Tailwind class names.
 */
export const palette = {
  /* ── Surfaces & text ─────────────────────────────────────── */
  base:              '#0f1117',   // near-black page background
  panel:             '#181a20',   // primary panel fill
  'panel-elevated':  '#1f2128',   // raised cards / popovers
  'border-subtle':   '#2a2d36',   // low-contrast dividers
  'text-primary':    '#e2e4e9',   // main body text
  'text-muted':      '#7c8091',   // secondary / hint text

  /* ── Interactive ─────────────────────────────────────────── */
  // "Selected / active in the UI" (active mode, tab, toggle, focus ring, primary
  // buttons). Bright sky blue (hue ≈198°, light). Zero-force members are ALSO blue,
  // so the two are kept apart on purpose: zero-force below is a deeper, indigo-leaning
  // blue (hue ≈231°, ~3x darker) — ΔE2000 ≈ 32 between them.
  accent:            '#38bdf8',
  'accent-2':        '#a78bfa',   // soft violet — secondary interactive / section cuts

  /* ── Member-force signals ────────────────────────────────── */
  // Tension vs compression are separated by LIGHTNESS as well as hue (luminance
  // ≈0.70 vs ≈0.33, ~2:1), so they stay distinguishable in grayscale and for
  // red-green color blindness. Text on the panel / on its pill tint stays ≥4.5:1.
  tension:           '#86efac',   // member in tension (light green)
  compression:       '#f87171',   // member in compression (red, darker than tension)
  'zero-force':      '#4a5fdb',   // zero-force: deep indigo-blue — fills, lines, borders (≈3.3:1 on panel)
  'zero-force-text': '#8fa4f7',   // zero-force as TEXT (≈7.3:1 on panel, ≈5.3:1 on its pill tint)

  /* ── Status ──────────────────────────────────────────────── */
  warning:           '#facc15',   // amber-yellow warnings
  error:             '#f43f5e',   // rose-red errors

  /* ── Canvas-only ─────────────────────────────────────────── */
  'member-default':  '#64748b',   // unsolved member line (slate-500)
  'canvas-label':    '#12141a',   // backdrop behind labels / tags drawn on the canvas
  'node-hover':      '#243046',   // node fill while hovered
  'node-ink':        '#000000',   // dark ring on a coincident (warning) node
  'node-halo':       '#ffffff',   // light ring on a selected node
}

const camel = (key) => key.replace(/-([a-z0-9])/g, (_, c) => c.toUpperCase())

/** Same palette with camelCase keys, for canvas code: TOKENS.panelElevated. */
export const TOKENS = Object.fromEntries(
  Object.entries(palette).map(([key, value]) => [camel(key), value]),
)

/** '#rrggbb' + alpha → 'rgba(r, g, b, alpha)' (for CSS gradients etc.). */
export function withAlpha(hex, alpha) {
  const n = parseInt(hex.slice(1), 16)
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`
}
