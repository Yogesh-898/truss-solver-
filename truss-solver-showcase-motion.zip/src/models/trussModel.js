/**
 * trussModel.js
 *
 * The plain-JS-object shape used for a truss throughout the app, plus the
 * static-determinacy check.
 *
 * ── Shape ────────────────────────────────────────────────────────────
 *
 * model = {
 *   nodes: [
 *     { id: 'n1', refNodeId: null, dx: 0, dy: 0 },      // first node = origin (0, 0)
 *     { id: 'n2', refNodeId: 'n1', dx: 4, dy: 0 },      // 4 to the right of n1
 *     { id: 'n3', refNodeId: 'n1', dx: 2, dy: 3 },      // 2 right, 3 up from n1
 *   ],
 *   members: [ { id: 'm1', startNodeId: 'n1', endNodeId: 'n2' }, ... ],
 *   supports: [
 *     { nodeId: 'n1', type: 'pin' },
 *     { nodeId: 'n2', type: 'roller', rollerDirection: 'y' },
 *   ],
 *   loads: [
 *     // magnitude + direction are what the user typed; fx/fy are derived
 *     // from them (see loadComponents) and are what the solver reads.
 *     { nodeId: 'n3', magnitude: 10, direction: 'down', angle: 270, fx: 0, fy: -10 },
 *   ],
 * }
 *
 * ── Where every dimension comes from ─────────────────────────────────
 *
 * The ONLY geometry inputs are each node's `dx` / `dy`: the horizontal
 * (+ right) and vertical (+ up) distance the USER typed, measured from the
 * node's reference node `refNodeId`. Nothing is ever taken from where the
 * user clicked on the canvas. Node positions, member lengths and member
 * angles are all DERIVED from those typed distances (see layoutEngine.js)
 * and are never stored or edited independently, so the drawing and the
 * calculations can never disagree.
 *
 * A node may only reference a node that appears EARLIER in `nodes`, which
 * makes cycles impossible. The first node has no reference (origin).
 *
 * Frame: +x right, +y UP (engineering frame) everywhere — geometry, loads
 * and reactions all share it. Angles are degrees, counterclockwise from +x.
 */

/** Reaction components contributed by each support type. */
export const REACTIONS_PER_SUPPORT = {
  pin: 2,
  roller: 1,
}

/** Load directions offered to the user, with their fixed angle from +x (deg). */
export const LOAD_DIRECTIONS = {
  down: { label: 'Vertical ↓ (down)', angle: 270 },
  up: { label: 'Vertical ↑ (up)', angle: 90 },
  right: { label: 'Horizontal → (right)', angle: 0 },
  left: { label: 'Horizontal ← (left)', angle: 180 },
  inclined: { label: 'Inclined (angle from +x)', angle: null },
}

export function createEmptyModel() {
  return { nodes: [], members: [], supports: [], loads: [] }
}

/**
 * Static determinacy check: m + r = 2j determinate, > indeterminate,
 * < unstable. Count-based (necessary, not sufficient) — see solver errors
 * for singular systems.
 */
export function checkDeterminacy(model) {
  const m = model.members.length
  const j = model.nodes.length

  const r = model.supports.reduce((total, support) => {
    const reactions = REACTIONS_PER_SUPPORT[support.type]
    if (reactions === undefined) {
      throw new Error(`Unknown support type: "${support.type}"`)
    }
    return total + reactions
  }, 0)

  let status
  if (m + r === 2 * j) status = 'determinate'
  else if (m + r > 2 * j) status = 'indeterminate'
  else status = 'unstable'

  return { m, j, r, status }
}

/** Removes float noise like 6.1e-16 from cos/sin results. */
function clean(value) {
  if (Math.abs(value) < 1e-9) return 0
  return Math.round(value * 1e10) / 1e10
}

/**
 * Converts the user's magnitude + direction (+ angle when inclined) into
 * fx / fy components in the +x right / +y up frame.
 */
export function loadComponents(magnitude, direction, angle) {
  const fixed = LOAD_DIRECTIONS[direction]?.angle
  const degrees = fixed !== null && fixed !== undefined ? fixed : angle
  const radians = (degrees * Math.PI) / 180
  return {
    angle: degrees,
    fx: clean(magnitude * Math.cos(radians)),
    fy: clean(magnitude * Math.sin(radians)),
  }
}

// ── Editing helpers (pure, immutable) ────────────────────────────────

export function addNode(model, node) {
  return { ...model, nodes: [...model.nodes, node] }
}

/** Members store only their two end nodes; length/angle are derived. */
export function addMember(model, member) {
  return { ...model, members: [...model.members, member] }
}

export function memberExists(model, nodeIdA, nodeIdB) {
  return model.members.some(
    (member) =>
      (member.startNodeId === nodeIdA && member.endNodeId === nodeIdB) ||
      (member.startNodeId === nodeIdB && member.endNodeId === nodeIdA),
  )
}

export function setSupport(model, nodeId, type, rollerDirection) {
  const supports = model.supports.filter((support) => support.nodeId !== nodeId)
  const support = type === 'roller' ? { nodeId, type, rollerDirection } : { nodeId, type }
  return { ...model, supports: [...supports, support] }
}

/**
 * Sets the load at `nodeId` from the user's magnitude + direction. For
 * 'inclined', `angle` (degrees from +x, 0–360) is used; other directions
 * ignore it. fx/fy are derived here once so the solver just reads them.
 */
export function setLoad(model, nodeId, { magnitude, direction, angle = 0 }) {
  const { angle: resolvedAngle, fx, fy } = loadComponents(magnitude, direction, angle)
  const loads = model.loads.filter((load) => load.nodeId !== nodeId)
  return {
    ...model,
    loads: [...loads, { nodeId, magnitude, direction, angle: resolvedAngle, fx, fy }],
  }
}

export function updateNode(model, nodeId, updates) {
  return {
    ...model,
    nodes: model.nodes.map((node) => (node.id === nodeId ? { ...node, ...updates } : node)),
  }
}

export function updateMember(model, memberId, updates) {
  return {
    ...model,
    members: model.members.map((member) =>
      member.id === memberId ? { ...member, ...updates } : member,
    ),
  }
}

/** True if any other node is measured from `nodeId`. */
export function isReferenced(model, nodeId) {
  return model.nodes.some((node) => node.refNodeId === nodeId)
}

/**
 * Removes `nodeId` and cascades to its members, support and load. Callers
 * must not delete a node other nodes are measured from (see isReferenced).
 */
export function deleteNode(model, nodeId) {
  return {
    nodes: model.nodes.filter((node) => node.id !== nodeId),
    members: model.members.filter(
      (member) => member.startNodeId !== nodeId && member.endNodeId !== nodeId,
    ),
    supports: model.supports.filter((support) => support.nodeId !== nodeId),
    loads: model.loads.filter((load) => load.nodeId !== nodeId),
  }
}

export function deleteMember(model, memberId) {
  return { ...model, members: model.members.filter((member) => member.id !== memberId) }
}

export function removeSupport(model, nodeId) {
  return { ...model, supports: model.supports.filter((support) => support.nodeId !== nodeId) }
}

export function removeLoad(model, nodeId) {
  return { ...model, loads: model.loads.filter((load) => load.nodeId !== nodeId) }
}
