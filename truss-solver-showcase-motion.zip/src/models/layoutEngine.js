/**
 * layoutEngine.js
 *
 * Turns the distances the USER typed (each node's dx/dy from its reference
 * node) into actual node positions, member lengths and member angles.
 * Nothing here — and nothing in the solver — reads a clicked pixel
 * position; the canvas only DRAWS what this returns.
 *
 * Frame: +x right, +y UP (same frame as loads and reactions). The canvas
 * flips y only at the very last step, when drawing.
 */

/**
 * Position { x, y } of every node, by summing typed dx/dy along the
 * reference chain back to the origin node. Pure; never mutates `model`.
 */
export function computeLayout(model) {
  const byId = new Map(model.nodes.map((node) => [node.id, node]))
  const positions = {}
  const resolving = new Set()

  function resolve(id) {
    if (positions[id]) return positions[id]
    const node = byId.get(id)
    if (!node || resolving.has(id)) return { x: 0, y: 0 } // missing ref / cycle guard
    resolving.add(id)

    const dx = Number.isFinite(node.dx) ? node.dx : 0
    const dy = Number.isFinite(node.dy) ? node.dy : 0
    const base = node.refNodeId && byId.has(node.refNodeId) ? resolve(node.refNodeId) : { x: 0, y: 0 }

    resolving.delete(id)
    positions[id] = { x: base.x + dx, y: base.y + dy }
    return positions[id]
  }

  for (const node of model.nodes) resolve(node.id)
  return positions
}

/**
 * Length and direction of a member, derived from its two end nodes'
 * positions (i.e. from the user's typed distances). Angle is degrees,
 * counterclockwise from +x, in [0, 360), measured start -> end.
 * Returns null if an endpoint is missing.
 */
export function getMemberGeometry(model, member, layout = computeLayout(model)) {
  const start = layout[member.startNodeId]
  const end = layout[member.endNodeId]
  if (!start || !end) return null
  const dx = end.x - start.x
  const dy = end.y - start.y
  let angle = (Math.atan2(dy, dx) * 180) / Math.PI
  if (angle < 0) angle += 360
  if (angle >= 360 - 1e-9) angle = 0
  return { length: Math.hypot(dx, dy), angle, dx, dy }
}

/** Ids of nodes that sit exactly on top of an earlier node. */
export function findCoincidentNodeIds(model, layout = computeLayout(model)) {
  const seen = []
  const result = new Set()
  for (const node of model.nodes) {
    const p = layout[node.id]
    if (seen.some((q) => Math.hypot(p.x - q.x, p.y - q.y) < 1e-9)) result.add(node.id)
    seen.push(p)
  }
  return result
}
