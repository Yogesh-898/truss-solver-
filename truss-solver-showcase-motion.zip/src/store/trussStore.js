import { create } from 'zustand'
import {
  createEmptyModel,
  addNode as addNodeToModel,
  addMember as addMemberToModel,
  setSupport as setSupportInModel,
  setLoad as setLoadInModel,
  updateNode as updateNodeInModel,
  updateMember as updateMemberInModel,
  deleteNode as deleteNodeInModel,
  deleteMember as deleteMemberInModel,
  removeSupport as removeSupportInModel,
  removeLoad as removeLoadInModel,
  memberExists,
  isReferenced,
} from '../models/trussModel.js'
import { solveSectionMethod } from '../solvers/sectionMethod.js'
import { solveJointMethod } from '../solvers/jointMethod.js'
import { solveReactions } from '../solvers/reactions.js'
import { labelReactionSteps } from '../solvers/stepFormat.js'

/**
 * trussStore.js — the ONE source of truth for the truss being edited.
 *
 * Geometry rule: a node's position only ever comes from the horizontal /
 * vertical distances (dx, dy) the user types in a form or table cell,
 * measured from a reference node the user picks. Canvas clicks never
 * supply a coordinate — they only OPEN a form (or select a node).
 *
 * `mode` decides what a canvas click means:
 *   - 'addNode'    click empty canvas -> opens the node form (dx, dy, ref node)
 *   - 'addMember'  click node, click node -> new member between them
 *   - 'addSupport' click node -> inline picker (pin / roller x / roller y)
 *   - 'addLoad'    click node -> inline load form (magnitude + direction)
 *   - 'sectionCut' click twice on empty canvas -> draws a cut line and runs
 *                  the Method of Sections on the members it crosses.
 *                  Clicking a NODE in this mode does nothing — the cut
 *                  ignores joints.
 *
 * `solveMethod` ('joints' | 'sections') decides HOW the truss is solved:
 *   - 'joints'   a Solve button runs the Method of Joints for every member.
 *   - 'sections' the Section Cut tool is the only way results are made, and
 *                each cut adds the members it solves to `results`.
 *
 * `results`, `reactions` and `steps` are the last computed answer. They are
 * cleared the moment the model or the units change (see the subscription at
 * the bottom of this file), so stale numbers are never shown.
 *
 * The two cut clicks are the only place a screen position is ever
 * converted back into the real-unit frame, and it is used for ONE thing:
 * testing which members the line crosses. The forces, lengths, angles and
 * moment arms in the section solution all come from the typed distances
 * (computeLayout / getMemberGeometry), never from the clicks.
 */
const useTrussStore = create((set, get) => ({
  model: createEmptyModel(),
  mode: 'addNode',

  // Units are asked once, up front. null until the user chooses.
  units: null, // { length: 'm' | 'mm', force: 'kN' | 'N' }
  unitsDialogOpen: true,

  nodeCounter: 0,
  memberCounter: 0,
  pendingMemberNodeId: null,

  // Open popup: { type: 'node', x, y } (x/y = where to show the popup ONLY,
  // never used as a dimension) | { type: 'support' | 'load', nodeId }
  inlineEditor: null,

  // ── Section Cut tool ────────────────────────────────────────────────
  // pendingCutPoint holds the FIRST click while we wait for the second.
  // Both points are kept in screen form (for the live preview) and in
  // real-unit model form (for the crossing test and for redrawing the
  // finished line after a resize).
  pendingCutPoint: null, // { screen: {x, y}, model: {x, y} }
  cutLine: null, // { start: {screen, model}, end: {screen, model} }
  sectionResult: null, // { ok, results, steps, crossedMemberIds, ... } | { ok: false, message }
  // The model object the section was solved against; used to grey out
  // stale numbers the moment the truss is edited.
  sectionModel: null,

  // ── Solve method + last computed answer ─────────────────────────────
  solveMethod: 'joints', // 'joints' | 'sections'
  results: {}, // { [memberId]: { force, nature, label } } — tension-positive
  reactions: null, // { [nodeId]: { Rx?, Ry? } } from the last solve
  steps: [], // worked solution, shared shape across every solver
  solveError: null, // plain-language message from the last failed solve
  sectionNote: null, // "these members could not be solved" note from the last cut
  sidebarTab: 'edit', // 'edit' | 'steps' | 'results'
  sidebarOpen: true,
  stepsView: 'detailed', // 'compact' | 'detailed' — display preference only
  // Full-truss free body diagram overlay on the canvas. View-only: it never touches the
  // model, results, reactions or steps, and is not cleared by solving or editing.
  fbdOverlay: false,

  setSidebarTab: (sidebarTab) => set({ sidebarTab }),
  setStepsView: (stepsView) => set({ stepsView }),
  setFbdOverlay: (fbdOverlay) => set({ fbdOverlay }),
  toggleFbdOverlay: () => set((state) => ({ fbdOverlay: !state.fbdOverlay })),
  setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),

  /**
   * Switches the solving method. The two methods never mix their answers,
   * so the previous results, steps and cut are dropped. Leaving 'sections'
   * also leaves the Section Cut tool, which only exists in that method.
   */
  setSolveMethod: (solveMethod) =>
    set((state) => {
      if (state.solveMethod === solveMethod) return {}
      return {
        solveMethod,
        results: {},
        reactions: null,
        steps: [],
        solveError: null,
        sectionNote: null,
        pendingCutPoint: null,
        cutLine: null,
        sectionResult: null,
        sectionModel: null,
        mode: solveMethod === 'joints' && state.mode === 'sectionCut' ? 'addNode' : state.mode,
      }
    }),

  /** Method of Joints for ALL members, using the current units for labels only. */
  solveJoints: () =>
    set((state) => {
      try {
        const solved = solveJointMethod(state.model, state.units)
        return {
          results: solved.results,
          reactions: solved.reactions,
          steps: solved.steps,
          solveError: null,
          sectionNote: null,
          sidebarTab: 'results',
        }
      } catch (error) {
        return {
          results: {},
          reactions: null,
          steps: [],
          solveError: error.message,
          sectionNote: null,
          sidebarTab: 'results',
        }
      }
    }),

  /** Small shortcut: support reactions only, with their steps. */
  solveReactionsOnly: () =>
    set((state) => {
      try {
        const solved = solveReactions(state.model)
        return {
          reactions: solved.reactions,
          steps: labelReactionSteps(solved.steps, state.units),
          solveError: null,
          sidebarTab: 'results',
        }
      } catch (error) {
        return { reactions: null, steps: [], solveError: error.message, sidebarTab: 'results' }
      }
    }),

  /** Forgets every solved member force (e.g. to start a fresh run of cuts). */
  clearResults: () =>
    set({ results: {}, reactions: null, steps: [], solveError: null, sectionNote: null }),

  setUnits: (units) => set({ units, unitsDialogOpen: false }),
  openUnitsDialog: () => set({ unitsDialogOpen: true }),
  closeUnitsDialog: () => set((state) => (state.units ? { unitsDialogOpen: false } : {})),

  setMode: (mode) =>
    set((state) => {
      // The Section Cut tool only exists in the 'sections' method.
      if (mode === 'sectionCut' && state.solveMethod !== 'sections') return {}
      return {
        mode,
        pendingMemberNodeId: null,
        inlineEditor: null,
        pendingCutPoint: null,
        ...(mode === 'sectionCut' ? {} : { cutLine: null, sectionResult: null, sectionModel: null }),
      }
    }),

  /**
   * One click of the Section Cut tool. `screen` is where the click landed
   * (preview only); `point` is that same click converted into the
   * real-unit frame by src/utils/view.js `toModel`, and is used solely to
   * work out which members the line crosses.
   */
  addCutPoint: ({ screen, model: point }) =>
    set((state) => {
      if (state.mode !== 'sectionCut') return {}

      if (!state.pendingCutPoint) {
        return {
          pendingCutPoint: { screen, model: point },
          cutLine: null,
          sectionResult: null,
          sectionModel: null,
        }
      }

      const cutLine = { start: state.pendingCutPoint, end: { screen, model: point } }
      const base = { cutLine, pendingCutPoint: null, sectionModel: state.model }

      try {
        // `state.results` are members already solved on THIS model by earlier
        // cuts; the solver treats them as known forces on the free body.
        const solved = solveSectionMethod(
          state.model,
          { start: cutLine.start.model, end: cutLine.end.model },
          state.units,
          state.results,
        )
        return {
          ...base,
          sectionResult: { ok: true, ...solved },
          // Each cut ADDS what it solved to what earlier cuts found.
          results: { ...state.results, ...solved.results },
          reactions: solved.reactions,
          steps: solved.steps,
          solveError: null,
          sectionNote: solved.unsolvedNote,
        }
      } catch (error) {
        return {
          ...base,
          sectionResult: { ok: false, message: error.message },
          steps: [],
          solveError: error.message,
          sectionNote: null,
        }
      }
    }),

  clearCut: () =>
    set({ pendingCutPoint: null, cutLine: null, sectionResult: null, sectionModel: null }),

  /** Canvas click on empty space. */
  handleStageClick: (pos) => {
    const { mode } = get()
    if (mode === 'addNode') {
      // Only the popup's screen position is taken from the click.
      set({ inlineEditor: { type: 'node', x: pos.x, y: pos.y } })
    } else if (mode === 'addMember') {
      set({ pendingMemberNodeId: null })
    } else {
      set({ inlineEditor: null })
    }
  },

  /** Canvas click on an existing node. */
  handleNodeClick: (nodeId) =>
    set((state) => {
      if (state.mode === 'addMember') {
        if (!state.pendingMemberNodeId) return { pendingMemberNodeId: nodeId }
        if (state.pendingMemberNodeId === nodeId) return { pendingMemberNodeId: null }
        if (memberExists(state.model, state.pendingMemberNodeId, nodeId)) {
          return { pendingMemberNodeId: null }
        }
        const id = `m${state.memberCounter + 1}`
        return {
          model: addMemberToModel(state.model, {
            id,
            startNodeId: state.pendingMemberNodeId,
            endNodeId: nodeId,
          }),
          memberCounter: state.memberCounter + 1,
          pendingMemberNodeId: null,
        }
      }

      if (state.mode === 'addSupport' || state.mode === 'addLoad') {
        if (!state.model.nodes.some((n) => n.id === nodeId)) return {}
        return {
          inlineEditor: { type: state.mode === 'addSupport' ? 'support' : 'load', nodeId },
        }
      }
      return {}
    }),

  /**
   * Node form "Place node": `dx` / `dy` are the distances the user typed,
   * measured from `refNodeId`. The very first node is the origin.
   */
  addNodeFromForm: (refNodeId, dx, dy) =>
    set((state) => {
      const id = `n${state.nodeCounter + 1}`
      const isFirst = state.model.nodes.length === 0
      if (!isFirst && !state.model.nodes.some((n) => n.id === refNodeId)) return {}
      const node = isFirst
        ? { id, refNodeId: null, dx: 0, dy: 0 }
        : { id, refNodeId, dx, dy }
      return {
        model: addNodeToModel(state.model, node),
        nodeCounter: state.nodeCounter + 1,
        inlineEditor: null,
      }
    }),

  applySupport: (nodeId, type, rollerDirection) =>
    set((state) => ({
      model: setSupportInModel(state.model, nodeId, type, rollerDirection),
      inlineEditor: null,
    })),

  /** `load` = { magnitude, direction, angle } exactly as the user entered it. */
  applyLoad: (nodeId, load) =>
    set((state) => ({
      model: setLoadInModel(state.model, nodeId, load),
      inlineEditor: null,
    })),

  closeInlineEditor: () => set({ inlineEditor: null }),

  // ── Data-table actions ───────────────────────────────────────────────

  /** Table "add row": measured from the previous node, distances start at 0 for the user to fill in. */
  addBlankNode: () =>
    set((state) => {
      const nodes = state.model.nodes
      const id = `n${state.nodeCounter + 1}`
      const node =
        nodes.length === 0
          ? { id, refNodeId: null, dx: 0, dy: 0 }
          : { id, refNodeId: nodes[nodes.length - 1].id, dx: 0, dy: 0 }
      return {
        model: addNodeToModel(state.model, node),
        nodeCounter: state.nodeCounter + 1,
      }
    }),

  /**
   * Table edit of a node's dx / dy / refNodeId. A node may only reference
   * a node listed before it, so references can never form a cycle.
   */
  updateNode: (nodeId, updates) =>
    set((state) => {
      const nodes = state.model.nodes
      const index = nodes.findIndex((n) => n.id === nodeId)
      if (index <= 0) {
        // first node stays the origin: ignore any attempt to change it
        return {}
      }
      if ('refNodeId' in updates) {
        const refIndex = nodes.findIndex((n) => n.id === updates.refNodeId)
        if (refIndex < 0 || refIndex >= index) return {}
      }
      return { model: updateNodeInModel(state.model, nodeId, updates) }
    }),

  /** Blocked while other nodes are measured from this one. */
  deleteNode: (nodeId) =>
    set((state) => {
      if (isReferenced(state.model, nodeId)) return {}
      return {
        model: deleteNodeInModel(state.model, nodeId),
        pendingMemberNodeId:
          state.pendingMemberNodeId === nodeId ? null : state.pendingMemberNodeId,
        inlineEditor: state.inlineEditor?.nodeId === nodeId ? null : state.inlineEditor,
      }
    }),

  addBlankMember: () =>
    set((state) => {
      if (state.model.nodes.length < 2) return {}
      const id = `m${state.memberCounter + 1}`
      const [a, b] = state.model.nodes
      return {
        model: addMemberToModel(state.model, { id, startNodeId: a.id, endNodeId: b.id }),
        memberCounter: state.memberCounter + 1,
      }
    }),

  updateMember: (memberId, updates) =>
    set((state) => ({ model: updateMemberInModel(state.model, memberId, updates) })),

  deleteMember: (memberId) =>
    set((state) => ({ model: deleteMemberInModel(state.model, memberId) })),

  addBlankSupport: () =>
    set((state) => {
      const node = state.model.nodes.find(
        (n) => !state.model.supports.some((s) => s.nodeId === n.id),
      )
      if (!node) return {}
      return { model: setSupportInModel(state.model, node.id, 'pin') }
    }),

  changeSupportNode: (oldNodeId, newNodeId) =>
    set((state) => {
      const support = state.model.supports.find((s) => s.nodeId === oldNodeId)
      if (!support) return {}
      const withoutOld = removeSupportInModel(state.model, oldNodeId)
      return {
        model: setSupportInModel(withoutOld, newNodeId, support.type, support.rollerDirection),
      }
    }),

  removeSupport: (nodeId) => set((state) => ({ model: removeSupportInModel(state.model, nodeId) })),

  /** Table "add row" for Loads — starts at magnitude 0 (downward) on the first node without a load; the user types the real value. */
  addBlankLoad: () =>
    set((state) => {
      const node = state.model.nodes.find((n) => !state.model.loads.some((l) => l.nodeId === n.id))
      if (!node) return {}
      return {
        model: setLoadInModel(state.model, node.id, { magnitude: 0, direction: 'down', angle: 270 }),
      }
    }),

  changeLoadNode: (oldNodeId, newNodeId) =>
    set((state) => {
      const load = state.model.loads.find((l) => l.nodeId === oldNodeId)
      if (!load) return {}
      const withoutOld = removeLoadInModel(state.model, oldNodeId)
      return {
        model: setLoadInModel(withoutOld, newNodeId, {
          magnitude: load.magnitude,
          direction: load.direction,
          angle: load.angle,
        }),
      }
    }),

  removeLoad: (nodeId) => set((state) => ({ model: removeLoadInModel(state.model, nodeId) })),
}))

/**
 * Stale-number guard. The moment the model or the units change, the last
 * results / reactions / steps no longer describe what is on screen, so
 * they are cleared. A units change also clears the drawn cut, because the
 * force labels on it were written in the old units. (A model change keeps
 * the cut so the canvas can say "the truss changed — draw the cut again".)
 */
useTrussStore.subscribe((state, previous) => {
  const modelChanged = state.model !== previous.model
  const unitsChanged = state.units !== previous.units
  if (!modelChanged && !unitsChanged) return

  const hasAnswer =
    Object.keys(state.results).length > 0 ||
    state.reactions !== null ||
    state.steps.length > 0 ||
    state.solveError !== null ||
    state.sectionNote !== null
  const hasCut = unitsChanged && (state.cutLine || state.sectionResult || state.pendingCutPoint)
  if (!hasAnswer && !hasCut) return

  useTrussStore.setState({
    results: {},
    reactions: null,
    steps: [],
    solveError: null,
    sectionNote: null,
    ...(hasCut
      ? { cutLine: null, sectionResult: null, sectionModel: null, pendingCutPoint: null }
      : {}),
  })
})

export default useTrussStore
