/**
 * One place that maps a member's nature to the color tokens, so the Results
 * table and the Steps panel agree with the canvas and its legend:
 *   Tension -> tension, Compression -> compression, Zero-force -> zero-force.
 *
 * Class names are written out in full so Tailwind can see them.
 *
 * The zero-force token is a deep blue meant for fills, lines and borders; as
 * *text* it is too dark on the panel background, so zero-force text uses the
 * dedicated zero-force-text token — the same one the canvas label, the canvas
 * legend and the section-cut note use — and the dim token is carried by the
 * dot / border / tint.
 */
export const NATURE_STYLE = {
  Tension: {
    text: 'text-tension',
    dot: 'bg-tension',
    pill: 'border-tension/40 bg-tension/15 text-tension',
  },
  Compression: {
    text: 'text-compression',
    dot: 'bg-compression',
    pill: 'border-compression/40 bg-compression/15 text-compression',
  },
  'Zero-force': {
    text: 'text-zero-force-text',
    dot: 'bg-zero-force',
    pill: 'border-zero-force/60 bg-zero-force/25 text-zero-force-text',
  },
}

const SUFFIX_TO_NATURE = { T: 'Tension', C: 'Compression', 'zero-force': 'Zero-force' }

// "m1 = 800 kN (T)" — a member id, "=", a value, then the (T) / (C) / (zero-force)
// suffix written by resultLabel() in stepFormat.js.
const MEMBER_RESULT = /([^\s=()→]+ = [^()=→]*?\((T|C|zero-force)\))/g

/**
 * Splits a step's result text into [{ text, nature }] pieces. Only the
 * "member = value (T|C|zero-force)" pieces get a nature; everything else is
 * returned with nature null and stays neutral. Display only — the text itself
 * is never altered.
 */
export function splitResultByNature(text) {
  if (!text) return []
  const pieces = []
  let cursor = 0
  for (const match of text.matchAll(MEMBER_RESULT)) {
    if (match.index > cursor) pieces.push({ text: text.slice(cursor, match.index), nature: null })
    pieces.push({ text: match[1], nature: SUFFIX_TO_NATURE[match[2]] })
    cursor = match.index + match[1].length
  }
  if (cursor < text.length) pieces.push({ text: text.slice(cursor), nature: null })
  return pieces
}

// Numbers (with optional unit/degree sign) and symbols like F_m1, Rx_A. A number
// glued to a letter ("m1") is treated as part of a word and left alone.
const NUMERIC_PART =
  /([A-Za-z]+_[A-Za-z0-9_]+|(?<![A-Za-z_\d.])[-+]?\d+(?:\.\d+)?(?:\s?(?:°|kN|kip|lb|N|mm|cm|ft|m)(?![A-Za-z\d]))?)/g

/** Splits prose into [{ text, mono }] so the numeric parts can be set in monospace. */
export function splitNumericParts(text) {
  if (!text) return []
  // split() with one capture group alternates [prose, match, prose, match, ...],
  // so decide mono-ness from the index first, then drop the empty strings.
  return text
    .split(NUMERIC_PART)
    .map((part, index) => ({ text: part, mono: index % 2 === 1 }))
    .filter((part) => part.text !== '')
}
