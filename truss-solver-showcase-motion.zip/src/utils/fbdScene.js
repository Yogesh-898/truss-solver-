/**
 * fbdScene.js
 *
 * Pure helpers that turn data the solvers ALREADY produced (member forces in
 * `results`, support `reactions`, `model.loads`, and the per-step `fbd` metadata
 * attached by jointMethod.js / sectionMethod.js) into drawable primitives:
 * arrows, lines, dots and text labels. Nothing here solves or re-derives a force;
 * it only decides where to put arrows for numbers that are already known.
 *
 * Two consumers share this file so they cannot disagree:
 *   - the canvas overlay (Konva, screen pixels)  -> overlayScene()
 *   - the per-step mini diagrams (SVG)           -> jointStepScene(), sectionStepScene()
 *
 * Direction convention (matches the solvers): a member's force is tension-positive.
 * A member in TENSION pulls on a joint toward the member's other end; one in
 * COMPRESSION pushes the joint away from it. Every arrow here shows the force
 * acting ON the joint / free body, so:
 *   tension     -> arrow points away from the joint, along the member
 *   compression -> arrow points toward the joint, along the member
 *   zero-force  -> no arrowhead (dashed stub, labelled 0)
 *
 * Angles are degrees counter-clockwise from +x in the engineering frame (+y UP).
 * Primitives are in SCREEN space (+y DOWN), so the y flip happens in `polar`.
 */

import { TOKENS } from '../theme/palette.js'
import { fmtNum } from './format.js'

export const natureColor = (nature) =>
  nature === 'Tension' ? TOKENS.tension : nature === 'Compression' ? TOKENS.compression : TOKENS.zeroForce

export const natureTextColor = (nature) => (nature === 'Zero-force' ? TOKENS.zeroForceText : natureColor(nature))

const toRad = (deg) => (deg * Math.PI) / 180

/** Point `dist` away from (x, y) in engineering direction `angleDeg`, in screen space. */
export function polar(x, y, angleDeg, dist) {
  return { x: x + Math.cos(toRad(angleDeg)) * dist, y: y - Math.sin(toRad(angleDeg)) * dist }
}

const forceText = (value, units) => `${fmtNum(Math.abs(value))}${units?.force ? ` ${units.force}` : ''}`

/** Labels may span several lines ("\n"); the width is that of the longest line. */
const linesOf = (text) => String(text).split('\n')

/** Approximate width of a monospace label, for bounds and label pills. */
export const textWidth = (text, size = 9) => Math.max(...linesOf(text).map((line) => line.length)) * size * 0.6

/**
 * A label placed just beyond (x, y), on the side the arrow points to, so it never sits
 * on top of its own arrow.
 */
function labelBeyond(x, y, angleDeg, text, fill, size = 9) {
  const c = Math.cos(toRad(angleDeg))
  const s = Math.sin(toRad(angleDeg))
  const anchor = c > 0.35 ? 'start' : c < -0.35 ? 'end' : 'middle'
  const extra = (linesOf(text).length - 1) * (size + 1) // later lines hang below the first
  const px = x + (anchor === 'start' ? 4 : anchor === 'end' ? -4 : 0)
  // y is the first line's baseline. Above the arrow: lift so the LAST line clears it.
  const py = s > 0.35 ? y - 4 - extra : s < -0.35 ? y + size + 2 : y + size * 0.35 - extra / 2
  return { x: px, y: py, text, fill, anchor, size, weight: 600 }
}

const labelHeight = (label) => linesOf(label.text).length * (label.size + 1)

/** Nudges labels that would sit on top of each other apart vertically. */
function declutter(labels) {
  const placed = []
  for (const label of labels) {
    let guard = 0
    const box = () => {
      const w = textWidth(label.text, label.size)
      const left = label.anchor === 'start' ? label.x : label.anchor === 'end' ? label.x - w : label.x - w / 2
      return { left, right: left + w, y: label.y, h: labelHeight(label) }
    }
    while (guard < 6) {
      const b = box()
      const clash = placed.find((p) => {
        const q = { left: 0, right: 0, y: p.y, h: labelHeight(p) }
        const w = textWidth(p.text, p.size)
        q.left = p.anchor === 'start' ? p.x : p.anchor === 'end' ? p.x - w : p.x - w / 2
        q.right = q.left + w
        const overlapY = q.y < b.y + b.h && b.y < q.y + q.h
        return overlapY && q.left < b.right && q.right > b.left
      })
      if (!clash) break
      label.y += label.size + 2
      guard += 1
    }
    placed.push(label)
  }
  return labels
}

function boundsOf(scene, padding) {
  let minX = Infinity
  let minY = Infinity
  let maxX = -Infinity
  let maxY = -Infinity
  const add = (x, y) => {
    minX = Math.min(minX, x)
    maxX = Math.max(maxX, x)
    minY = Math.min(minY, y)
    maxY = Math.max(maxY, y)
  }
  for (const a of scene.arrows) {
    add(a.x1, a.y1)
    add(a.x2, a.y2)
  }
  for (const l of scene.lines) {
    add(l.x1, l.y1)
    add(l.x2, l.y2)
  }
  for (const d of scene.dots) {
    add(d.x - d.r, d.y - d.r)
    add(d.x + d.r, d.y + d.r)
  }
  for (const t of scene.labels) {
    const w = textWidth(t.text, t.size)
    const left = t.anchor === 'start' ? t.x : t.anchor === 'end' ? t.x - w : t.x - w / 2
    add(left, t.y - t.size)
    add(left + w, t.y + (linesOf(t.text).length - 1) * (t.size + 1) + 2)
  }
  if (!Number.isFinite(minX)) return { x: -50, y: -50, width: 100, height: 100 }
  return {
    x: minX - padding,
    y: minY - padding,
    width: maxX - minX + 2 * padding,
    height: maxY - minY + 2 * padding,
  }
}

const emptyScene = () => ({ arrows: [], lines: [], dots: [], labels: [] })

// ── Reusable pieces ──────────────────────────────────────────────────

/**
 * Arrow for a force acting ON the point (px, py) in direction `angle`: the head touches the
 * point (after `gap`) and the tail trails back along the opposite direction.
 */
function incomingArrow(px, py, angle, gap, length, color, extra = {}) {
  const head = polar(px, py, angle + 180, gap)
  const tail = polar(px, py, angle + 180, gap + length)
  return { x1: tail.x, y1: tail.y, x2: head.x, y2: head.y, color, width: 2.2, ...extra, tail }
}

/** Arrow for a member force acting on the joint at (px, py), along the member direction `angle`. */
function memberForceArrow(px, py, angle, nature, gap, length) {
  const color = natureColor(nature)
  if (nature === 'Zero-force') {
    const a = polar(px, py, angle, gap)
    const b = polar(px, py, angle, gap + length)
    return { kind: 'stub', x1: a.x, y1: a.y, x2: b.x, y2: b.y, color, width: 2, dash: true, end: b }
  }
  const near = polar(px, py, angle, gap)
  const far = polar(px, py, angle, gap + length)
  return nature === 'Tension'
    ? { kind: 'arrow', x1: near.x, y1: near.y, x2: far.x, y2: far.y, color, width: 2.4, end: far }
    : { kind: 'arrow', x1: far.x, y1: far.y, x2: near.x, y2: near.y, color, width: 2.4, end: far }
}

/** Reaction components a support provides, with the signed value (null if not solved yet). */
export function reactionComponents(support, reaction) {
  const components = support.type === 'pin' ? ['Rx', 'Ry'] : support.rollerDirection === 'x' ? ['Rx'] : ['Ry']
  return components.map((component) => ({
    component,
    value: reaction && Number.isFinite(reaction[component]) ? reaction[component] : null,
  }))
}

const reactionAngle = (component, value) =>
  component === 'Rx' ? ((value ?? 0) >= 0 ? 0 : 180) : (value ?? 0) >= 0 ? 90 : 270

// ── 1. Canvas overlay ────────────────────────────────────────────────

/**
 * What the full-truss FBD toggle adds on top of the normal drawing, in screen pixels.
 *
 * Loads and support symbols are already part of the normal canvas, so they are not drawn
 * a second time; the overlay adds the missing pieces of a free body diagram:
 *   - a reaction arrow for every support component (dashed + symbol-only until solved,
 *     solid + signed value once reactions exist),
 *   - once member forces exist, a pair of force arrows on each solved member plus a label
 *     with its magnitude and unit.
 *
 * @param {object} args
 * @param {object} args.model
 * @param {(nodeId: string) => ({x:number,y:number}|null)} args.screenPos
 * @param {object} args.results   member id -> { force, nature }
 * @param {object|null} args.reactions  node id -> { Rx?, Ry? } (null before any solve)
 * @param {{force?: string}|null} args.units  labelling only
 */
export function overlayScene({ model, screenPos, results, reactions, units }) {
  const arrows = []
  const labels = []

  // Reactions.
  const REACTION_LEN = 52
  const GAP = 10
  for (const support of model.supports) {
    const p = screenPos(support.nodeId)
    if (!p) continue
    for (const { component, value } of reactionComponents(support, reactions?.[support.nodeId])) {
      const solved = value !== null
      if (solved && Math.abs(value) < 1e-9) continue // nothing acts there
      const angle = reactionAngle(component, value)
      const arrow = incomingArrow(p.x, p.y, angle, GAP, REACTION_LEN, TOKENS.textPrimary, {
        dash: !solved,
        width: 2.4,
      })
      arrows.push(arrow)
      const name = `${component}_${support.nodeId}`
      labels.push({
        ...labelBeyond(arrow.tail.x, arrow.tail.y, angle + 180, solved ? `${name} = ${forceText(value, units)}` : name, TOKENS.textPrimary, 10.5),
        pill: true,
      })
    }
  }

  // Member force arrows (only for members that have a solved force).
  for (const member of model.members) {
    const solved = results?.[member.id]
    if (!solved || solved.nature === 'Zero-force') continue
    const a = screenPos(member.startNodeId)
    const b = screenPos(member.endNodeId)
    if (!a || !b) continue
    const length = Math.hypot(b.x - a.x, b.y - a.y)
    if (length < 1e-6) continue
    const ux = (b.x - a.x) / length
    const uy = (b.y - a.y) / length
    const nx = -uy // fixed side of the member, so every arrow pair sits beside its line
    const ny = ux
    const OFFSET = 9
    const END_GAP = 14
    const arrowLen = Math.min(30, length / 2 - END_GAP - 4)
    if (arrowLen < 8) continue

    const color = natureColor(solved.nature)
    const tension = solved.nature === 'Tension'
    const place = (from, dir) => {
      // `from` is the joint; `dir` is +1 along the member away from it.
      const sx = from.x + nx * OFFSET
      const sy = from.y + ny * OFFSET
      const near = { x: sx + dir.x * END_GAP, y: sy + dir.y * END_GAP }
      const far = { x: near.x + dir.x * arrowLen, y: near.y + dir.y * arrowLen }
      arrows.push(
        tension
          ? { x1: near.x, y1: near.y, x2: far.x, y2: far.y, color, width: 2.4 }
          : { x1: far.x, y1: far.y, x2: near.x, y2: near.y, color, width: 2.4 },
      )
    }
    place(a, { x: ux, y: uy })
    place(b, { x: -ux, y: -uy })

    const at = 0.28
    labels.push({
      x: a.x + ux * length * at + nx * 22,
      y: a.y + uy * length * at + ny * 22,
      text: forceText(solved.force, units),
      fill: natureTextColor(solved.nature),
      stroke: color,
      anchor: 'middle',
      size: 10.5,
      weight: 700,
      pill: true,
    })
  }

  return { arrows, labels }
}

/** Label size in the mini diagrams (viewBox units; the SVG scales to the card width). */
const STEP_FONT = 10

// ── 2a. Method of Joints: isolated joint ─────────────────────────────

/**
 * Isolated-joint FBD from a joint step's `fbd`. Only this joint appears: a dot at the
 * origin, one arrow per member force, one for the load and one per reaction component.
 */
export function jointStepScene(fbd, units) {
  const scene = emptyScene()
  const LEN = 34
  const GAP = 7
  const labels = []

  scene.dots.push({ x: 0, y: 0, r: 3.5, fill: TOKENS.panelElevated, stroke: TOKENS.textPrimary })

  for (const m of fbd.members) {
    const arrow = memberForceArrow(0, 0, m.angle, m.nature, GAP, LEN)
    if (arrow.kind === 'stub') scene.lines.push(arrow)
    else scene.arrows.push(arrow)
    labels.push(labelBeyond(arrow.end.x, arrow.end.y, m.angle, `${m.id}\n${m.label}`, natureTextColor(m.nature), STEP_FONT))
  }

  if (fbd.load) {
    const arrow = incomingArrow(0, 0, fbd.load.angle, GAP, LEN, TOKENS.error)
    scene.arrows.push(arrow)
    labels.push(labelBeyond(arrow.tail.x, arrow.tail.y, fbd.load.angle + 180, forceText(fbd.load.magnitude, units), TOKENS.error, STEP_FONT))
  }

  if (fbd.reaction) {
    for (const component of ['Rx', 'Ry']) {
      const value = fbd.reaction[component]
      if (!Number.isFinite(value) || Math.abs(value) < 1e-9) continue
      const angle = reactionAngle(component, value)
      const arrow = incomingArrow(0, 0, angle, GAP, LEN, TOKENS.textPrimary)
      scene.arrows.push(arrow)
      labels.push(
        labelBeyond(arrow.tail.x, arrow.tail.y, angle + 180, `${component} = ${forceText(value, units)}`, TOKENS.textPrimary, STEP_FONT),
      )
    }
  }

  scene.labels = declutter(labels)
  return { ...scene, bounds: boundsOf(scene, 6) }
}

// ── 2b. Method of Sections: the solved segment ───────────────────────

/**
 * Free-body FBD of the segment actually used, from the "Isolate the segment" step's `fbd`.
 * Only the free body's own nodes and members are drawn; each cut member is a force arrow
 * at its attachment joint (never a physical member); loads and reactions on the segment
 * are arrows. The discarded side never appears because the step's data never contains it.
 */
export function sectionStepScene(fbd, units) {
  const scene = emptyScene()
  const labels = []
  const LEN = 26
  const GAP = 6

  const xs = fbd.nodes.map((n) => n.x)
  const ys = fbd.nodes.map((n) => n.y)
  const spanX = Math.max(...xs) - Math.min(...xs)
  const spanY = Math.max(...ys) - Math.min(...ys)
  const span = Math.max(spanX, spanY)
  const scale = span > 0 ? 90 / span : 1
  const pos = new Map(fbd.nodes.map((n) => [n.id, { x: (n.x - Math.min(...xs)) * scale, y: -(n.y - Math.min(...ys)) * scale }]))

  for (const member of fbd.members) {
    const a = pos.get(member.startNodeId)
    const b = pos.get(member.endNodeId)
    if (!a || !b) continue
    scene.lines.push({
      x1: a.x,
      y1: a.y,
      x2: b.x,
      y2: b.y,
      color: member.result ? natureColor(member.result.nature) : TOKENS.memberDefault,
      width: 2.5,
    })
  }

  for (const node of fbd.nodes) {
    const p = pos.get(node.id)
    scene.dots.push({ x: p.x, y: p.y, r: 3.2, fill: TOKENS.panelElevated, stroke: TOKENS.textPrimary })
    labels.push({ x: p.x + 5, y: p.y - 5, text: node.id, fill: TOKENS.textMuted, anchor: 'start', size: 9, weight: 500 })
  }

  for (const cut of fbd.cutMembers) {
    const p = pos.get(cut.attachNodeId)
    if (!p) continue
    if (!cut.result) {
      // Not determined by this cut: assumed-tension direction, dashed, no value.
      const near = polar(p.x, p.y, cut.angle, GAP)
      const far = polar(p.x, p.y, cut.angle, GAP + LEN)
      scene.arrows.push({ x1: near.x, y1: near.y, x2: far.x, y2: far.y, color: TOKENS.textMuted, width: 2, dash: true })
      labels.push(labelBeyond(far.x, far.y, cut.angle, `${cut.id}\nnot solved`, TOKENS.textMuted, STEP_FONT))
      continue
    }
    const arrow = memberForceArrow(p.x, p.y, cut.angle, cut.result.nature, GAP, LEN)
    if (arrow.kind === 'stub') scene.lines.push(arrow)
    else scene.arrows.push(arrow)
    labels.push(labelBeyond(arrow.end.x, arrow.end.y, cut.angle, `${cut.id}\n${cut.result.label}`, natureTextColor(cut.result.nature), STEP_FONT))
  }

  for (const load of fbd.loads) {
    const p = pos.get(load.nodeId)
    if (!p) continue
    const arrow = incomingArrow(p.x, p.y, load.angle, GAP, LEN, TOKENS.error)
    scene.arrows.push(arrow)
    labels.push(labelBeyond(arrow.tail.x, arrow.tail.y, load.angle + 180, forceText(load.magnitude, units), TOKENS.error, STEP_FONT))
  }

  for (const reaction of fbd.reactions) {
    const p = pos.get(reaction.nodeId)
    if (!p) continue
    for (const component of ['Rx', 'Ry']) {
      const value = reaction[component]
      if (!Number.isFinite(value) || Math.abs(value) < 1e-9) continue
      const angle = reactionAngle(component, value)
      const arrow = incomingArrow(p.x, p.y, angle, GAP, LEN, TOKENS.textPrimary)
      scene.arrows.push(arrow)
      labels.push(
        labelBeyond(arrow.tail.x, arrow.tail.y, angle + 180, `${component} = ${forceText(value, units)}`, TOKENS.textPrimary, STEP_FONT),
      )
    }
  }

  scene.labels = declutter(labels)
  return { ...scene, bounds: boundsOf(scene, 6) }
}
