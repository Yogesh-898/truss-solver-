/** Rounds for display and drops float noise / trailing zeros (e.g. 3.0000000004 -> "3"). */
export function fmtNum(value, digits = 3) {
  if (!Number.isFinite(value)) return '—'
  const factor = 10 ** digits
  const rounded = Math.round(value * factor) / factor
  return String(Object.is(rounded, -0) ? 0 : rounded)
}
