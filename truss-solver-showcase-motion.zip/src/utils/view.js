/**
 * view.js
 *
 * The one place that knows about PIXELS. It maps between the real-unit
 * frame the model lives in (+x right, +y UP, built from the distances the
 * user typed) and the screen frame Konva draws in (+x right, +y DOWN).
 *
 * This lived inside TrussCanvas.jsx until the Section Cut tool needed the
 * same mapping — the canvas draws with `toScreen`, and the cut tool uses
 * `toModel` to turn the two clicked points back into the real-unit frame
 * so it can test which members the cut crosses.
 *
 * IMPORTANT: `scale` and both transforms exist for DRAWING and for the
 * geometric crossing test only. No force, length, angle or moment arm in
 * any solver may ever be derived from a pixel — every dimension in a
 * calculation comes from computeLayout / getMemberGeometry, i.e. from the
 * distances the user typed.
 */

export const PADDING = 90

/**
 * Fits `layout` (real units) into a width × height canvas with one
 * uniform scale, so the drawn shape stays true to the typed dimensions.
 *
 * @returns {{
 *   scale: number,
 *   minX: number, minY: number,
 *   offsetX: number, offsetY: number,
 *   width: number, height: number,
 *   toScreen: (point: {x: number, y: number}) => {x: number, y: number},
 *   toModel: (point: {x: number, y: number}) => {x: number, y: number},
 * }}
 *   `toModel` is the exact inverse of `toScreen`.
 */
export function computeView(layout, width, height) {
  const points = Object.values(layout ?? {})

  let minX = 0
  let minY = 0
  let scale = 1
  let offsetX = width / 2
  let offsetY = height / 2

  if (points.length > 0) {
    const xs = points.map((p) => p.x)
    const ys = points.map((p) => p.y)
    minX = Math.min(...xs)
    minY = Math.min(...ys)
    const spanX = Math.max(...xs) - minX
    const spanY = Math.max(...ys) - minY
    const availableWidth = Math.max(width - 2 * PADDING, 50)
    const availableHeight = Math.max(height - 2 * PADDING, 50)

    if (spanX > 0 && spanY > 0) scale = Math.min(availableWidth / spanX, availableHeight / spanY)
    else if (spanX > 0) scale = availableWidth / spanX
    else if (spanY > 0) scale = availableHeight / spanY

    offsetX = (width - spanX * scale) / 2
    offsetY = (height - spanY * scale) / 2
  }

  // Engineering +y UP becomes screen +y DOWN here, at the very last step.
  const toScreen = (point) => ({
    x: offsetX + (point.x - minX) * scale,
    y: height - offsetY - (point.y - minY) * scale,
  })

  const toModel = (point) => ({
    x: minX + (point.x - offsetX) / scale,
    y: minY + (height - offsetY - point.y) / scale,
  })

  return { scale, minX, minY, offsetX, offsetY, width, height, toScreen, toModel }
}

export default computeView
