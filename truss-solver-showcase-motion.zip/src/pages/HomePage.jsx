import ParticleField from '../components/home/ParticleField.jsx'
import CapabilityShowcase from '../components/home/CapabilityShowcase.jsx'
import LaunchButton from '../components/home/LaunchButton.jsx'
import { TOKENS, withAlpha } from '../theme/palette.js'

function HomePage() {
  return (
    <main className="min-h-full bg-base text-text-primary">
      {/* Hero */}
      <section
        aria-labelledby="hero-title"
        className="relative flex min-h-screen items-center justify-center overflow-hidden px-6 py-16 sm:px-10"
        style={{
          backgroundImage: `radial-gradient(ellipse 60% 50% at 50% 45%, ${withAlpha(TOKENS.accent, 0.07)}, transparent 70%)`,
        }}
      >
        <ParticleField />

        <div className="relative z-10 flex w-full max-w-3xl flex-col items-center text-center">
          <h1
            id="hero-title"
            className="max-w-full break-words font-ui text-5xl font-bold tracking-tight text-text-primary sm:text-6xl md:text-7xl"
          >
            Truss Solver
          </h1>
          <p className="mt-5 max-w-xl text-balance break-words font-ui text-base text-text-muted sm:max-w-2xl sm:text-lg">
            Solve statically determinate trusses by the method of joints and sections.
          </p>
          <LaunchButton className="mt-9" />
        </div>
      </section>

      {/* Capability showcase — same dark base as the hero */}
      <CapabilityShowcase />

      {/* Closing call to action, so nobody has to scroll back up to start */}
      <section
        aria-labelledby="closing-title"
        className="border-t border-border-subtle bg-base px-6 py-20 text-center sm:px-10"
        style={{
          backgroundImage: `radial-gradient(ellipse 50% 70% at 50% 100%, ${withAlpha(TOKENS.accent, 0.06)}, transparent 70%)`,
        }}
      >
        <h2
          id="closing-title"
          className="mx-auto max-w-full break-words font-ui text-2xl font-bold tracking-tight text-text-primary sm:text-3xl"
        >
          Ready to solve your truss?
        </h2>
        <LaunchButton className="mt-7" />
      </section>
    </main>
  )
}

export default HomePage
