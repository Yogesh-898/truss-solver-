import { useLayoutEffect, useMemo, useRef, useState } from 'react'
import Toolbar from '../components/Toolbar.jsx'
import TrussCanvas from '../components/TrussCanvas.jsx'
import TrussDataPanel from '../components/TrussDataPanel.jsx'
import StepsPanel from '../components/StepsPanel.jsx'
import ResultsPanel from '../components/ResultsPanel.jsx'
import UnitsDialog from '../components/UnitsDialog.jsx'
import useTrussStore from '../store/trussStore.js'
import { ChevronLeft } from 'lucide-react'
import { useSlidingIndicator, indicatorStyle } from '../components/useSlidingIndicator.js'

const TABS = [
  { id: 'edit', label: 'Edit truss' },
  { id: 'steps', label: 'Steps' },
  { id: 'results', label: 'Results' },
]

const tabId = (id) => `sidebar-tab-${id}`
const panelId = (id) => `sidebar-panel-${id}`
const SIDEBAR_ID = 'sidebar'

// Sidebar slide. One short, decelerating curve shared by the width animation and the
// canvas glide below, so the sidebar edge and the truss move as one:
//  - width: 220ms ease-out-expo-ish (fast start, soft landing; no slow ease-in at the start);
//  - opacity: fades faster than the width moves (150ms) so content doesn't ghost.
// `visibility` is the part that takes the collapsed sidebar out of the way of assistive
// tech and old browsers:
//  - opening: visible immediately (0s, no delay), so focus can move in on the same frame;
//  - closing: flips to hidden only AFTER the slide (0s duration, 220ms delay), so the
//    content stays visible while it slides out.
// `inert` (set below while closed) removes it from the tab order straight away.
const SIDEBAR_MS = 220
const SIDEBAR_EASE = 'cubic-bezier(0.32,0.72,0,1)'
const SIDEBAR_OPEN =
  'w-sidebar opacity-100 visible [transition:width_220ms_cubic-bezier(0.32,0.72,0,1),opacity_150ms_ease-out,visibility_0s_linear_0s]'
const SIDEBAR_CLOSED =
  'w-0 opacity-0 invisible [transition:width_220ms_cubic-bezier(0.32,0.72,0,1),opacity_150ms_ease-out,visibility_0s_linear_220ms]'

function SolverPage() {
  const sidebarTab = useTrussStore((state) => state.sidebarTab)
  const setSidebarTab = useTrussStore((state) => state.setSidebarTab)
  const sidebarOpen = useTrussStore((state) => state.sidebarOpen)
  const toggleSidebar = useTrussStore((state) => state.toggleSidebar)
  const unitsDialogOpen = useTrussStore((state) => state.unitsDialogOpen)
  const stepCount = useTrussStore((state) => state.steps.length)
  const resultCount = useTrussStore((state) => state.results.length ?? Object.keys(state.results).length)

  const rowRef = useRef(null) // the canvas + sidebar row
  const columnRef = useRef(null) // the sidebar's inner, fixed-width column
  const railRef = useRef(null) // the always-visible toggle strip at the sidebar's edge
  const tabRefs = useRef({})

  /* ── Canvas size ─────────────────────────────────────────────────────────
     The canvas gets the row's width minus the toggle rail's width (always there) and
     the sidebar's FINAL width (only while open). All inputs
     are stable while the sidebar animates (the row never changes size, and the
     inner column keeps its width), so the Konva stage is resized once per toggle
     instead of on every animation frame. The canvas container just reveals or
     clips the stage as the sidebar slides. */
  const [slot, setSlot] = useState({ rowWidth: 0, rowHeight: 0, columnWidth: 0, railWidth: 0 })
  useLayoutEffect(() => {
    function measure() {
      const row = rowRef.current
      const column = columnRef.current
      const rail = railRef.current
      if (!row || !column || !rail) return
      const next = {
        rowWidth: row.clientWidth,
        rowHeight: row.clientHeight,
        columnWidth: column.offsetWidth,
        railWidth: rail.offsetWidth,
      }
      setSlot((prev) =>
        prev.rowWidth === next.rowWidth &&
        prev.rowHeight === next.rowHeight &&
        prev.columnWidth === next.columnWidth &&
        prev.railWidth === next.railWidth
          ? prev
          : next,
      )
    }
    measure()
    const observer = new ResizeObserver(measure)
    observer.observe(rowRef.current)
    observer.observe(columnRef.current)
    observer.observe(railRef.current)
    return () => observer.disconnect()
  }, [])

  const canvasSize = useMemo(
    () => ({
      width: Math.max(0, slot.rowWidth - slot.railWidth - (sidebarOpen ? slot.columnWidth : 0)),
      height: slot.rowHeight,
    }),
    [slot, sidebarOpen],
  )

  /* ── Canvas glide ────────────────────────────────────────────────────────
     The Konva stage is resized once, to its final width, the moment the sidebar toggles
     (see above), which would make the truss jump to its new centre while the sidebar is
     still sliding. So, on a toggle only (never on a plain window resize), we tell the
     canvas how far the truss moved; it plays that distance back as a compositor-only
     transform over the same duration and easing as the sidebar. */
  const lastCanvas = useRef({ open: sidebarOpen, width: 0 })
  const [glide, setGlide] = useState({ id: 0, from: 0 })
  useLayoutEffect(() => {
    const last = lastCanvas.current
    if (last.open !== sidebarOpen && last.width > 0 && canvasSize.width > 0) {
      setGlide((g) => ({ id: g.id + 1, from: (last.width - canvasSize.width) / 2 }))
    }
    lastCanvas.current = { open: sidebarOpen, width: canvasSize.width }
  }, [sidebarOpen, canvasSize.width])

  // One indicator (tinted fill + bottom bar) that slides to the selected tab.
  const tablistRef = useRef(null)
  const { rect: tabRect, animate: tabAnimate } = useSlidingIndicator(
    tablistRef,
    `${sidebarTab}|${stepCount}|${resultCount}`,
  )

  /* ── Tabs: roving tabindex + arrow keys (automatic activation) ─────────── */
  function onTabKeyDown(event, index) {
    let next = null
    if (event.key === 'ArrowRight') next = (index + 1) % TABS.length
    else if (event.key === 'ArrowLeft') next = (index - 1 + TABS.length) % TABS.length
    else if (event.key === 'Home') next = 0
    else if (event.key === 'End') next = TABS.length - 1
    if (next === null) return
    event.preventDefault()
    const id = TABS[next].id
    setSidebarTab(id)
    tabRefs.current[id]?.focus()
  }

  return (
    <div className="flex h-full w-full flex-col">
      <UnitsDialog />

      {/* While the units dialog is open everything behind it is inert: unreachable by
          keyboard and hidden from screen readers, matching the dialog's aria-modal. */}
      <div className="flex min-h-0 flex-1 flex-col" inert={unitsDialogOpen ? '' : undefined}>
        <Toolbar />
        <div ref={rowRef} className="flex min-h-0 flex-1 overflow-hidden">
          {/* Canvas column. `min-w-0` + `overflow-hidden` are what let it shrink:
              a flex item's default min-width is its content's width, and the
              Konva stage inside is sized in px, so without them the canvas could
              only ever grow and would push the sidebar off-screen. */}
          <div className="relative min-w-0 flex-1 overflow-hidden bg-panel">
            {canvasSize.width > 0 && (
              <TrussCanvas size={canvasSize} glide={{ ...glide, duration: SIDEBAR_MS, easing: SIDEBAR_EASE }} />
            )}
          </div>

          {/* THE sidebar toggle — the only control that opens or closes the sidebar.
              Just the arrow icon, no bar or backing shape. It hangs off a zero-width
              anchor that sits on the sidebar's edge, a sibling of the (collapsing)
              <aside> rather than a child, so it stays on screen in both states: the
              anchor is shrink-0 and the canvas column is the flexible item that gives
              way, so at any viewport width it can never be pushed off-screen. The
              button extends leftwards from the anchor over the canvas's edge (above
              its overlays), vertically centred. One button, both directions: the
              chevron points the way the sidebar will move. Focus stays on it.
              State lives on the icon itself: muted at rest; accent colour and a small
              scale-up on hover; accent colour plus the app's standard focus ring on
              keyboard focus (ring drawn inside the button, offset -2px, because the row
              is overflow-hidden and the button is flush with the right edge while the
              sidebar is collapsed). */}
          <div ref={railRef} className="relative w-0 shrink-0">
            <button
              type="button"
              onClick={toggleSidebar}
              aria-label={sidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
              aria-expanded={sidebarOpen}
              aria-controls={SIDEBAR_ID}
              title={sidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
              className="group absolute right-0 top-1/2 z-30 flex h-9 w-7 -translate-y-1/2 items-center justify-center rounded-md text-text-muted transition-colors hover:text-accent focus-visible:text-accent [outline-offset:-2px]"
            >
              <ChevronLeft
                size={18}
                strokeWidth={2.2}
                className="[--s:1] group-hover:[--s:1.2] group-active:[--s:0.9]"
                style={{
                  transform: `rotate(${sidebarOpen ? 180 : 0}deg) scale(var(--s))`,
                  transition: `transform ${SIDEBAR_MS}ms ${SIDEBAR_EASE}`,
                }}
              />
            </button>
          </div>

          {/* Sidebar — fixed, canvas-friendly width (clamp(18rem, 28vw, 24rem) =
              288–384px), never shrinks, never grows. Collapsing animates the
              outer width to 0; the inner column keeps its width so the content
              doesn't reflow mid-animation. While collapsed it is `inert` (no tab
              stops, not read by screen readers) as well as invisible. */}
          <aside
            id={SIDEBAR_ID}
            inert={sidebarOpen ? undefined : ''}
            className={`shrink-0 overflow-hidden bg-panel motion-reduce:transition-none ${
              sidebarOpen ? SIDEBAR_OPEN : SIDEBAR_CLOSED
            }`}
          >
            <div ref={columnRef} className="flex h-full w-sidebar flex-col border-l border-border-subtle">
              {/* relative z-20: the focus ring of a tab extends ~4px below the header, over the scroll
                  area. Without its own stacking level the scroll container (painted later) covers
                  that edge of the ring. z-20 also keeps it above the Steps panel's z-10 sticky bar. */}
              <div className="relative z-20 border-b border-border-subtle px-4 pt-3">
                <h1 className="font-ui text-base font-semibold text-text-primary">Truss Solver</h1>

                {/* Same "selected" language as the Toolbar: tinted fill, accent text, bottom bar.
                    Tab semantics: only the selected tab is in the Tab order (roving tabindex);
                    Left/Right/Home/End move between tabs and select them. */}
                <div ref={tablistRef} className="relative -mb-px mt-2.5 flex gap-1" role="tablist" aria-label="Sidebar sections">
                  {tabRect && (
                    <span
                      aria-hidden="true"
                      className="pointer-events-none absolute rounded-t-md bg-accent/15 motion-reduce:!transition-none"
                      style={indicatorStyle(tabRect, tabAnimate)}
                    >
                      <span className="absolute inset-x-1 bottom-0 h-0.5 rounded-full bg-accent" />
                    </span>
                  )}
                  {TABS.map((tab, index) => {
                    const active = sidebarTab === tab.id
                    const count = tab.id === 'steps' ? stepCount : tab.id === 'results' ? resultCount : 0
                    return (
                      <button
                        key={tab.id}
                        ref={(node) => {
                          tabRefs.current[tab.id] = node
                        }}
                        id={tabId(tab.id)}
                        type="button"
                        role="tab"
                        aria-selected={active}
                        data-sliding-active={active ? '' : undefined}
                        aria-controls={active ? panelId(tab.id) : undefined}
                        aria-label={count > 0 ? `${tab.label}, ${count}` : undefined}
                        tabIndex={active ? 0 : -1}
                        onClick={() => setSidebarTab(tab.id)}
                        onKeyDown={(event) => onTabKeyDown(event, index)}
                        className={[
                          'relative flex items-center gap-1.5 rounded-t-md px-3 py-2 font-ui text-sm font-medium transition-colors duration-200',
                          active
                            ? 'text-accent'
                            : 'text-text-muted hover:bg-panel-elevated hover:text-text-primary',
                        ].join(' ')}
                      >
                        {tab.label}
                        {count > 0 && (
                          <span
                            className={`rounded-full px-1.5 font-technical text-[10px] leading-4 ${
                              active ? 'bg-accent/20 text-accent' : 'bg-border-subtle text-text-muted'
                            }`}
                          >
                            {count}
                          </span>
                        )}
                      </button>
                    )
                  })}
                </div>
              </div>

              <div
                role="tabpanel"
                id={panelId(sidebarTab)}
                aria-labelledby={tabId(sidebarTab)}
                className="flex-1 overflow-y-auto p-4"
              >
                {sidebarTab === 'edit' && <TrussDataPanel />}
                {sidebarTab === 'steps' && <StepsPanel />}
                {sidebarTab === 'results' && <ResultsPanel />}
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  )
}

export default SolverPage
