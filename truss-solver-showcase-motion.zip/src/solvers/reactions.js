/**
 * reactions.js
 *
 * Solves for the external support reaction components of a truss by
 * treating the *whole truss as a single rigid body* and writing the
 * three overall 2D equilibrium equations:
 *
 *     ΣFx = 0,   ΣFy = 0,   ΣM = 0 (about a chosen reference point)
 *
 * This is the "overall equilibrium" step described as step 1 of the
 * Method of Joints procedure in all three attached references
 * (Beer & Johnston §6.4, Meriam/Kraige/Bolton §4.3, Hibbeler §2) — it
 * must be done before joint-by-joint or section analysis can start,
 * because those methods treat the reactions as *known* forces.
 *
 * This module only knows about the truss as a rigid body: nodes, the
 * supports on them, and the applied loads. It has no idea how many
 * members exist or how they're connected — that's irrelevant to overall
 * equilibrium. Nothing about a specific truss shape is hard-coded; the
 * same code runs whether the model has 3 nodes or 30.
 *
 * Moment sign convention (per moment-calculation-guide-trusses.md §2):
 * each force's moment about the reference point is computed as the
 * r × F cross product, M = Δx·Fy − Δy·Fx, with counterclockwise
 * positive. This is the unambiguous, textbook-standard form. (The
 * guide's shorthand "M = Fx·dy − Fy·dx" is the same relationship but
 * written with its terms in the opposite order/sign — the guide itself
 * flags this form as convention-dependent ("signs depending on
 * rotational sense"), so we use the fixed Δx·Fy − Δy·Fx form
 * everywhere instead, both in the solve and in the narrated steps, to
 * avoid ever picking the wrong sign.)
 */

import { lusolve } from 'mathjs'
import { checkDeterminacy } from '../models/trussModel.js'
import { computeLayout } from '../models/layoutEngine.js'

/**
 * Rounds a number for display in a step's equation/substitution text —
 * plain arithmetic values are exact, but division inside lusolve can
 * leave float noise (e.g. 66.66666666666667) that would look wrong in a
 * worked-example explanation.
 */
function fmt(value) {
  const rounded = Math.round(value * 1000) / 1000
  // Avoid "-0"
  return Object.is(rounded, -0) ? 0 : rounded
}

/** Short human label for a reaction unknown, e.g. "Rx_n1". */
function labelFor(unknown) {
  return `${unknown.component}_${unknown.nodeId}`
}

/**
 * Formats one term of a linear equation ("+ 4·Ry_n2", "- Rx_n1", "+ 50")
 * for display. `value` may be a coefficient (paired with a variable
 * label) or a plain known number (label omitted).
 */
function formatTerm(coefficient, label) {
  if (coefficient === 0) return null
  const magnitude = Math.abs(coefficient)
  const sign = coefficient < 0 ? '-' : '+'
  if (label === undefined) {
    return `${sign} ${fmt(magnitude)}`
  }
  const coeffText = magnitude === 1 ? '' : `${fmt(magnitude)}·`
  return `${sign} ${coeffText}${label}`
}

/**
 * Joins formatted terms into "term1 term2 ... = 0", stripping a leading
 * "+ " so the line doesn't start with a stray plus sign.
 */
function joinTerms(terms) {
  const filtered = terms.filter(Boolean)
  if (filtered.length === 0) return '0 = 0'
  const joined = filtered.join(' ')
  return `${joined.startsWith('+') ? joined.slice(2) : joined} = 0`
}

/** One-line "why this equation, why this reference point" text per equation kind. */
function reasoningFor(kind, referenceNodeId) {
  if (kind === 'fx') {
    return (
      'Treat the whole truss as a single rigid body and sum the horizontal (x) ' +
      'components of every applied load and every support reaction — for the body ' +
      'to be in equilibrium, that total must equal zero.'
    )
  }
  if (kind === 'fy') {
    return (
      'With the other reaction component(s) already pinned down by the earlier ' +
      'steps, sum the vertical (y) components of every applied load and support ' +
      'reaction — the total must equal zero, which now isolates the one unknown ' +
      'still left.'
    )
  }
  return (
    `Sum moments of every load and reaction about node ${referenceNodeId}, using ` +
    `M = Δx·Fy − Δy·Fx (the standard right-hand-rule cross product, ` +
    `counterclockwise positive) for each force. Taking moments about a support ` +
    `conveniently zeroes out that support's own reaction component(s), since their ` +
    `moment arm about their own location is zero — that leaves fewer unknowns in ` +
    `this one equation.`
  )
}

/**
 * Per-load line for the itemized breakdown, e.g.:
 *  - fx/fy: "Load at n3: fy = -200"
 *  - moment: "Load at n3 (x=3, y=4): moment about n1 = Δx·fy − Δy·fx =
 *             (3)×(-200) − (4)×(50) = -600 − 200 = -800"
 */
function describeLoadContribution(kind, load, referencePoint, referenceNodeId) {
  if (kind === 'fx') {
    return { text: `Load at ${load.nodeId}: fx = ${fmt(load.fx)}`, value: load.fx }
  }
  if (kind === 'fy') {
    return { text: `Load at ${load.nodeId}: fy = ${fmt(load.fy)}`, value: load.fy }
  }
  const dx = load.position.x - referencePoint.x
  const dy = load.position.y - referencePoint.y
  const term1 = dx * load.fy
  const term2 = dy * load.fx
  const value = term1 - term2
  const text =
    `Load at ${load.nodeId} (x=${fmt(load.position.x)}, y=${fmt(load.position.y)}): ` +
    `moment about ${referenceNodeId} = Δx·fy − Δy·fx (CCW positive) = ` +
    `(${fmt(dx)})×(${fmt(load.fy)}) − (${fmt(dy)})×(${fmt(load.fx)}) = ` +
    `${fmt(term1)} − ${fmt(term2)} = ${fmt(value)}`
  return { text, value }
}

/**
 * Per-unknown line for the itemized breakdown. If the unknown was already
 * solved in an earlier step, the line shows its known numeric value and
 * the numeric contribution it makes to this equation. If it's still
 * unknown, the line shows how its coefficient in this equation was
 * derived (directly for ΣFx/ΣFy, via its moment arm for ΣM) without
 * assuming a value for it yet.
 */
function describeUnknownContribution(kind, unknown, coefficient, referencePoint, resolved) {
  const label = labelFor(unknown)
  const known = label in resolved
  const { x, y } = unknown.position

  if (kind !== 'moment') {
    if (known) {
      const value = resolved[label]
      return {
        text:
          `Reaction ${label} at ${unknown.nodeId}: already known from an earlier step ` +
          `= ${value}, contributing ${fmt(coefficient)}×${value} = ${fmt(coefficient * value)}`,
        knownNow: false,
      }
    }
    return {
      text: `Reaction ${label} at ${unknown.nodeId}: still unknown, coefficient ${fmt(coefficient)} in this equation`,
      knownNow: false,
    }
  }

  // Moment equation: explain the arm this reaction's coefficient came
  // from, using the same M = Δx·Fy − Δy·Fx (CCW+) convention as the load
  // terms above — a horizontal reaction (Fy=0) only has a "−Δy·Fx" term,
  // a vertical reaction (Fx=0) only has a "Δx·Fy" term.
  const dx = x - referencePoint.x
  const dy = y - referencePoint.y
  const armText =
    unknown.dir.x === 1
      ? `−Δy·Fx term ⇒ −Δy = −(${fmt(dy)}) = ${fmt(-dy)}`
      : `Δx·Fy term ⇒ Δx = (${fmt(dx)}) = ${fmt(dx)}`

  if (known) {
    const value = resolved[label]
    return {
      text:
        `Reaction ${label} at ${unknown.nodeId} (x=${fmt(x)}, y=${fmt(y)}): moment arm gives ` +
        `coefficient ${armText}; already known = ${value}, contributing ` +
        `${fmt(coefficient)}×${value} = ${fmt(coefficient * value)}`,
      knownNow: false,
    }
  }
  return {
    text:
      `Reaction ${label} at ${unknown.nodeId} (x=${fmt(x)}, y=${fmt(y)}): moment arm gives ` +
      `coefficient ${armText} → term is ${fmt(coefficient)}·${label}`,
    knownNow: false,
  }
}

/**
 * Narrates one overall-equilibrium equation (ΣFx, ΣFy, or ΣM) as a fully
 * worked step — reasoning for the choice of equation/reference point, an
 * itemized arithmetic breakdown of every load's and reaction's individual
 * contribution, the combined substitution, and the final result — in the
 * same "assume-tension-style bookkeeping, substitute the real numbers,
 * solve for the unknown" sequence the reference guides use for the
 * overall free-body diagram of the whole truss (Beer & Johnston §6.4 step
 * 1; Meriam/Kraige/Bolton §4.3; Hibbeler's Method of Joints "Support
 * Reactions" step). Every number here comes from `model` — nothing is
 * hard-coded from any textbook example.
 *
 * @param resolved - Map of already-known unknown labels -> numeric value,
 *   from earlier steps in this same call; mutated in place as this step
 *   resolves new unknowns.
 */
function narrateEquation({
  kind,
  title,
  equationLabel,
  unknowns,
  coefficients,
  loads,
  referencePoint,
  referenceNodeId,
  resolved,
  finalValues,
}) {
  const reasoning = reasoningFor(kind, referenceNodeId)
  const equation = `${equationLabel} = 0`

  // Itemized breakdown: one line per load, then one line per reaction
  // that actually appears in this equation (nonzero coefficient).
  const breakdown = []
  for (const load of loads) {
    breakdown.push(describeLoadContribution(kind, load, referencePoint, referenceNodeId).text)
  }
  unknowns.forEach((unknown, index) => {
    const coeff = coefficients[index]
    if (coeff === 0) return
    breakdown.push(describeUnknownContribution(kind, unknown, coeff, referencePoint, resolved).text)
  })

  // Combined substitution line: known applied-load resultant, plus every
  // unknown term — using its *numeric* value if a previous step already
  // solved it, or its variable name if it's still unknown.
  const knownSum = loads.reduce(
    (total, load) => total + describeLoadContribution(kind, load, referencePoint, referenceNodeId).value,
    0,
  )
  const knownTerm = formatTerm(knownSum)
  const unknownTerms = unknowns.map((unknown, index) => {
    const coeff = coefficients[index]
    if (coeff === 0) return null
    const label = labelFor(unknown)
    if (label in resolved) {
      return formatTerm(coeff * resolved[label])
    }
    return formatTerm(coeff, label)
  })
  const substitution = joinTerms([knownTerm, ...unknownTerms])

  // Which unknowns does this equation actually involve, and which of
  // those are still unresolved after previous steps?
  const involvedIndices = coefficients
    .map((coeff, index) => (coeff !== 0 ? index : -1))
    .filter((index) => index !== -1)
  const newIndices = involvedIndices.filter((index) => !(labelFor(unknowns[index]) in resolved))

  let result
  if (newIndices.length === 1) {
    const index = newIndices[0]
    const unknown = unknowns[index]
    const label = labelFor(unknown)
    const value = fmt(finalValues[index])
    resolved[label] = value
    result = `${label} = ${value}`
  } else if (newIndices.length === 0) {
    // Every unknown in this equation was already pinned down by an
    // earlier step — this equation is left as the equilibrium check
    // rather than a new unknown to solve for.
    result = 'Already determined by the previous steps — satisfies this equation as a check.'
  } else {
    // More unknowns than this single equation can isolate on its own
    // (only arises for unusual support layouts); report the values the
    // full linear solve found for them rather than pretending to derive
    // them from this equation alone.
    result = newIndices
      .map((index) => {
        const label = labelFor(unknowns[index])
        const value = fmt(finalValues[index])
        resolved[label] = value
        return `${label} = ${value}`
      })
      .join(', ')
  }

  return { title, reasoning, equation, breakdown, substitution, result }
}

/**
 * Unit direction vector that a support's reaction component acts along.
 *  - a pin contributes two perpendicular reaction components: Rx (1,0)
 *    and Ry (0,1)
 *  - a roller contributes a single reaction component along whichever
 *    axis it constrains (`rollerDirection`: 'x' or 'y')
 *
 * Returns an array of { component, dir: {x, y} } describing every
 * unknown reaction this support contributes, in a stable order.
 */
function reactionComponentsForSupport(support) {
  if (support.type === 'pin') {
    return [
      { component: 'Rx', dir: { x: 1, y: 0 } },
      { component: 'Ry', dir: { x: 0, y: 1 } },
    ]
  }

  if (support.type === 'roller') {
    const direction = support.rollerDirection || 'y'
    if (direction === 'x') {
      return [{ component: 'Rx', dir: { x: 1, y: 0 } }]
    }
    if (direction === 'y') {
      return [{ component: 'Ry', dir: { x: 0, y: 1 } }]
    }
    throw new Error(`Unknown rollerDirection "${direction}" on support at node "${support.nodeId}"`)
  }

  throw new Error(`Unknown support type "${support.type}" at node "${support.nodeId}"`)
}

/**
 * Looks up a node's position from `layout` — computeLayout() output, i.e.
 * positions built purely from the dx/dy distances the USER typed, in the
 * same +x right / +y UP frame as the loads (so moment arms and force
 * directions are consistent). Throws on a dangling reference.
 */
function getNodePosition(layout, nodeId) {
  const position = layout[nodeId]
  if (!position) {
    throw new Error(`Support/load references node "${nodeId}", which does not exist in the model`)
  }
  return position
}

/**
 * The z-component of (P - ref) × F, i.e. the moment that a force F
 * applied at point P exerts about `ref`. Positive is counter-clockwise,
 * matching the usual statics sign convention.
 */
function momentAbout(ref, point, fx, fy) {
  return (point.x - ref.x) * fy - (point.y - ref.y) * fx
}

/**
 * Solves for every unknown support reaction component of `model` by
 * enforcing overall rigid-body equilibrium of the truss (ΣFx = 0,
 * ΣFy = 0, ΣM = 0 about a reference point).
 *
 * This only determines the *external* reactions — it says nothing about
 * individual member forces (that's the job of the Method of Joints /
 * Method of Sections solvers, which take these reactions as known
 * inputs).
 *
 * @param {object} model - a truss model matching the shape documented
 *   in src/models/trussModel.js
 * @returns {{ reactions: Object.<string, Object.<string, number>>, steps: Array<{title: string, reasoning: string, equation: string, breakdown: string[], substitution: string, result: string}> }}
 *   `reactions` is keyed by support nodeId, e.g.
 *   { n1: { Rx: 400, Ry: 300 }, n4: { Ry: 900 } }. `steps` walks through
 *   the same ΣFx / ΣM / ΣFy overall-equilibrium equations the reference
 *   guides use — each with a one-line rationale (`reasoning`), an
 *   itemized per-load/per-reaction arithmetic breakdown (`breakdown`),
 *   the combined numeric equation (`substitution`), and the value it
 *   resolves (`result`) — with the model's actual numbers throughout.
 * @throws if the truss is not statically determinate, or if the number
 *   of unknown reaction components isn't exactly 3 (overall rigid-body
 *   equilibrium only ever supplies 3 independent equations in 2D, so
 *   that's the only case this step of the solve can resolve on its own)
 */
export function solveReactions(model) {
  const { m, j, r, status } = checkDeterminacy(model)
  if (status !== 'determinate') {
    throw new Error(
      `Cannot solve reactions: truss is ${status} (m=${m}, j=${j}, r=${r}; ` +
        `determinacy requires m + r = 2j). Fix the model before solving.`,
    )
  }

  if (model.supports.length === 0) {
    throw new Error('Cannot solve reactions: the truss has no supports.')
  }

  // Computed once, from the same user-typed-distance geometry TrussCanvas
  // draws (+y up, matching the load frame) — never from pixel positions.
  const layout = computeLayout(model)

  // Build the ordered list of unknowns: one entry per reaction component
  // contributed by every support (2 for a pin, 1 for a roller).
  const unknowns = model.supports.flatMap((support) => {
    const position = getNodePosition(layout, support.nodeId)
    return reactionComponentsForSupport(support).map(({ component, dir }) => ({
      nodeId: support.nodeId,
      component,
      dir,
      position,
    }))
  })

  // Overall rigid-body equilibrium in 2D only ever gives 3 independent
  // equations (ΣFx, ΣFy, ΣM). If the supports imply a different number
  // of unknowns, this step alone can't resolve them — even though the
  // truss as a whole may still satisfy the m + r = 2j determinacy count
  // (e.g. it might be internally redundant to compensate).
  if (unknowns.length !== 3) {
    throw new Error(
      `Cannot solve reactions: overall equilibrium supplies exactly 3 equations ` +
        `(ΣFx=0, ΣFy=0, ΣM=0), but the supports imply ${unknowns.length} unknown ` +
        `reaction component(s). This solver only handles externally determinate ` +
        `trusses (total reaction components = 3).`,
    )
  }

  // Reference point for the moment equation: the first support's node,
  // per the guides' "sum moments about a convenient point" guidance —
  // using a support point conveniently zeroes out that support's own
  // moment contribution (if it's a pin) or at least one of its
  // components (if it's a roller).
  const referenceNodeId = model.supports[0].nodeId
  const referencePoint = getNodePosition(layout, referenceNodeId)

  // Loads with their positions resolved once, reused both for the actual
  // solve and for narrating each step's itemized breakdown.
  const loads = model.loads.map((load) => ({
    nodeId: load.nodeId,
    fx: load.fx,
    fy: load.fy,
    position: getNodePosition(layout, load.nodeId),
  }))

  // Known side: the resultant of all applied external loads.
  let sumFxKnown = 0
  let sumFyKnown = 0
  let sumMomentKnown = 0
  for (const load of loads) {
    sumFxKnown += load.fx
    sumFyKnown += load.fy
    sumMomentKnown += momentAbout(referencePoint, load.position, load.fx, load.fy)
  }

  // Build the 3x3 coefficient matrix A (rows: ΣFx, ΣFy, ΣM equations;
  // columns: the unknown reaction components, in `unknowns` order) and
  // the right-hand side b, so that A · x = b solves ΣF/ΣM = 0, i.e. the
  // unknown reactions exactly balance the known applied loads.
  const A = [
    unknowns.map((u) => u.dir.x), // ΣFx = 0
    unknowns.map((u) => u.dir.y), // ΣFy = 0
    unknowns.map((u) => momentAbout(referencePoint, u.position, u.dir.x, u.dir.y)), // ΣM = 0
  ]
  const b = [[-sumFxKnown], [-sumFyKnown], [-sumMomentKnown]]

  let solution
  try {
    solution = lusolve(A, b)
  } catch (err) {
    throw new Error(
      `Cannot solve reactions: the equilibrium equations are singular (the chosen ` +
        `supports can't resist the applied loads as arranged — e.g. all reaction ` +
        `directions are parallel, or every support sits on the same line). ` +
        `Underlying error: ${err.message}`,
    )
  }

  // mathjs's lusolve returns a plain nested array when given plain arrays,
  // but a Matrix (with a `.get()` method) when given mathjs Matrix inputs.
  // Normalize to a plain nested array so we don't depend on which one we
  // got back.
  const solutionArray = typeof solution.toArray === 'function' ? solution.toArray() : solution

  // Assemble the flat solution vector back into { nodeId: { Rx, Ry } }.
  const reactions = {}
  const finalValues = unknowns.map((_, index) => solutionArray[index][0])
  unknowns.forEach((unknown, index) => {
    const value = finalValues[index]
    if (!reactions[unknown.nodeId]) reactions[unknown.nodeId] = {}
    reactions[unknown.nodeId][unknown.component] = value
  })

  // Narrate the same three equations in the textbook sequence — sum
  // forces in x, sum moments about a support (isolating one vertical
  // reaction), then sum forces in y for whatever's left — substituting
  // this model's real numbers at each step. `resolved` accumulates
  // known values as we go so later steps can plug in real numbers
  // instead of leaving earlier unknowns symbolic.
  const resolved = {}
  const [fxCoeffs, fyCoeffs, momentCoeffs] = A
  const steps = [
    narrateEquation({
      kind: 'fx',
      title: 'Sum forces in x',
      equationLabel: 'ΣFx',
      unknowns,
      coefficients: fxCoeffs,
      loads,
      referencePoint,
      referenceNodeId,
      resolved,
      finalValues,
    }),
    narrateEquation({
      kind: 'moment',
      title: `Sum moments about node ${referenceNodeId}`,
      // Per-force moment formula is M = Δx·Fy − Δy·Fx (the r × F cross
      // product, CCW positive) — the standard sign convention. The
      // shorthand "M = Fx·dy − Fy·dx" some texts give is the same
      // formula with its two terms swapped in order/sign and is only
      // valid once you've independently worked out the rotational sense
      // by inspection; we state the unambiguous cross-product form
      // directly so the sign is never in question.
      equationLabel: `ΣM_${referenceNodeId} (M = Δx·Fy − Δy·Fx per force, CCW+)`,
      unknowns,
      coefficients: momentCoeffs,
      loads,
      referencePoint,
      referenceNodeId,
      resolved,
      finalValues,
    }),
    narrateEquation({
      kind: 'fy',
      title: 'Sum forces in y',
      equationLabel: 'ΣFy',
      unknowns,
      coefficients: fyCoeffs,
      loads,
      referencePoint,
      referenceNodeId,
      resolved,
      finalValues,
    }),
  ]

  return { reactions, steps }
}

export default solveReactions
