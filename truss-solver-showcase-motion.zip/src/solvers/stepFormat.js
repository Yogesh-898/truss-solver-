/**
 * stepFormat.js
 *
 * Formatting and trigonometry helpers shared by every solver's narrated
 * `steps` output, so the Method of Joints and the Method of Sections
 * round, sign and label their numbers identically and can never disagree
 * about the same member.
 *
 * Nothing here changes a result — these functions only turn numbers the
 * solvers already computed into readable text.
 */

/** Angles within this many degrees count as the same direction. */
export const ANGLE_TOLERANCE_DEG = 1e-6

/** Relative tolerance for calling a solved force "zero". */
export const ZERO_FORCE_TOLERANCE = 1e-7

/** Absolute tolerance for a pivot / determinant / residual being zero. */
export const NUMERIC_TOLERANCE = 1e-9

/** Rounds for display only; the solve itself always uses full precision. */
export function fmt(value) {
  const rounded = Math.round(value * 1000) / 1000
  return Object.is(rounded, -0) ? 0 : rounded
}

/** Drops float noise like 6.1e-17 from a cos/sin result. */
export function cleanTrig(value) {
  if (Math.abs(value) < 1e-12) return 0
  return Math.round(value * 1e12) / 1e12
}

export function cosOf(angleDeg) {
  return cleanTrig(Math.cos((angleDeg * Math.PI) / 180))
}

export function sinOf(angleDeg) {
  return cleanTrig(Math.sin((angleDeg * Math.PI) / 180))
}

/** True when two directions lie on the same line (equal, or 180° apart). */
export function isCollinear(angleA, angleB) {
  const difference = Math.abs(((angleA - angleB) % 360) + 360) % 360
  return (
    difference < ANGLE_TOLERANCE_DEG ||
    Math.abs(difference - 180) < ANGLE_TOLERANCE_DEG ||
    Math.abs(difference - 360) < ANGLE_TOLERANCE_DEG
  )
}

/** Formats "+ 0.8·F_m3", "- F_m1" or "+ 400" for an equation line. */
export function formatTerm(coefficient, label) {
  if (coefficient === 0) return null
  const magnitude = Math.abs(coefficient)
  const sign = coefficient < 0 ? '-' : '+'
  if (label === undefined) return `${sign} ${fmt(magnitude)}`
  const coefficientText = Math.abs(magnitude - 1) < 1e-12 ? '' : `${fmt(magnitude)}·`
  return `${sign} ${coefficientText}${label}`
}

/** Joins formatted terms into "a + b - c = 0", without a leading "+". */
export function joinTerms(terms) {
  const filtered = terms.filter(Boolean)
  if (filtered.length === 0) return '0 = 0'
  const joined = filtered.join(' ')
  return `${joined.startsWith('+ ') ? joined.slice(2) : joined} = 0`
}

/** "800 kN" when units are supplied, "800" when they aren't. */
export function withForceUnit(value, units) {
  return units?.force ? `${fmt(value)} ${units.force}` : `${fmt(value)}`
}

/** "4 m" when units are supplied, "4" when they aren't. */
export function withLengthUnit(value, units) {
  return units?.length ? `${fmt(value)} ${units.length}` : `${fmt(value)}`
}

/**
 * Appends the force unit to every "Label = number" in solveReactions'
 * result strings. Units are labelling only — no number changes here.
 */
export function labelReactionSteps(steps, units) {
  if (!units?.force) return steps
  return steps.map((step) => ({
    ...step,
    result: step.result.replace(
      /(R[xy]_[A-Za-z0-9_]+ = )(-?\d+(?:\.\d+)?)/g,
      (_match, prefix, number) => `${prefix}${number} ${units.force}`,
    ),
  }))
}

/** 'Tension' | 'Compression' | 'Zero-force' for a tension-positive force. */
export function natureOf(force, scale = 1) {
  if (Math.abs(force) <= ZERO_FORCE_TOLERANCE * Math.max(scale, 1)) return 'Zero-force'
  return force > 0 ? 'Tension' : 'Compression'
}

/** "800 kN (T)" / "500 kN (C)" / "0 kN (zero-force)". */
export function resultLabel(force, nature, units) {
  if (nature === 'Zero-force') return `${withForceUnit(0, units)} (zero-force)`
  const suffix = nature === 'Tension' ? '(T)' : '(C)'
  return `${withForceUnit(Math.abs(force), units)} ${suffix}`
}
