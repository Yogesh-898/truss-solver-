/**
 * sectionMethod.js
 *
 * The Method of Sections, as a GENERAL solver: any model from
 * src/store/trussStore.js, any cut line the user draws. Nothing about a
 * particular truss — node layout, member count, load pattern, which side
 * is "the good side" — is assumed or hard-coded.
 *
 * ── What the two clicks are for ──────────────────────────────────────
 *
 * The cut line reaches this module already converted into the real-unit
 * frame (src/utils/view.js `toModel`). It is used for exactly ONE thing:
 * a line-segment crossing test that decides WHICH members the cut passes
 * through. It never enters a force or a moment equation. Every length,
 * angle, moment arm and line of action below comes from computeLayout /
 * getMemberGeometry, i.e. from the distances the user typed.
 *
 * ── Procedure (Hibbeler §6.4; Beer & Johnston §6.7; Meriam/Kraige §4.5) ─
 *
 * 1. Solve the whole truss as a rigid body for the support reactions.
 * 2. Pass the cut through AT LEAST THREE members (there is no upper
 *    limit). With exactly three unknown forces the free body's three
 *    equilibrium equations solve them all. With more, only a member that
 *    one equation isolates is solved (see "More than three members").
 * 3. Isolate one side as a free body — the side with fewer external
 *    forces, since that is less arithmetic.
 * 4. Assume every cut member is in TENSION, pulling the free body toward
 *    the member's other end (its far side of the cut). A positive answer
 *    confirms tension, a negative one means compression.
 * 5. Sum moments about the intersection of two unknowns' lines of action
 *    to eliminate both and get the third directly. If two unknowns are
 *    parallel, sum forces perpendicular to them instead.
 *
 * ── More than three members ─────────────────────────────────────────
 *
 * A free body only has three equilibrium equations, so it cannot fix
 * more than three unknown forces. Nothing is guessed: a cut member is
 * solved ONLY when a single equation isolates it — a moment sum about a
 * point every OTHER unknown's line of action passes through, or, when all
 * the other unknowns are parallel, a force sum perpendicular to them.
 * Members whose forces are already known — zero-force members, or members
 * solved by an earlier cut on the same model (passed in as
 * `knownResults`) — are not unknowns: they act on the free body as known
 * forces. Whatever cannot be isolated is reported as unsolved, with the
 * reason, instead of being made up.
 *
 * ── Sign rule (identical to jointMethod.js) ──────────────────────────
 *
 * A member's `angle` points startNodeId → endNodeId. A member in tension
 * pulls each end toward the other end, so the force it exerts on the free
 * body, applied at whichever end node lies INSIDE the free body, acts
 * along `angle` when that node is the member's start and `angle + 180°`
 * when it is the member's end. Forces are tension-positive.
 */

import { checkDeterminacy } from '../models/trussModel.js'
import { computeLayout, getMemberGeometry } from '../models/layoutEngine.js'
import { solveReactions } from './reactions.js'
import { findZeroForceMembers } from './jointMethod.js'
import {
  NUMERIC_TOLERANCE,
  cosOf,
  fmt,
  formatTerm,
  joinTerms,
  labelReactionSteps,
  natureOf,
  resultLabel,
  sinOf,
  withForceUnit,
  withLengthUnit,
} from './stepFormat.js'

/** A cut passing closer than this (as a fraction of a member) to a joint is ambiguous. */
const JOINT_PROXIMITY = 1e-6

/** Below this, two lines of action count as parallel rather than intersecting. */
const PARALLEL_TOLERANCE = 1e-9

// ── Geometry helpers ─────────────────────────────────────────────────

/**
 * Where two finite segments cross, or null. `t` runs along the first
 * segment (the cut), `u` along the second (the member).
 */
function segmentIntersection(cutStart, cutEnd, memberStart, memberEnd) {
  const r = { x: cutEnd.x - cutStart.x, y: cutEnd.y - cutStart.y }
  const s = { x: memberEnd.x - memberStart.x, y: memberEnd.y - memberStart.y }
  const denominator = r.x * s.y - r.y * s.x
  if (Math.abs(denominator) < 1e-15) return null // parallel or collinear

  const qp = { x: memberStart.x - cutStart.x, y: memberStart.y - cutStart.y }
  const t = (qp.x * s.y - qp.y * s.x) / denominator
  const u = (qp.x * r.y - qp.y * r.x) / denominator
  if (t < -1e-9 || t > 1 + 1e-9 || u < -1e-9 || u > 1 + 1e-9) return null

  return { t, u, point: { x: cutStart.x + t * r.x, y: cutStart.y + t * r.y } }
}

/** z-component of (point − reference) × F: the moment, counterclockwise positive. */
function momentAbout(reference, point, fx, fy) {
  return (point.x - reference.x) * fy - (point.y - reference.y) * fx
}

/**
 * Intersection of two infinite lines, each given by a point on it and a
 * direction angle in degrees. Returns null when they are parallel.
 */
function lineIntersection(pointA, angleA, pointB, angleB) {
  const dA = { x: cosOf(angleA), y: sinOf(angleA) }
  const dB = { x: cosOf(angleB), y: sinOf(angleB) }
  const denominator = dA.x * dB.y - dA.y * dB.x
  if (Math.abs(denominator) < PARALLEL_TOLERANCE) return null
  const t = ((pointB.x - pointA.x) * dB.y - (pointB.y - pointA.y) * dB.x) / denominator
  return { x: pointA.x + t * dA.x, y: pointA.y + t * dA.y }
}

/** Connected groups of node ids, using only the members left after the cut. */
function connectedComponents(model, remainingMembers) {
  const parent = new Map(model.nodes.map((node) => [node.id, node.id]))
  const find = (id) => {
    let root = id
    while (parent.get(root) !== root) root = parent.get(root)
    let walk = id
    while (parent.get(walk) !== walk) {
      const next = parent.get(walk)
      parent.set(walk, root)
      walk = next
    }
    return root
  }
  for (const member of remainingMembers) {
    const a = find(member.startNodeId)
    const b = find(member.endNodeId)
    if (a !== b) parent.set(a, b)
  }

  const groups = new Map()
  for (const node of model.nodes) {
    const root = find(node.id)
    if (!groups.has(root)) groups.set(root, [])
    groups.get(root).push(node.id)
  }
  return [...groups.values()]
}

/** "left" / "right" / "upper" / "lower", from the two sides' centroids. */
function describeSide(layout, sideNodeIds, otherNodeIds) {
  const centroid = (ids) => {
    const points = ids.map((id) => layout[id]).filter(Boolean)
    if (points.length === 0) return { x: 0, y: 0 }
    return {
      x: points.reduce((total, p) => total + p.x, 0) / points.length,
      y: points.reduce((total, p) => total + p.y, 0) / points.length,
    }
  }
  const mine = centroid(sideNodeIds)
  const theirs = centroid(otherNodeIds)
  if (Math.abs(mine.x - theirs.x) >= Math.abs(mine.y - theirs.y)) {
    return mine.x < theirs.x ? 'left' : 'right'
  }
  return mine.y > theirs.y ? 'upper' : 'lower'
}

// ── Equilibrium equations over the free body ─────────────────────────

/**
 * Builds one candidate equation over the free body.
 *
 * `coefficients[i]` multiplies unknown i (a cut member's tension force);
 * `known` is everything already numeric (applied loads, solved
 * reactions). The equation asserts `known + Σ coefficients[i]·F_i = 0`.
 */
function momentEquation(unknowns, knownForces, reference, label, reasoning) {
  return {
    kind: 'moment',
    label,
    reasoning,
    reference,
    coefficients: unknowns.map((unknown) =>
      momentAbout(reference, unknown.point, unknown.ux, unknown.uy),
    ),
    known: knownForces.reduce(
      (total, force) => total + momentAbout(reference, force.point, force.fx, force.fy),
      0,
    ),
    describeKnown: (force) => {
      const dx = force.point.x - reference.x
      const dy = force.point.y - reference.y
      return (
        `${force.label}: Δx·Fy − Δy·Fx = (${fmt(dx)})×(${fmt(force.fy)}) − ` +
        `(${fmt(dy)})×(${fmt(force.fx)}) = ${fmt(momentAbout(reference, force.point, force.fx, force.fy))}`
      )
    },
    describeUnknown: (unknown, coefficient) => {
      const dx = unknown.point.x - reference.x
      const dy = unknown.point.y - reference.y
      if (Math.abs(coefficient) < NUMERIC_TOLERANCE) {
        return (
          `${unknown.memberId}: its line of action passes through this moment centre, ` +
          `so its moment arm is zero and it drops out of this equation.`
        )
      }
      return (
        `${unknown.memberId}: acts at ${unknown.attachNodeId} (Δx = ${fmt(dx)}, Δy = ${fmt(dy)}) ` +
        `along ${fmt(unknown.directionAngle)}°, so its moment coefficient is ` +
        `Δx·sinθ − Δy·cosθ = (${fmt(dx)})×(${fmt(unknown.uy)}) − (${fmt(dy)})×(${fmt(unknown.ux)}) ` +
        `= ${fmt(coefficient)}`
      )
    },
  }
}

function forceEquation(unknowns, knownForces, direction, label, reasoning) {
  return {
    kind: 'force',
    label,
    reasoning,
    direction,
    coefficients: unknowns.map((unknown) => unknown.ux * direction.x + unknown.uy * direction.y),
    known: knownForces.reduce(
      (total, force) => total + force.fx * direction.x + force.fy * direction.y,
      0,
    ),
    describeKnown: (force) =>
      `${force.label}: (${fmt(force.fx)}, ${fmt(force.fy)}) resolved along ` +
      `(${fmt(direction.x)}, ${fmt(direction.y)}) = ${fmt(force.fx * direction.x + force.fy * direction.y)}`,
    describeUnknown: (unknown, coefficient) => {
      if (Math.abs(coefficient) < NUMERIC_TOLERANCE) {
        return (
          `${unknown.memberId}: at ${fmt(unknown.directionAngle)}° it is perpendicular to this ` +
          `direction, so it contributes nothing to this equation.`
        )
      }
      return (
        `${unknown.memberId}: direction ${fmt(unknown.directionAngle)}° ` +
        `(cosθ = ${fmt(unknown.ux)}, sinθ = ${fmt(unknown.uy)}) resolved along ` +
        `(${fmt(direction.x)}, ${fmt(direction.y)}) gives coefficient ${fmt(coefficient)}`
      )
    },
  }
}

/**
 * The pool of equations worth trying, in the order the reference guides
 * recommend: moment centres at pairwise intersections first (each kills
 * two unknowns at once), perpendicular-force equations where two
 * unknowns are parallel, then single-elimination moments, then plain
 * ΣFx / ΣFy.
 */
function buildCandidateEquations(unknowns, knownForces, units) {
  const candidates = []

  for (let i = 0; i < unknowns.length; i += 1) {
    for (let j = i + 1; j < unknowns.length; j += 1) {
      const a = unknowns[i]
      const b = unknowns[j]
      const meeting = lineIntersection(a.point, a.lineAngle, b.point, b.lineAngle)

      if (meeting) {
        candidates.push(
          momentEquation(
            unknowns,
            knownForces,
            meeting,
            `ΣM about (${fmt(meeting.x)}, ${fmt(meeting.y)})`,
            `The lines of action of ${a.memberId} and ${b.memberId} meet at ` +
              `(x = ${withLengthUnit(meeting.x, units)}, y = ${withLengthUnit(meeting.y, units)}). ` +
              `Taking moments about that point gives both of them a zero moment arm, so they ` +
              `drop out and the remaining cut force is found directly from one equation.`,
          ),
        )
      } else {
        // Parallel unknowns: summing forces perpendicular to them removes
        // both, which is the guides' stated fallback for this case.
        const perpendicular = {
          x: -sinOf(a.lineAngle),
          y: cosOf(a.lineAngle),
        }
        candidates.push(
          forceEquation(
            unknowns,
            knownForces,
            perpendicular,
            `ΣF perpendicular to ${a.memberId} / ${b.memberId} ` +
              `(direction ${fmt(perpendicular.x)}, ${fmt(perpendicular.y)})`,
            `${a.memberId} and ${b.memberId} are parallel (both at ${fmt(a.lineAngle)}°), so ` +
              `their lines of action never meet and no moment centre can remove both. Summing ` +
              `forces perpendicular to them removes both instead, isolating the third cut force.`,
          ),
        )
      }
    }
  }

  // Moment about a point on ONE unknown's line of action — removes just
  // that unknown. This is what solves a 1- or 2-member cut.
  for (const unknown of unknowns) {
    candidates.push(
      momentEquation(
        unknowns,
        knownForces,
        unknown.point,
        `ΣM about ${unknown.attachNodeId}`,
        `Joint ${unknown.attachNodeId} lies on ${unknown.memberId}'s line of action, so taking ` +
          `moments there removes ${unknown.memberId} (and any other cut force through that joint) ` +
          `from the equation.`,
      ),
    )
  }

  candidates.push(
    forceEquation(
      unknowns,
      knownForces,
      { x: 1, y: 0 },
      'ΣFx = 0',
      'Sum the horizontal components of every force on the isolated free body.',
    ),
  )
  candidates.push(
    forceEquation(
      unknowns,
      knownForces,
      { x: 0, y: 1 },
      'ΣFy = 0',
      'Sum the vertical components of every force on the isolated free body.',
    ),
  )

  return candidates
}

/** Narrates one equation and returns the force it isolates. */
function narrateEquation({ equation, unknowns, knownForces, resolved, targetIndex, units }) {
  const breakdown = []
  for (const force of knownForces) {
    breakdown.push(equation.describeKnown(force))
  }
  equation.coefficients.forEach((coefficient, index) => {
    const unknown = unknowns[index]
    const line = equation.describeUnknown(unknown, coefficient)
    if (Math.abs(coefficient) >= NUMERIC_TOLERANCE && unknown.memberId in resolved) {
      breakdown.push(
        `${line}; already solved, F_${unknown.memberId} = ` +
          `${withForceUnit(resolved[unknown.memberId], units)}, contributing ` +
          `${fmt(coefficient * resolved[unknown.memberId])}`,
      )
    } else {
      breakdown.push(line)
    }
  })

  const knownTotal =
    equation.known +
    equation.coefficients.reduce((total, coefficient, index) => {
      const memberId = unknowns[index].memberId
      if (!(memberId in resolved)) return total
      return total + coefficient * resolved[memberId]
    }, 0)

  const target = unknowns[targetIndex]
  const targetCoefficient = equation.coefficients[targetIndex]
  const force = -knownTotal / targetCoefficient
  resolved[target.memberId] = force

  const substitution = joinTerms([
    formatTerm(knownTotal),
    formatTerm(targetCoefficient, `F_${target.memberId}`),
  ])
  const nature = natureOf(force)

  return {
    step: {
      title: `${equation.label} — solve ${target.memberId}`,
      reasoning: equation.reasoning,
      equation: `${equation.label} = 0`,
      breakdown,
      substitution,
      result:
        `F_${target.memberId} = ${fmt(-knownTotal)} / ${fmt(targetCoefficient)} = ` +
        `${withForceUnit(force, units)}  →  ${target.memberId} = ${resultLabel(force, nature, units)}`,
    },
    force,
  }
}

// ── Main solver ──────────────────────────────────────────────────────

/**
 * Solves the forces in the members a drawn cut crosses.
 *
 * @param {object} model - a truss model per src/models/trussModel.js
 * @param {{ start: {x: number, y: number}, end: {x: number, y: number} }} cutLine
 *   the two clicked points, ALREADY converted to the real-unit frame by
 *   src/utils/view.js `toModel`. Used only to decide which members the
 *   cut crosses — never as a dimension in any equation.
 * @param {{ length?: string, force?: string }} [units] - labelling only.
 * @param {Object.<string, { force: number }>} [knownResults] - member
 *   forces already solved on THIS model (earlier cuts). They are treated
 *   as known forces on the free body, not as unknowns.
 * @returns {{
 *   results: Object.<string, { force: number, nature: string, label: string }>,
 *   reactions: object,
 *   crossedMemberIds: string[],
 *   solvedMemberIds: string[],
 *   knownMemberIds: string[],
 *   unsolvedMemberIds: string[],
 *   unsolvedNote: string | null,
 *   freeBodyNodeIds: string[],
 *   sideLabel: string,
 *   steps: Array<object>
 * }}
 *   `results` has the same shape as jointMethod.js, keyed by member id,
 *   tension-positive. It holds the members this cut determined (plus any
 *   crossed zero-force members). Members it could not isolate are listed
 *   in `unsolvedMemberIds` and are absent from `results`.
 * @throws {Error} with a plain-language message for every failure case:
 *   an indeterminate truss, a cut that crosses nothing, a cut that
 *   crosses fewer than three members, a cut through a joint, a cut that
 *   does not separate the truss, a section that is singular (concurrent
 *   lines of action), and a cut where no member can be isolated.
 */
export function solveSectionMethod(model, cutLine, units, knownResults = {}) {
  // 1. The cut itself has to be a real segment, and the truss has to be
  //    solvable at all, before anything else is worth doing.
  if (!cutLine?.start || !cutLine?.end) {
    throw new Error('Draw a cut line with two clicks before solving.')
  }
  const cutLength = Math.hypot(cutLine.end.x - cutLine.start.x, cutLine.end.y - cutLine.start.y)
  if (cutLength < NUMERIC_TOLERANCE) {
    throw new Error('The two clicks landed on the same point — draw a cut line with some length.')
  }

  const { m, j, r, status } = checkDeterminacy(model)
  if (status !== 'determinate') {
    throw new Error(
      `Cannot run the Method of Sections: the truss is ${status} (m=${m}, j=${j}, r=${r}; ` +
        `determinacy requires m + r = 2j). Fix the model before cutting it.`,
    )
  }

  const layout = computeLayout(model)
  const geometryById = new Map()
  for (const member of model.members) {
    const geometry = getMemberGeometry(model, member, layout)
    if (geometry && geometry.length > NUMERIC_TOLERANCE) geometryById.set(member.id, geometry)
  }

  // 2. Which members does the cut cross? This is the ONLY use of the
  //    clicked points.
  const crossed = []
  for (const member of model.members) {
    const geometry = geometryById.get(member.id)
    if (!geometry) continue
    const start = layout[member.startNodeId]
    const end = layout[member.endNodeId]
    if (!start || !end) continue

    const hit = segmentIntersection(cutLine.start, cutLine.end, start, end)
    if (!hit) continue
    if (hit.u < JOINT_PROXIMITY || hit.u > 1 - JOINT_PROXIMITY) {
      const jointId = hit.u < 0.5 ? member.startNodeId : member.endNodeId
      throw new Error(
        `The cut passes exactly through joint ${jointId}, so it is ambiguous which members it ` +
          `separates. Redraw the cut so it crosses members between their joints.`,
      )
    }
    crossed.push({ member, geometry, at: hit.point })
  }

  if (crossed.length === 0) {
    throw new Error(
      'The cut does not cross any members. Draw it so the line passes through the members you ' +
        'want to solve.',
    )
  }
  if (crossed.length < 3) {
    throw new Error(
      `The cut crosses only ${crossed.length} member${crossed.length === 1 ? '' : 's'} ` +
        `(${crossed.map((c) => c.member.id).join(', ')}). Redraw the cut so it crosses at least ` +
        `3 members.`,
    )
  }

  // 3. Does removing them actually split the truss in two?
  const crossedIds = new Set(crossed.map((c) => c.member.id))
  const remainingMembers = model.members.filter((member) => !crossedIds.has(member.id))
  const components = connectedComponents(model, remainingMembers)

  if (components.length !== 2) {
    throw new Error(
      `Removing the ${crossed.length} crossed member(s) leaves ${components.length} separate ` +
        `piece(s), not 2, so this cut does not divide the truss into two free bodies. Redraw the ` +
        `cut so it passes right through the truss.`,
    )
  }

  const [groupA, groupB] = components.map((ids) => new Set(ids))
  for (const { member } of crossed) {
    const startInA = groupA.has(member.startNodeId)
    const endInA = groupA.has(member.endNodeId)
    if (startInA === endInA) {
      throw new Error(
        `Member ${member.id} has both ends on the same side of the cut, so the cut does not ` +
          `truly separate the truss there. Redraw the cut.`,
      )
    }
  }

  // 4. Reactions for the whole truss — the free body needs them as known
  //    forces, exactly as in the reference procedure's step 1.
  let reactions
  let reactionSteps
  try {
    const solved = solveReactions(model)
    reactions = solved.reactions
    reactionSteps = solved.steps
  } catch (error) {
    throw new Error(error.message)
  }

  // 5. Pick the side with fewer external forces as the free body.
  const externalCount = (group) => {
    const loads = model.loads.filter(
      (load) => group.has(load.nodeId) && (load.fx !== 0 || load.fy !== 0),
    ).length
    const reactionComponents = Object.entries(reactions)
      .filter(([nodeId]) => group.has(nodeId))
      .reduce((total, [, components_]) => total + Object.keys(components_).length, 0)
    return loads + reactionComponents
  }
  const countA = externalCount(groupA)
  const countB = externalCount(groupB)
  const freeBody = countA <= countB ? groupA : groupB
  const otherSide = freeBody === groupA ? groupB : groupA
  const freeBodyCount = Math.min(countA, countB)
  const otherCount = Math.max(countA, countB)
  const sideLabel = describeSide(layout, [...freeBody], [...otherSide])

  // 6. Every crossed member gets a direction on the free body: applied
  //    at whichever end node sits inside it. A member whose force is
  //    already known — zero-force, or solved by an earlier cut on this
  //    same model — is NOT an unknown; it acts on the free body as a
  //    known force instead.
  const zeroForceIds = new Set(findZeroForceMembers(model).map((zero) => zero.memberId))
  const cutMembers = crossed.map(({ member, geometry }) => {
    const startInside = freeBody.has(member.startNodeId)
    const attachNodeId = startInside ? member.startNodeId : member.endNodeId
    const farNodeId = startInside ? member.endNodeId : member.startNodeId
    const directionAngle = startInside ? geometry.angle : (geometry.angle + 180) % 360

    let knownForce = null
    let knownSource = null
    const earlier = knownResults?.[member.id]
    if (earlier && Number.isFinite(earlier.force)) {
      knownForce = earlier.force
      knownSource = 'solved by an earlier cut'
    } else if (zeroForceIds.has(member.id)) {
      knownForce = 0
      knownSource = 'a zero-force member'
    }

    return {
      memberId: member.id,
      attachNodeId,
      farNodeId,
      point: layout[attachNodeId],
      lineAngle: geometry.angle,
      directionAngle,
      ux: cosOf(directionAngle),
      uy: sinOf(directionAngle),
      geometry,
      startInside,
      member,
      knownForce,
      knownSource,
    }
  })
  const unknowns = cutMembers.filter((cutMember) => cutMember.knownForce === null)
  const knownMembers = cutMembers.filter((cutMember) => cutMember.knownForce !== null)

  if (unknowns.length === 0) {
    throw new Error(
      `Every member this cut crosses (${crossed.map((c) => c.member.id).join(', ')}) already has ` +
        `a known force — zero-force, or solved by an earlier cut — so there is nothing new to ` +
        `find. Draw a cut through members that are still unsolved.`,
    )
  }

  // Known forces acting on the free body: its applied loads and its
  // support reactions, each at its own node's derived position, plus any
  // already-known cut members.
  const knownForces = []
  for (const load of model.loads) {
    if (!freeBody.has(load.nodeId)) continue
    if (load.fx === 0 && load.fy === 0) continue
    knownForces.push({
      label: `Applied load at ${load.nodeId} (x = ${fmt(layout[load.nodeId].x)}, y = ${fmt(layout[load.nodeId].y)})`,
      point: layout[load.nodeId],
      fx: load.fx,
      fy: load.fy,
    })
  }
  for (const [nodeId, components_] of Object.entries(reactions)) {
    if (!freeBody.has(nodeId)) continue
    for (const [component, value] of Object.entries(components_)) {
      if (value === 0) continue
      knownForces.push({
        label: `Reaction ${component}_${nodeId} (x = ${fmt(layout[nodeId].x)}, y = ${fmt(layout[nodeId].y)})`,
        point: layout[nodeId],
        fx: component === 'Rx' ? value : 0,
        fy: component === 'Ry' ? value : 0,
      })
    }
  }
  for (const known of knownMembers) {
    if (known.knownForce === 0) continue // contributes nothing
    knownForces.push({
      label:
        `Member ${known.memberId} (known force ${withForceUnit(known.knownForce, units)}, ` +
        `${known.knownSource}; at x = ${fmt(known.point.x)}, y = ${fmt(known.point.y)})`,
      point: known.point,
      fx: known.ux * known.knownForce,
      fy: known.uy * known.knownForce,
    })
  }

  // 7. Narrate the setup.
  const steps = [...labelReactionSteps(reactionSteps, units)]
  const overDetermined = unknowns.length > 3

  const isolateStep = {
    title: `Isolate the ${sideLabel} segment`,
    reasoning:
      `Every part of a truss in equilibrium is itself in equilibrium, so either side of the cut ` +
      `can be treated as a rigid free body. The ${sideLabel} side is chosen because it carries ` +
      `fewer external forces (${freeBodyCount} vs. ${otherCount} on the other side), which means ` +
      `less arithmetic for the same answer.`,
    equation: `Cut crosses ${crossed.map((c) => c.member.id).join(', ')}`,
    breakdown: [
      `Free body: joints ${[...freeBody].join(', ')}.`,
      `Discarded side: joints ${[...otherSide].join(', ')}.`,
      `External forces kept on the free body: ` +
        (knownForces.length > 0 ? knownForces.map((f) => f.label.split(' (')[0]).join('; ') : 'none'),
      `Each unknown cut member is replaced by a force assumed to be in TENSION, pulling the ` +
        `free body toward the member's far end.`,
      ...knownMembers.map(
        (known) =>
          `${known.memberId} is ${known.knownSource}` +
          (known.knownForce === 0
            ? ', so its force is 0 and it adds nothing to the equations.'
            : `, so it acts as a known force of ${withForceUnit(known.knownForce, units)}.`),
      ),
    ],
    substitution: `${unknowns.length} unknown member force(s): ${unknowns.map((u) => `F_${u.memberId}`).join(', ')}.`,
    result: overDetermined
      ? `${unknowns.length} unknowns but only 3 equilibrium equations — only a member that a ` +
        `single equation isolates can be solved from this cut.`
      : `Free body ready — 3 equilibrium equations available for ${unknowns.length} unknown(s).`,
  }
  steps.push(isolateStep)

  for (const cutMember of cutMembers) {
    const isKnown = cutMember.knownForce !== null
    steps.push({
      title: `Direction of the cut force in ${cutMember.memberId}`,
      reasoning:
        `${cutMember.memberId} runs ${cutMember.member.startNodeId} → ${cutMember.member.endNodeId}, and ` +
        `its end ${cutMember.attachNodeId} is on the free body while ${cutMember.farNodeId} is on the ` +
        `discarded side. In tension it pulls joint ${cutMember.attachNodeId} toward ` +
        `${cutMember.farNodeId}, so the direction used is ` +
        (cutMember.startInside
          ? `the member's own angle.`
          : `angle + 180° = ${fmt(cutMember.geometry.angle)}° + 180°.`),
      equation: `F_${cutMember.memberId} acts at ${cutMember.attachNodeId} along ${fmt(cutMember.directionAngle)}°`,
      breakdown: [
        `Member ${cutMember.memberId}: angle = ${fmt(cutMember.geometry.angle)}°, length = ` +
          `${withLengthUnit(cutMember.geometry.length, units)} (both derived from the typed distances).`,
        `Direction used on this free body = ${fmt(cutMember.directionAngle)}°, ` +
          `cosθ = ${fmt(cutMember.ux)}, sinθ = ${fmt(cutMember.uy)}.`,
        `Applied at joint ${cutMember.attachNodeId} (x = ${fmt(cutMember.point.x)}, y = ${fmt(cutMember.point.y)}).`,
      ],
      substitution: `F_${cutMember.memberId} → (${fmt(cutMember.ux)}·F_${cutMember.memberId}, ${fmt(cutMember.uy)}·F_${cutMember.memberId})`,
      result: isKnown
        ? `Force already known (${cutMember.knownSource}): ` +
          `${resultLabel(cutMember.knownForce, natureOf(cutMember.knownForce), units)} — used as a known force.`
        : `Ready to use in the equilibrium equations below.`,
    })
  }

  // 8. Pick and apply equations that each isolate one unknown, in the
  //    order the guides prefer. Every equation narrated below is an
  //    equation actually used to get a number. The loop stops when
  //    everything is solved, or when no equation isolates any of what is
  //    left — it never guesses.
  const candidates = buildCandidateEquations(unknowns, knownForces, units)
  const resolved = {}
  const solvedBy = {}
  const usedLabels = new Set()

  while (Object.keys(resolved).length < unknowns.length) {
    let chosen = null
    let chosenTarget = -1

    for (const equation of candidates) {
      if (usedLabels.has(equation.label)) continue
      const openIndices = equation.coefficients
        .map((coefficient, index) => ({ coefficient, index }))
        .filter(
          ({ coefficient, index }) =>
            Math.abs(coefficient) >= NUMERIC_TOLERANCE && !(unknowns[index].memberId in resolved),
        )
      if (openIndices.length !== 1) continue
      chosen = equation
      chosenTarget = openIndices[0].index
      break
    }

    if (!chosen) break

    usedLabels.add(chosen.label)
    const { step } = narrateEquation({
      equation: chosen,
      unknowns,
      knownForces,
      resolved,
      targetIndex: chosenTarget,
      units,
    })
    solvedBy[unknowns[chosenTarget].memberId] = chosen.label
    steps.push(step)
  }

  const unresolved = unknowns.filter((unknown) => !(unknown.memberId in resolved))
  const complete = unresolved.length === 0

  if (Object.keys(resolved).length === 0) {
    if (overDetermined) {
      throw new Error(
        `This cut exposes ${unknowns.length} unknown member forces (${unknowns
          .map((u) => u.memberId)
          .join(', ')}), but the isolated segment has only 3 equilibrium equations, and no ` +
          `single equation isolates any one of them — so nothing can be solved from it. Redraw ` +
          `the cut through 3 unsolved members, or solve neighbouring members first so they ` +
          `count as known.`,
      )
    }

    const concurrent =
      unknowns.length === 3 &&
      (() => {
        const meeting = lineIntersection(
          unknowns[0].point,
          unknowns[0].lineAngle,
          unknowns[1].point,
          unknowns[1].lineAngle,
        )
        if (!meeting) return false
        const third = unknowns[2]
        const offset = momentAbout(meeting, third.point, third.ux, third.uy)
        return Math.abs(offset) < 1e-9
      })()

    if (concurrent) {
      throw new Error(
        `This cut cannot be solved: the lines of action of ${unknowns
          .map((u) => u.memberId)
          .join(', ')} all meet at a single point, so no moment equation can separate them ` +
          `and the section is statically indeterminate. Redraw the cut through a different ` +
          `set of members.`,
      )
    }
    throw new Error(
      `This cut cannot be solved: the equilibrium equations for the isolated segment are ` +
        `singular, so the forces in ${unknowns
          .map((u) => u.memberId)
          .join(', ')} are not determined by this section alone. Redraw the cut, or use the ` +
        `Method of Joints for these members.`,
    )
  }

  // 9. Independent check (only meaningful when every unknown is solved):
  //    the free body must satisfy all three overall equilibrium
  //    equations, not just the ones used above.
  const scale = Math.max(...Object.values(resolved).map((f) => Math.abs(f)), 1)
  let residuals = []
  if (complete) {
    const checkReference = unknowns[0].point
    residuals = [
      {
        name: 'ΣFx',
        value:
          knownForces.reduce((total, force) => total + force.fx, 0) +
          unknowns.reduce((total, unknown) => total + unknown.ux * resolved[unknown.memberId], 0),
      },
      {
        name: 'ΣFy',
        value:
          knownForces.reduce((total, force) => total + force.fy, 0) +
          unknowns.reduce((total, unknown) => total + unknown.uy * resolved[unknown.memberId], 0),
      },
      {
        name: 'ΣM',
        value:
          knownForces.reduce(
            (total, force) => total + momentAbout(checkReference, force.point, force.fx, force.fy),
            0,
          ) +
          unknowns.reduce(
            (total, unknown) =>
              total +
              momentAbout(checkReference, unknown.point, unknown.ux, unknown.uy) *
                resolved[unknown.memberId],
            0,
          ),
      },
    ]
    const worst = residuals.reduce((a, b) => (Math.abs(a.value) > Math.abs(b.value) ? a : b))
    if (Math.abs(worst.value) > 1e-6 * scale) {
      throw new Error(
        `This cut cannot be solved consistently: the isolated segment still has a net ` +
          `${worst.name} of ${fmt(worst.value)} after solving, which means the section's three ` +
          `equilibrium equations contradict each other. Check the supports and loads, or redraw ` +
          `the cut.`,
      )
    }
  }

  const results = {}
  for (const unknown of unknowns) {
    if (!(unknown.memberId in resolved)) continue
    const force = resolved[unknown.memberId]
    const nature = natureOf(force, scale)
    results[unknown.memberId] = {
      force: nature === 'Zero-force' ? 0 : force,
      nature,
      label: resultLabel(force, nature, units),
    }
  }
  // Crossed zero-force members are determined too (their force is 0), so
  // they are reported and colour-coded like any other solved member.
  for (const known of knownMembers) {
    if (known.knownSource !== 'a zero-force member') continue
    results[known.memberId] = {
      force: 0,
      nature: 'Zero-force',
      label: resultLabel(0, 'Zero-force', units),
    }
  }

  const solvedMemberIds = unknowns.filter((u) => u.memberId in resolved).map((u) => u.memberId)
  const unsolvedMemberIds = unresolved.map((u) => u.memberId)
  const unsolvedNote = complete
    ? null
    : `${unsolvedMemberIds.join(', ')} could not be solved: this cut exposes ${unknowns.length} ` +
      `unknown forces but the isolated segment has only 3 equilibrium equations, and no single ` +
      `equation isolates ${unsolvedMemberIds.length === 1 ? 'it' : 'them'}. Draw a different ` +
      `cut, or solve neighbouring members first so they count as known.`

  if (crossed.length === 3 && complete && knownMembers.length === 0) {
    steps.push({
      title: 'Check and summarise',
      reasoning:
        `Only some of the three available equations were needed to find the unknowns. The unused ` +
        `ones are a free check: substituting the solved forces back into ΣFx, ΣFy and ΣM about ` +
        `${unknowns[0].attachNodeId} must leave nothing.`,
      equation: 'ΣFx = 0, ΣFy = 0, ΣM = 0 on the isolated segment',
      breakdown: residuals.map(
        (residual) => `${residual.name} residual = ${fmt(residual.value)} (zero to rounding).`,
      ),
      substitution: unknowns
        .map((unknown) => `F_${unknown.memberId} = ${withForceUnit(resolved[unknown.memberId], units)}`)
        .join(', '),
      result: unknowns
        .map((unknown) => `${unknown.memberId} = ${results[unknown.memberId].label}`)
        .join('; '),
    })
  } else {
    steps.push({
      title: 'Which cut members were determined',
      reasoning:
        `A free body has only three equilibrium equations, so a cut through more than three ` +
        `unknown members cannot fix them all. A member is solved only when a single equation ` +
        `isolates it; anything else is left unsolved rather than guessed.` +
        (complete
          ? ` Here every unknown was isolated, so the unused equations serve as a check.`
          : ''),
      equation: `Cut crosses ${crossed.length} members: ${unknowns.length} unknown, ${knownMembers.length} already known`,
      breakdown: [
        ...solvedMemberIds.map(
          (memberId) =>
            `${memberId} = ${results[memberId].label} — determined from ${solvedBy[memberId]}.`,
        ),
        ...knownMembers.map(
          (known) =>
            `${known.memberId} — already known (${known.knownSource}); used as a known force, not solved here.`,
        ),
        ...unresolved.map(
          (unknown) =>
            `${unknown.memberId} — NOT determined: after every equation that isolates a single ` +
            `force was used, it is still tied to the other unsolved members (more unknowns than ` +
            `independent equations).`,
        ),
        ...residuals.map(
          (residual) => `${residual.name} residual = ${fmt(residual.value)} (zero to rounding).`,
        ),
      ],
      substitution:
        `Determined: ${solvedMemberIds.join(', ') || 'none'}. ` +
        `Not determined: ${unsolvedMemberIds.join(', ') || 'none'}.`,
      result: complete
        ? `All ${unknowns.length} unknown cut member(s) determined.`
        : `${solvedMemberIds.length} of ${unknowns.length} unknown cut members determined; ` +
          `${unsolvedMemberIds.join(', ')} remain unsolved.`,
    })
  }

  // FBD metadata for the "Isolate the segment" step: ONLY the free body that was used.
  // Cut members become force arrows (not physical members); the discarded side is
  // never included. Values are the ones solved above (or already known).
  const forceOf = (memberId) => {
    if (memberId in results) return results[memberId]
    if (knownResults?.[memberId] && Number.isFinite(knownResults[memberId].force)) return knownResults[memberId]
    const known = knownMembers.find((k) => k.memberId === memberId)
    if (known) {
      const nature = natureOf(known.knownForce)
      return { force: known.knownForce, nature, label: resultLabel(known.knownForce, nature, units) }
    }
    return null
  }
  const insideIds = [...freeBody]
  isolateStep.fbd = {
    kind: 'section',
    nodes: insideIds.map((id) => ({ id, x: layout[id].x, y: layout[id].y })),
    members: model.members
      .filter((member) => freeBody.has(member.startNodeId) && freeBody.has(member.endNodeId))
      .map((member) => ({
        id: member.id,
        startNodeId: member.startNodeId,
        endNodeId: member.endNodeId,
        result: forceOf(member.id),
      })),
    cutMembers: cutMembers.map((cutMember) => ({
      id: cutMember.memberId,
      attachNodeId: cutMember.attachNodeId,
      angle: cutMember.directionAngle, // tension direction ON the free body
      result: forceOf(cutMember.memberId),
    })),
    loads: model.loads
      .filter((load) => freeBody.has(load.nodeId) && (load.fx !== 0 || load.fy !== 0))
      .map((load) => ({ nodeId: load.nodeId, magnitude: load.magnitude, angle: load.angle, fx: load.fx, fy: load.fy })),
    reactions: Object.entries(reactions)
      .filter(([nodeId]) => freeBody.has(nodeId))
      .map(([nodeId, components_]) => ({ nodeId, ...components_ })),
  }

  return {
    results,
    reactions,
    crossedMemberIds: crossed.map((c) => c.member.id),
    solvedMemberIds,
    knownMemberIds: knownMembers.map((known) => known.memberId),
    unsolvedMemberIds,
    unsolvedNote,
    freeBodyNodeIds: [...freeBody],
    sideLabel,
    steps,
  }
}

export default solveSectionMethod
