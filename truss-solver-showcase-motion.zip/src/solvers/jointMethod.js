/**
 * jointMethod.js
 *
 * The Method of Joints, as a GENERAL solver: it works on any model
 * matching src/models/trussModel.js, with any number of nodes, members,
 * supports and loads. Nothing about any particular truss — node layout,
 * member count, load pattern — is assumed or hard-coded.
 *
 * ── Where every number comes from ────────────────────────────────────
 *
 * Each member's direction is taken from the `angle` returned by
 * getMemberGeometry(model, member, layout) in layoutEngine.js, which is
 * derived from the dx/dy distances the USER typed. cosθ = cos(angle),
 * sinθ = sin(angle). This module never reads a pixel or click position,
 * and never rebuilds a Δx/Δy triangle of its own — if the geometry is
 * wrong, it is wrong in exactly one place (layoutEngine) rather than in
 * two places that can disagree.
 *
 * ── Sign rule ────────────────────────────────────────────────────────
 *
 * `angle` points from a member's startNodeId to its endNodeId. A member
 * in TENSION pulls each of its end joints toward the member's other end,
 * so the direction of the force a member exerts on a joint is:
 *
 *     at the member's START joint:  angle
 *     at the member's END joint:    angle + 180°
 *
 * Member forces are tension-positive throughout: a negative result means
 * compression.
 *
 * ── How it solves ────────────────────────────────────────────────────
 *
 * 1. solveReactions(model) first — the reactions become known forces.
 * 2. One global linear system, 2 rows per joint (ΣFx = 0, ΣFy = 0), with
 *    the member forces as the unknowns and the applied loads (load.fx,
 *    load.fy) plus the solved reactions moved to the known side.
 * 3. math.lusolve() on a square, full-rank subset of those rows, with the
 *    remaining rows checked as residuals so an inconsistent system is
 *    reported rather than quietly least-squares-fitted.
 *
 * The narrated `steps` walk joint by joint in a teaching order (a joint
 * with at most 2 unknown members and at least one known force first),
 * even though the arithmetic is one global solve. The numbers shown are
 * the numbers from that solve, so the walkthrough and the answer can't
 * disagree.
 */

import { lusolve } from 'mathjs'
import { checkDeterminacy } from '../models/trussModel.js'
import { computeLayout, getMemberGeometry } from '../models/layoutEngine.js'
import { solveReactions } from './reactions.js'
import {
  NUMERIC_TOLERANCE,
  cosOf,
  fmt,
  formatTerm,
  isCollinear,
  joinTerms,
  labelReactionSteps,
  natureOf,
  resultLabel,
  sinOf,
  withForceUnit,
} from './stepFormat.js'

// ── Geometry per joint ───────────────────────────────────────────────

/**
 * Every member touching `nodeId`, with the direction its force acts in on
 * THAT joint, per the sign rule: `angle` at the member's start joint,
 * `angle + 180°` at its end joint.
 */
function membersAtJoint(model, nodeId, geometryById) {
  const result = []
  for (const member of model.members) {
    const isStart = member.startNodeId === nodeId
    const isEnd = member.endNodeId === nodeId
    if (!isStart && !isEnd) continue

    const geometry = geometryById.get(member.id)
    if (!geometry) continue

    const directionAngle = isStart ? geometry.angle : (geometry.angle + 180) % 360
    result.push({
      member,
      geometry,
      isStart,
      directionAngle,
      cos: cosOf(directionAngle),
      sin: sinOf(directionAngle),
    })
  }
  return result
}

// ── FBD metadata ─────────────────────────────────────────────────────

/**
 * Structured description of one joint's free body, attached to each joint step as
 * `step.fbd` so the Steps panel can draw an isolated-joint diagram without parsing
 * text or re-deriving anything. Everything here is read from values this solver
 * already holds: the member directions from membersAtJoint (tension direction ON
 * this joint), the solved forces in `results`, the joint's load and reaction.
 */
function jointFbd(nodeId, connected, load, reaction, results, support) {
  return {
    kind: 'joint',
    nodeId,
    support: support ?? null,
    members: connected.map((entry) => ({
      id: entry.member.id,
      angle: entry.directionAngle,
      force: results[entry.member.id].force,
      nature: results[entry.member.id].nature,
      label: results[entry.member.id].label,
    })),
    load: load && (load.fx !== 0 || load.fy !== 0) ? { magnitude: load.magnitude, angle: load.angle, fx: load.fx, fy: load.fy } : null,
    reaction: reaction && Object.keys(reaction).length > 0 ? { ...reaction } : null,
  }
}

// ── Linear algebra plumbing ──────────────────────────────────────────

/**
 * Picks `columnCount` rows of `matrix` that are linearly independent, by
 * Gaussian elimination with partial pivoting on a scratch copy. Returns
 * the chosen ORIGINAL row indices, or null when the rows don't span the
 * unknowns (i.e. the truss is a mechanism).
 */
function pickIndependentRows(matrix, columnCount) {
  const work = matrix.map((row) => row.slice())
  const used = new Array(matrix.length).fill(false)
  const chosen = []

  for (let column = 0; column < columnCount; column += 1) {
    let bestRow = -1
    let bestMagnitude = NUMERIC_TOLERANCE
    for (let row = 0; row < work.length; row += 1) {
      if (used[row]) continue
      const magnitude = Math.abs(work[row][column])
      if (magnitude > bestMagnitude) {
        bestMagnitude = magnitude
        bestRow = row
      }
    }
    if (bestRow === -1) return null

    used[bestRow] = true
    chosen.push(bestRow)

    for (let row = 0; row < work.length; row += 1) {
      if (used[row]) continue
      const factor = work[row][column] / work[bestRow][column]
      if (factor === 0) continue
      for (let c = column; c < columnCount; c += 1) {
        work[row][c] -= factor * work[bestRow][c]
      }
    }
  }
  return chosen
}

/** lusolve returns either a nested array or a Matrix; normalize it. */
function toNestedArray(solution) {
  return typeof solution?.toArray === 'function' ? solution.toArray() : solution
}

// ── Zero-force members ───────────────────────────────────────────────

/**
 * The two standard special cases, decided from the members' derived
 * angles taken in the direction pointing AWAY from the joint:
 *
 *  1. Exactly two members meet at a joint with no external load and no
 *     support, and they are NOT collinear -> both members are zero-force.
 *  2. Exactly three members meet at such a joint and two of them are
 *     collinear -> the third (non-collinear) member is zero-force.
 *
 * A joint carrying a load or a support is never eligible, because the
 * reaction/load supplies the force the rule assumes is absent.
 *
 * @returns {Array<{ memberId: string, nodeId: string, case: string, reason: string }>}
 */
export function findZeroForceMembers(model) {
  const layout = computeLayout(model)
  const geometryById = new Map()
  for (const member of model.members) {
    const geometry = getMemberGeometry(model, member, layout)
    if (geometry) geometryById.set(member.id, geometry)
  }

  const loadedNodeIds = new Set(
    model.loads.filter((load) => load.fx !== 0 || load.fy !== 0).map((load) => load.nodeId),
  )
  const supportedNodeIds = new Set(model.supports.map((support) => support.nodeId))

  const found = []
  const seen = new Set()

  for (const node of model.nodes) {
    if (loadedNodeIds.has(node.id) || supportedNodeIds.has(node.id)) continue

    const connected = membersAtJoint(model, node.id, geometryById)

    if (connected.length === 2) {
      const [a, b] = connected
      if (isCollinear(a.directionAngle, b.directionAngle)) continue
      for (const entry of [a, b]) {
        if (seen.has(entry.member.id)) continue
        seen.add(entry.member.id)
        found.push({
          memberId: entry.member.id,
          nodeId: node.id,
          case: 'two-member joint',
          reason:
            `Joint ${node.id} carries no load and no support, and only ${a.member.id} and ` +
            `${b.member.id} meet there. Their directions away from the joint are ` +
            `${fmt(a.directionAngle)}° and ${fmt(b.directionAngle)}°, which are not collinear, ` +
            `so neither can balance the other and both forces must be zero.`,
        })
      }
      continue
    }

    if (connected.length === 3) {
      for (let i = 0; i < 3; i += 1) {
        const others = connected.filter((_, index) => index !== i)
        if (!isCollinear(others[0].directionAngle, others[1].directionAngle)) continue
        const odd = connected[i]
        if (seen.has(odd.member.id)) break
        seen.add(odd.member.id)
        found.push({
          memberId: odd.member.id,
          nodeId: node.id,
          case: 'three-member joint with two collinear',
          reason:
            `Joint ${node.id} carries no load and no support. ${others[0].member.id} ` +
            `(${fmt(others[0].directionAngle)}°) and ${others[1].member.id} ` +
            `(${fmt(others[1].directionAngle)}°) are collinear, so summing forces ` +
            `perpendicular to that line leaves only ${odd.member.id} ` +
            `(${fmt(odd.directionAngle)}°), which must therefore be zero.`,
        })
        break
      }
    }
  }

  return found
}

// ── Joint ordering for the narration ─────────────────────────────────

/**
 * A teaching order: repeatedly take a joint with at most 2 still-unknown
 * members, preferring one that already has a known force acting on it (a
 * load, a reaction, or an already-solved member) — the "select a starting
 * joint" step of the standard procedure. Any joints the greedy pass can't
 * reach are appended in model order so the walkthrough is never truncated.
 */
function chooseJointOrder(model, geometryById, reactions) {
  const loadedNodeIds = new Set(
    model.loads.filter((load) => load.fx !== 0 || load.fy !== 0).map((load) => load.nodeId),
  )
  const reactionNodeIds = new Set(Object.keys(reactions))

  const remaining = model.nodes.map((node) => node.id)
  const solvedMemberIds = new Set()
  const order = []

  while (remaining.length > 0) {
    let pickIndex = -1
    let pickScore = -1

    remaining.forEach((nodeId, index) => {
      const connected = membersAtJoint(model, nodeId, geometryById)
      const unknownCount = connected.filter((entry) => !solvedMemberIds.has(entry.member.id)).length
      if (unknownCount > 2) return

      const hasKnownForce =
        loadedNodeIds.has(nodeId) ||
        reactionNodeIds.has(nodeId) ||
        connected.some((entry) => solvedMemberIds.has(entry.member.id))

      // Prefer a joint with a known force; among those, prefer the one
      // with the fewest unknowns (1 unknown resolves immediately).
      const score = (hasKnownForce ? 10 : 0) + (2 - unknownCount)
      if (score > pickScore) {
        pickScore = score
        pickIndex = index
      }
    })

    if (pickIndex === -1) break

    const [nodeId] = remaining.splice(pickIndex, 1)
    order.push(nodeId)
    for (const entry of membersAtJoint(model, nodeId, geometryById)) {
      solvedMemberIds.add(entry.member.id)
    }
  }

  return [...order, ...remaining]
}

// ── Step narration ───────────────────────────────────────────────────

/** The "here are this joint's member directions" step. */
function buildDirectionsStep(nodeId, connected, position) {
  const breakdown = connected.map((entry) => {
    const { member, geometry, isStart, directionAngle, cos, sin } = entry
    const role = isStart
      ? `this joint is its START node (${member.startNodeId} → ${member.endNodeId}), so the ` +
        `tension direction here is the member's own angle`
      : `this joint is its END node (${member.startNodeId} → ${member.endNodeId}), so the ` +
        `tension direction here is angle + 180° = ${fmt(geometry.angle)}° + 180°`
    return (
      `Member ${member.id} (${role}): angle = ${fmt(geometry.angle)}°, ` +
      `direction used = ${fmt(directionAngle)}°, cosθ = ${fmt(cos)}, sinθ = ${fmt(sin)}`
    )
  })

  return {
    title: `Joint ${nodeId} — member directions`,
    reasoning:
      `A joint is a concurrent force system, so only ΣFx = 0 and ΣFy = 0 apply there. ` +
      `Each member force is resolved along its own derived direction. A member in tension ` +
      `pulls this joint toward the member's other end, which is why the direction used is ` +
      `the member's angle at its start joint and angle + 180° at its end joint.`,
    equation: `Resolve each member at joint ${nodeId} into cosθ / sinθ`,
    breakdown,
    substitution: `Joint ${nodeId} is at (x = ${fmt(position.x)}, y = ${fmt(position.y)}), derived from the typed distances.`,
    result: `${connected.length} member direction(s) ready for the two equilibrium equations.`,
  }
}

/**
 * One ΣFx or ΣFy step at a joint: the itemized contributions, the
 * substituted equation with real numbers, and whatever member force the
 * equation isolates.
 *
 * @param resolved - memberId -> solved force, mutated as steps resolve.
 */
function buildEquilibriumStep({
  axis,
  nodeId,
  connected,
  load,
  reaction,
  forcesByMemberId,
  resolved,
  units,
  scale,
}) {
  const isX = axis === 'x'
  const componentKey = isX ? 'cos' : 'sin'
  const reactionKey = isX ? 'Rx' : 'Ry'
  const loadComponent = isX ? load?.fx ?? 0 : load?.fy ?? 0
  const reactionComponent = reaction?.[reactionKey] ?? 0

  const breakdown = []
  if (loadComponent !== 0) {
    breakdown.push(
      `Applied load at ${nodeId}: ${isX ? 'fx' : 'fy'} = ${withForceUnit(loadComponent, units)}`,
    )
  }
  if (reactionComponent !== 0) {
    breakdown.push(
      `Support reaction ${reactionKey}_${nodeId} (known from the reaction steps): ` +
        `${withForceUnit(reactionComponent, units)}`,
    )
  }

  const unknownEntries = []
  for (const entry of connected) {
    const coefficient = entry[componentKey]
    const label = `F_${entry.member.id}`
    if (coefficient === 0) {
      breakdown.push(
        `Member ${entry.member.id}: ${isX ? 'cos' : 'sin'}θ = 0 at ${fmt(entry.directionAngle)}°, ` +
          `so it contributes nothing to this equation.`,
      )
      continue
    }
    if (entry.member.id in resolved) {
      const value = resolved[entry.member.id]
      breakdown.push(
        `Member ${entry.member.id}: already solved, ${label} = ${withForceUnit(value, units)}, ` +
          `contributing ${fmt(coefficient)}×(${fmt(value)}) = ${fmt(coefficient * value)}`,
      )
    } else {
      breakdown.push(
        `Member ${entry.member.id}: unknown, term is ${fmt(coefficient)}·${label} ` +
          `(${isX ? 'cos' : 'sin'}θ at ${fmt(entry.directionAngle)}°)`,
      )
      unknownEntries.push(entry)
    }
  }

  const knownSum =
    loadComponent +
    reactionComponent +
    connected.reduce((total, entry) => {
      const coefficient = entry[componentKey]
      if (coefficient === 0 || !(entry.member.id in resolved)) return total
      return total + coefficient * resolved[entry.member.id]
    }, 0)

  const unknownTerms = unknownEntries.map((entry) =>
    formatTerm(entry[componentKey], `F_${entry.member.id}`),
  )
  const substitution = joinTerms([formatTerm(knownSum), ...unknownTerms])

  let result
  if (unknownEntries.length === 0) {
    result = 'No unknown left in this equation — it holds as an equilibrium check on the joint.'
  } else if (unknownEntries.length === 1) {
    const entry = unknownEntries[0]
    const force = forcesByMemberId[entry.member.id]
    resolved[entry.member.id] = force
    const nature = natureOf(force, scale)
    result =
      `F_${entry.member.id} = ${fmt(-knownSum)} / ${fmt(entry[componentKey])} = ` +
      `${withForceUnit(force, units)}  →  ${entry.member.id} = ${resultLabel(force, nature, units)}`
  } else {
    // Two unknowns here; this equation is solved together with the other
    // one at the same joint, so report both values the solve found.
    result = unknownEntries
      .map((entry) => {
        const force = forcesByMemberId[entry.member.id]
        resolved[entry.member.id] = force
        return `${entry.member.id} = ${resultLabel(force, natureOf(force, scale), units)}`
      })
      .join(', ')
    result = `Solved simultaneously with the other equation at this joint: ${result}`
  }

  return {
    title: `Joint ${nodeId} — ΣF${axis} = 0`,
    reasoning: isX
      ? `Sum the horizontal components of every force acting on joint ${nodeId}: its applied ` +
        `load, any support reaction there, and each member force along its own direction.`
      : `Sum the vertical components of every force acting on joint ${nodeId}, with any member ` +
        `force already found above substituted as a known number.`,
    equation: `ΣF${axis} = 0 at joint ${nodeId}`,
    breakdown: breakdown.length > 0 ? breakdown : ['No force has a component along this axis at this joint.'],
    substitution,
    result,
  }
}

// ── Main solver ──────────────────────────────────────────────────────

/**
 * Solves every member force by the Method of Joints.
 *
 * @param {object} model - a truss model per src/models/trussModel.js
 * @param {{ length?: string, force?: string }} [units] - labelling ONLY.
 *   Units never change a number; they are appended to result strings.
 * @returns {{
 *   results: Object.<string, { force: number, nature: string, label: string }>,
 *   reactions: Object.<string, Object.<string, number>>,
 *   zeroForceMembers: Array<object>,
 *   steps: Array<{ title: string, reasoning: string, equation: string, breakdown: string[], substitution: string, result: string }>
 * }}
 *   `results` is keyed by member id, tension-positive, e.g.
 *   { m1: { force: 800, nature: 'Tension', label: '800 N (T)' } }.
 * @throws {Error} with a plain-language message when the truss is not
 *   determinate, when solveReactions cannot run, when the geometry is
 *   degenerate, or when the joint equations are singular/inconsistent.
 *   An error is always raised in preference to returning a wrong answer.
 */
export function solveJointMethod(model, units) {
  // 1. Determinacy, then the reactions — the Method of Joints treats them
  //    as known forces, so they have to come first.
  const { m, j, r, status } = checkDeterminacy(model)
  if (status !== 'determinate') {
    throw new Error(
      `Cannot run the Method of Joints: the truss is ${status} (m=${m}, j=${j}, r=${r}; ` +
        `determinacy requires m + r = 2j). Fix the model before solving.`,
    )
  }
  if (model.members.length === 0) {
    throw new Error('Cannot run the Method of Joints: the truss has no members.')
  }

  let reactions
  let reactionSteps
  try {
    const solved = solveReactions(model)
    reactions = solved.reactions
    reactionSteps = solved.steps
  } catch (error) {
    // Surface the reactions solver's own clear message rather than
    // continuing with unknown reactions and producing wrong numbers.
    throw new Error(error.message)
  }

  // 2. Geometry, once, from the typed distances.
  const layout = computeLayout(model)
  const geometryById = new Map()
  const degenerate = []
  for (const member of model.members) {
    const geometry = getMemberGeometry(model, member, layout)
    if (!geometry) {
      degenerate.push(`${member.id} (an end node is missing from the model)`)
      continue
    }
    if (geometry.length < NUMERIC_TOLERANCE) {
      degenerate.push(`${member.id} (zero length — its two end nodes sit at the same position)`)
      continue
    }
    geometryById.set(member.id, geometry)
  }
  if (degenerate.length > 0) {
    throw new Error(
      `Cannot run the Method of Joints: these members have no usable direction — ` +
        `${degenerate.join('; ')}. Fix the node distances (or the member's end nodes) first.`,
    )
  }

  // 3. The global system: 2 rows per joint, member forces as unknowns.
  const memberIds = model.members.map((member) => member.id)
  const columnOf = new Map(memberIds.map((id, index) => [id, index]))
  const loadByNodeId = new Map(model.loads.map((load) => [load.nodeId, load]))
  const supportByNodeId = new Map(model.supports.map((support) => [support.nodeId, support.type]))

  const matrix = []
  const rightHandSide = []
  const rowLabels = []

  for (const node of model.nodes) {
    const connected = membersAtJoint(model, node.id, geometryById)
    const load = loadByNodeId.get(node.id)
    const reaction = reactions[node.id]

    for (const axis of ['x', 'y']) {
      const componentKey = axis === 'x' ? 'cos' : 'sin'
      const row = new Array(memberIds.length).fill(0)
      for (const entry of connected) {
        row[columnOf.get(entry.member.id)] += entry[componentKey]
      }
      const known =
        (axis === 'x' ? load?.fx ?? 0 : load?.fy ?? 0) +
        (axis === 'x' ? reaction?.Rx ?? 0 : reaction?.Ry ?? 0)

      matrix.push(row)
      rightHandSide.push(-known)
      rowLabels.push(`ΣF${axis} at joint ${node.id}`)
    }
  }

  // 4. Solve. There are 2j equations for m unknowns and, for a
  //    determinate truss, 2j = m + r > m — the reactions already consumed
  //    r of them. So pick m independent rows, solve those with lusolve,
  //    and use the leftover rows as a consistency check.
  const chosenRows = pickIndependentRows(matrix, memberIds.length)
  if (!chosenRows) {
    throw new Error(
      `Cannot run the Method of Joints: the joint equilibrium equations are singular. ` +
        `The truss is a mechanism (some part of it can move without stretching any member) ` +
        `or the supports are arranged so they cannot hold it — for example a joint whose ` +
        `members are all in line, or a panel with no diagonal. Check the member layout and ` +
        `the supports.`,
    )
  }

  const squareMatrix = chosenRows.map((rowIndex) => matrix[rowIndex])
  const squareRhs = chosenRows.map((rowIndex) => [rightHandSide[rowIndex]])

  let solution
  try {
    solution = toNestedArray(lusolve(squareMatrix, squareRhs))
  } catch (error) {
    throw new Error(
      `Cannot run the Method of Joints: the joint equilibrium equations could not be solved ` +
        `(the system is singular — the truss is a mechanism or the supports are arranged ` +
        `badly). Underlying error: ${error.message}`,
    )
  }

  const forces = solution.map((row) => row[0])
  const scale = Math.max(...forces.map((force) => Math.abs(force)), 1)

  // Every row not used in the square solve must still balance.
  for (let rowIndex = 0; rowIndex < matrix.length; rowIndex += 1) {
    if (chosenRows.includes(rowIndex)) continue
    const residual =
      matrix[rowIndex].reduce((total, coefficient, column) => total + coefficient * forces[column], 0) -
      rightHandSide[rowIndex]
    if (Math.abs(residual) > 1e-6 * scale) {
      throw new Error(
        `Cannot run the Method of Joints: the joint equations are inconsistent — ` +
          `"${rowLabels[rowIndex]}" cannot be satisfied by any set of member forces ` +
          `(out by ${fmt(residual)}). This usually means the truss is unstable despite ` +
          `passing the m + r = 2j count, or a load sits on a joint the members cannot resist.`,
      )
    }
  }

  const forcesByMemberId = {}
  memberIds.forEach((id, index) => {
    forcesByMemberId[id] = forces[index]
  })

  const results = {}
  for (const id of memberIds) {
    const force = forcesByMemberId[id]
    const nature = natureOf(force, scale)
    results[id] = {
      force: nature === 'Zero-force' ? 0 : force,
      nature,
      label: resultLabel(force, nature, units),
    }
  }

  // 5. Narrate. Reactions first, then zero-force members, then joints in
  //    teaching order — all showing the numbers from the solve above.
  const steps = [...labelReactionSteps(reactionSteps, units)]

  const zeroForceMembers = findZeroForceMembers(model)
  for (const zero of zeroForceMembers) {
    const solvedForce = forcesByMemberId[zero.memberId] ?? 0
    const zeroConnected = membersAtJoint(model, zero.nodeId, geometryById)
    steps.push({
      fbd: jointFbd(zero.nodeId, zeroConnected, loadByNodeId.get(zero.nodeId), reactions[zero.nodeId], results, supportByNodeId.get(zero.nodeId)),
      title: `Zero-force member ${zero.memberId} (by inspection at joint ${zero.nodeId})`,
      reasoning: zero.reason,
      equation: `Special case: ${zero.case}`,
      breakdown: [
        `Joint ${zero.nodeId} has no applied load and no support.`,
        `Spotting this before writing equations removes ${zero.memberId} as an unknown and ` +
          `makes the remaining joints easier to start from.`,
      ],
      substitution: `F_${zero.memberId} = 0`,
      result:
        `${zero.memberId} = ${resultLabel(0, 'Zero-force', units)}` +
        (Math.abs(solvedForce) > 1e-6 * scale
          ? ` (note: the full solve gives ${withForceUnit(solvedForce, units)} — check the model)`
          : ' — confirmed by the full solve.'),
    })
  }

  const resolved = {}
  for (const zero of zeroForceMembers) {
    resolved[zero.memberId] = 0
  }

  const jointOrder = chooseJointOrder(model, geometryById, reactions)
  for (const nodeId of jointOrder) {
    const connected = membersAtJoint(model, nodeId, geometryById)
    if (connected.length === 0) continue

    const load = loadByNodeId.get(nodeId)
    const reaction = reactions[nodeId]
    const fbd = jointFbd(nodeId, connected, load, reaction, results, supportByNodeId.get(nodeId))
    steps.push({ ...buildDirectionsStep(nodeId, connected, layout[nodeId]), fbd })

    // Present whichever equation isolates a single unknown first — that
    // is how the procedure is worked by hand.
    const countUnknowns = (componentKey) =>
      connected.filter(
        (entry) => entry[componentKey] !== 0 && !(entry.member.id in resolved),
      ).length
    const axes = countUnknowns('sin') === 1 && countUnknowns('cos') !== 1 ? ['y', 'x'] : ['x', 'y']

    for (const axis of axes) {
      steps.push({
        ...buildEquilibriumStep({
          axis,
          nodeId,
          connected,
          load,
          reaction,
          forcesByMemberId,
          resolved,
          units,
          scale,
        }),
        fbd,
      })
    }
  }

  return { results, reactions, zeroForceMembers, steps }
}

export default solveJointMethod
