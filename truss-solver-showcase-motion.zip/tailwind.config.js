import { palette } from './src/theme/palette.js'

/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './index.html',
    './src/**/*.{js,jsx}',
  ],
  theme: {
    extend: {
      /* ── Responsive breakpoints ─────────────────────────────── */
      screens: {
        // Toolbar button labels show at/above these widths; below → icon-only + tooltip.
        // Measured with the real Inter/JetBrains Mono fonts, labels need ≈935px in Joints
        // mode and ≈985px in Sections mode (the extra Section Cut button); each value
        // adds ~25px of slack for the wider "mm · kN" units label and font differences.
        // (+40px each for the icon-only Free body diagram toggle added to the right-hand group.)
        'toolbar-labels': '1000px',            // Joints mode
        'toolbar-labels-sections': '1050px',  // Sections mode
      },

      /* ── Layout ─────────────────────────────────────────────── */
      width: {
        sidebar: 'clamp(18rem, 28vw, 24rem)',   // 288–384px; ≈28% of the viewport at 1100–1280px
      },

      /* ── Design-system color tokens ─────────────────────────── */
      colors: palette,   // single source of truth: src/theme/palette.js

      /* ── Motion ─────────────────────────────────────────────── */
      // Dialog entrance. (These replace `animate-in fade-in`, which are
      // tailwindcss-animate classes and silently did nothing without that plugin.)
      keyframes: {
        'dialog-backdrop-in': { from: { opacity: '0' }, to: { opacity: '1' } },
        'dialog-panel-in': {
          from: { opacity: '0', transform: 'translateY(6px) scale(0.98)' },
          to: { opacity: '1', transform: 'none' },
        },
        // Unit selection: the option the user just picked pops (quick scale-up, soft settle)
        // while a ring pulse expands and fades around it. The first shadow is the selected
        // option's resting 1px ring (ring-1 ring-accent/30), repeated here so it doesn't
        // flicker while the animation overrides box-shadow.
        'unit-select': {
          '0%': {
            transform: 'scale(0.94)',
            boxShadow: '0 0 0 1px rgb(56 189 248 / 0.3), 0 0 0 1px rgb(56 189 248 / 0.45)',
          },
          '55%': {
            transform: 'scale(1.045)',
            boxShadow: '0 0 0 1px rgb(56 189 248 / 0.3), 0 0 0 6px rgb(56 189 248 / 0)',
          },
          '100%': {
            transform: 'scale(1)',
            boxShadow: '0 0 0 1px rgb(56 189 248 / 0.3), 0 0 0 6px rgb(56 189 248 / 0)',
          },
        },
      },
      animation: {
        'dialog-backdrop-in': 'dialog-backdrop-in 180ms ease-out both',
        'dialog-panel-in': 'dialog-panel-in 200ms cubic-bezier(0.16, 1, 0.3, 1) both',
        'unit-select': 'unit-select 200ms cubic-bezier(0.34, 1.4, 0.64, 1)',
      },

      /* ── Typography ─────────────────────────────────────────── */
      fontFamily: {
        technical: [
          '"JetBrains Mono"', '"Fira Code"', '"SF Mono"',
          '"Cascadia Code"', '"Source Code Pro"', 'Menlo',
          'Consolas', 'monospace',
        ],
        ui: [
          '"Inter"', '"Segoe UI"', 'Roboto', '"Helvetica Neue"',
          'Arial', 'sans-serif',
        ],
      },
    },
  },
  plugins: [],
}
